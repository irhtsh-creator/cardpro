# CardHub – Implementation Plan

## What the reference platform does (from site + API docs)
- Virtual cards for ad spend: browse products (BIN, min/max issue + top-up), issue, top up, withdraw, freeze/unfreeze, block, PIN, OTP/3DS codes.
- Per-card transaction feed (authorization, expense, decline, refund, reversal, maintenance fee) delivered by signed callbacks.
- KYC gate for some products (`kycSort`), fee types (success / decline / expense...), USD balance funded with crypto (USDT TRC-20 auto-converted).
- Requests are signed: `CAP-TOKEN`, `CAP-NONCE`, `CAP-SIGN = sha256(nonce + body + query + secret)`.

## Stack (chosen for zero-build, easy self-hosting)
- Node 22 + Express, built-in `node:sqlite` (no native compile), bcryptjs, jsonwebtoken (httpOnly cookie).
- Vanilla-JS single-page frontend (no build step), Server-Sent Events for real-time.
- Provider clients: `providers/cardspro.js`, `providers/capitalist.js`; both fall back to a built-in simulator when `MOCK_MODE=1`.

## Data model
users, settings (global fees), user_fee_overrides (columns on users), kyc, cards, card_tx, ledger (every balance movement), deposits, referrals, api_credentials, audit_log, events.

## Modules
1. Auth: signup (referral code), login, logout, roles `user | manager | admin`.
2. KYC: user form + document upload, admin review (approve/decline), optional provider KYC link.
3. Cards: products, issue (fees + min deposit), top-up, withdraw, freeze, block, details, OTP.
4. Wallet: internal USD ledger, USDT TRC-20 deposit address via Capitalist auto-conversion, deposit sync/callback, admin manual credit.
5. Transactions: unified history of ledger + card transactions with filters, CSV export.
6. Referrals: unique code, commission % on referred users' fees, payout to wallet.
7. Account manager: managers assigned to users, manager panel, manager contact shown to user.
8. Real-time report: SSE stream + live dashboard stats.
9. Admin: global fees (card/issue/top-up/transaction/decline), min deposit, per-user overrides, user control (suspend, balance adjust, assign manager, role), API credentials, referral settings, wallet settings, audit log.

## Security
Secrets only in `.env` (never in code or the frontend), password hashing, rate limits, role checks on every route, idempotent request ids, webhook secret path.

## Test plan
Automated end-to-end script (`npm test`) against the simulator: signup, login, KYC, deposit, issue, top-up, withdraw, freeze, block, fee math, referral payout, manager assignment, admin controls, SSE.
