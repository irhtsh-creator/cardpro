# CardHub – virtual card platform

Self-hosted rebuild of the CardsPro model: users sign up, pass KYC, fund a USD wallet with USDT (TRC-20, auto-converted via Capitalist), and issue/manage virtual cards for ad spend. Admins control every fee, limit, user, credential and feature.

**Stack:** Node 22 · Express 5 · built-in `node:sqlite` (no native builds) · vanilla-JS SPA (no build step) · Server-Sent Events for real-time.

## Quick start
```bash
npm install
cp .env.example .env      # then edit: APP_SECRET, WEBHOOK_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
npm start                 # http://localhost:3000
npm test                  # 148 end-to-end checks against the built-in simulator
```
Requires **Node 22.5+**. Log in with the admin email/password from `.env`.

## Simulator vs live
`PROVIDER_MODE=mock` (default) uses a built-in simulator of the CardsPro and Capitalist APIs; no real money moves, and the UI shows buttons to simulate deposits, card spend, declines and 3DS codes.
To go live: put your keys in `.env` (or Admin → **API credentials**, stored AES-encrypted), set `CAPITALIST_ACCOUNT` to your receiving account (e.g. `U0123504`), use **Test connection**, then Admin → **Fees & limits** → Provider mode → *Live*.

> **Rotate the API key/secret that was pasted in the chat.** Treat it as exposed. `.env` is git-ignored; never commit it.

## Provider integration
| What | Endpoint | Notes |
|---|---|---|
| Cards | `https://api.cardspro.com/cards/v1` – `/products /issue /{san}/details /topup /withdraw /block /freeze /unfreeze /otp-codes` | Headers `CAP-TOKEN`, `CAP-NONCE`, `CAP-SIGN = sha256(nonce + body + query + secret)` |
| USDT deposit address | Capitalist `GET /v1/depositAddressAutoUSDTt/{account}` (`https://api2.capitalist.net`) | Headers `API-Key`, `X-Request-Timestamp`, `Signature = sha256(ts + body + secret)`. Address valid ~8h, never reused |
| Deposit crediting | Capitalist `GET /v1/transactions` polled every 60s + on demand | Matched by destination address, idempotent per document id |

**Callbacks:** give CardsPro `https://YOUR-DOMAIN/api/webhooks/cardspro/<WEBHOOK_SECRET>`; optional Capitalist trigger at `/api/webhooks/capitalist/<WEBHOOK_SECRET>` (it only triggers a re-sync, the payload is never trusted). Serve behind HTTPS (nginx/Caddy) and set `PUBLIC_URL` to the https URL.

## Features → where
| Requirement | Location |
|---|---|
| Admin panel, all controls | `/#/admin/*` |
| Card / issue / top-up / transaction / decline fees, min deposit | Admin → Fees & limits (global), Card products (per product), user page (per user). Priority: user > product > global |
| User control (suspend, role, KYC, balance adjust, password reset, fee overrides) | Admin → Users → user |
| API credentials | Admin → API credentials |
| Referral control | Admin → Referrals + rate in Fees & limits (+ per-user rate) |
| Crypto wallet control | Admin → Crypto deposits |
| Feature switches, registration, maintenance | Admin → Fees & limits |
| Signup/login | `/#/signup`, `/#/login` |
| KYC | User: Verification · Admin: KYC queue (approve/decline with reason) |
| Cards | issue, top-up, withdraw, freeze, block, reveal PAN/CVV, 3DS codes |
| Real-time report | Dashboards (user + admin) with live SSE feed |
| Transactions | Wallet + card payments, filters, search, CSV export |
| Referral system | Link/code, commissions on issue/top-up/transaction/decline fees |
| Account manager | Auto-assignment, contact card, chat, private notes, manager panel scoped to assigned users |

## Money rules
- Issue/top-up debit amount + fee immediately; failure or decline refunds both. Referral commission is paid only when the operation succeeds.
- Withdrawals hold the card balance until confirmed. Callbacks and deposit syncs are idempotent.
- Wallet changes only go through `src/ledger.js` (append-only ledger).
- Timeouts leave an operation *pending*; Admin → Pending operations settles it after you check with the provider.

## Security notes
bcrypt passwords, HttpOnly session cookie, JSON-only mutations (CSRF), strict CSP, role checks on every route, secrets encrypted at rest, KYC files served only to owner/admin/assigned manager, CSV formula-injection guard, rate-limited auth. Before production: strong `APP_SECRET`/`WEBHOOK_SECRET`, HTTPS, change the admin password, back up `data/` (SQLite DB + KYC uploads), and add email verification / 2FA / a real KYC provider if required by your compliance obligations.

## Layout
`src/` server (`routes/`, `providers/`, `cardsvc.js`, `walletsvc.js`, `fees.js`, `ledger.js`) · `public/` SPA · `test/e2e.js` · `PLAN.md`
