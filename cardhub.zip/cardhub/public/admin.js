/* Admin + account-manager pages */
(() => {
'use strict';
const { html, raw, esc, $, get, post, put, patch, del, fmt, signed, date, badge, label, table, stat, chart, pager, field, toast, modal, closeModal, confirmBox, route, render, qstr, state: S, forms, actions } = window.CH;
const CH = window.CH;
const A = ['admin']; const STAFF = ['admin', 'manager'];
const pg = (k) => CH.pageKeys[k] || 1;
const ADMIN_ONLY_LIVE = { live: true };

// ---------- live dashboard ----------
route('/admin', A, async () => {
  const s = await get('/admin/stats');
  const cardsActive = s.cards.filter((c) => ['active', 'frozen'].includes(c.status)).reduce((a, c) => a + c.n, 0);
  return html`<h1>Live dashboard</h1><p class="muted">Platform-wide numbers, updated in real time. ${s.liveClients} live connection(s).</p>
  ${s.pendingKyc || s.pendingOps ? html`<div class="alert warn">${s.pendingKyc ? html`<a href="#/admin/kyc">${s.pendingKyc} KYC submission(s) waiting</a>. ` : ''}${s.pendingOps ? html`<a href="#/admin/ops">${s.pendingOps} card operation(s) pending</a>.` : ''}</div>` : ''}
  <div class="grid g4" style="margin-bottom:14px">${stat('Users', s.users, `+${s.newUsers7} this week`)}${stat('Active cards', cardsActive)}${stat('Spend (30d)', fmt(s.spend30), `${s.declines30} declines`)}${stat('Revenue (all-time fees)', fmt(s.revenueTotal), `${fmt(s.fees30)} last 30d`)}</div>
  <div class="grid g4" style="margin-bottom:16px">${stat('User wallet liabilities', fmt(s.liabilities))}${stat('Total deposited', fmt(s.depositsTotal))}${stat('Referral commissions paid', fmt(s.referralPaid))}${stat('Provider mode', s.mode === 'live' ? '🟢 live' : '🧪 simulator')}</div>
  <div class="grid g2"><div class="panel"><h2>Last 14 days</h2>${chart(s.labels, [{ name: 'Card spend', color: '#5b8cff', values: s.spendSeries }, { name: 'Deposits', color: '#34d6a8', values: s.depositSeries }, { name: 'Fee revenue', color: '#ffbe55', values: s.feeSeries }])}</div>
  <div class="panel"><h2>Live event stream</h2>${S.feed.length ? html`<div class="small">${S.feed.slice(0, 12).map((f) => html`<div>• <span class="muted">${new Date(f.at).toLocaleTimeString()}</span> user #${f.userId}: ${f.text}</div>`)}</div>` : html`<div class="muted small">Waiting for activity… (events from all users appear here instantly)</div>`}
  <h3 style="margin-top:16px">Recent</h3><div class="small">${s.recentEvents.slice(0, 8).map((f) => html`<div class="muted">${new Date(f.at).toLocaleTimeString()} · #${f.userId} · ${f.type}</div>`)}</div></div></div>
  <div class="grid g2"><div class="panel"><h2>Cards by status</h2>${table(['Status', 'Cards', 'Balance'], s.cards.map((c) => [badge(c.status), c.n, fmt(c.balance)]), 'No cards')}</div><div class="panel"><h2>Top merchants (30d)</h2>${table(['Merchant', 'Payments', 'Total'], s.topMerchants.map((m) => [m.merchant, m.n, fmt(m.total)]), 'No spend yet')}</div></div>`;
}, ADMIN_ONLY_LIVE);

// ---------- users ----------
const uState = { q: '', role: '', status: '' };
route('/admin/users', A, async () => {
  const page = pg('users'); const limit = 25;
  const r = await get('/admin/users?' + qstr({ ...uState, page, limit }));
  return html`<div class="row"><h1 class="sp">Users</h1><button class="btn" data-action="new-user">+ Create user</button></div>
  <form class="panel row" data-form="user-filter"><input name="q" placeholder="Search email, name, referral code" value="${uState.q}" style="max-width:300px"><select name="role" style="max-width:140px"><option value="">All roles</option>${['user', 'manager', 'admin'].map((x) => html`<option ${uState.role === x ? 'selected' : ''}>${x}</option>`)}</select><select name="status" style="max-width:140px"><option value="">Any status</option>${['active', 'suspended'].map((x) => html`<option ${uState.status === x ? 'selected' : ''}>${x}</option>`)}</select><button class="btn sm">Filter</button></form>
  <div class="panel">${table(['ID', 'User', 'Role', 'Status', 'KYC', 'Balance', 'Manager', 'Refs', ''], r.users.map((u) => [u.id, html`<b>${u.name}</b><div class="muted small">${u.email}</div>`, u.role, badge(u.status), badge(u.kycStatus === 'none' ? 'pending' : u.kycStatus), fmt(u.balance), u.managerName || '–', u.referrals, html`<a class="btn sec sm" href="#/admin/users/${u.id}">Open</a>`]))}${pager(page, r.total, limit, 'users')}</div>`;
});
forms['user-filter'] = async (d) => { Object.assign(uState, d); CH.pageKeys.users = 1; await render({ soft: true }); };
actions['new-user'] = () => modal('Create user', html`<form data-form="create-user">${field('name', 'Name')}${field('email', 'Email', 'email', '', 'required')}${field('password', 'Password (min 8)', 'password', '', 'required minlength="8"')}<label>Role</label><select name="role"><option>user</option><option>manager</option><option>admin</option></select><div class="row end" style="margin-top:14px"><button class="btn">Create</button></div></form>`);
forms['create-user'] = async (d) => { const r = await post('/admin/users', d); closeModal(); toast('User created', 'ok'); location.hash = `#/admin/users/${r.id}`; };

const FEE_FIELDS = [['issue_fee_flat', 'Issue fee – flat $'], ['issue_fee_pct', 'Issue fee – %'], ['topup_fee_flat', 'Top-up fee – flat $'], ['topup_fee_pct', 'Top-up fee – %'], ['txn_fee_flat', 'Transaction fee – flat $'], ['txn_fee_pct', 'Transaction fee – %'], ['decline_fee_flat', 'Decline fee – $'], ['card_min_deposit', 'Card min. deposit $'], ['referral_pct', 'Referral commission %']];
route('/admin/users/:id', A, async ({ id }) => {
  const [d, mg, st] = await Promise.all([get(`/admin/users/${id}`), get('/admin/managers'), get('/admin/settings')]);
  const u = d.user; const ov = u.feeOverrides;
  return html`<div class="row"><a href="#/admin/users">← Users</a><span class="sp"></span>${badge(u.status)}</div><h1>${u.name} <span class="muted small">#${u.id} · ${u.email}</span></h1>
  <div class="grid g4" style="margin-bottom:14px">${stat('Balance', fmt(u.balance))}${stat('KYC', u.kycStatus)}${stat('Spend (30d)', fmt(d.summary.spend30))}${stat('Referred users', d.referrals)}</div>
  <div class="grid g2"><div class="panel"><h2>Account control</h2><form data-form="user-update" data-id="${u.id}">${field('name', 'Name', 'text', u.name)}<div class="form-grid"><div><label>Role</label><select name="role">${['user', 'manager', 'admin'].map((x) => html`<option ${u.role === x ? 'selected' : ''}>${x}</option>`)}</select></div><div><label>Status</label><select name="status">${['active', 'suspended'].map((x) => html`<option ${u.status === x ? 'selected' : ''}>${x}</option>`)}</select></div>
    <div><label>KYC status</label><select name="kycStatus">${['none', 'pending', 'approved', 'declined'].map((x) => html`<option ${u.kycStatus === x ? 'selected' : ''}>${x}</option>`)}</select></div><div><label>Account manager</label><select name="managerId"><option value="">— none —</option>${mg.managers.map((m) => html`<option value="${m.id}" ${u.managerId === m.id ? 'selected' : ''}>${m.name} (${m.users} users)</option>`)}</select></div></div>
    <div class="row end" style="margin-top:12px"><button class="btn">Save</button></div></form></div>
  <div class="panel"><h2>Fee overrides for this user</h2><p class="muted small">Leave blank to use the global/product value. Overrides win over everything.</p><form data-form="user-fees" data-id="${u.id}"><div class="form-grid">${FEE_FIELDS.map(([k, l]) => field(k, `${l} (global ${st.settings[k]})`, 'number', ov[k] ?? '', 'step="0.01" min="0"'))}</div><div class="row end" style="margin-top:12px"><button class="btn">Save overrides</button></div></form></div></div>
  <div class="grid g2"><div class="panel"><h2>Adjust balance</h2><form data-form="adjust" data-id="${u.id}">${field('amount', 'Amount (negative to debit)', 'number', '', 'step="0.01" required')}${field('note', 'Reason (required, visible to user)', 'text', '', 'required maxlength="200"')}<div class="row end" style="margin-top:12px"><button class="btn">Apply</button></div></form>
  <hr style="border:0;border-top:1px solid var(--line);margin:16px 0"><form data-form="reset-pw" data-id="${u.id}">${field('password', 'Set new password', 'password', '', 'minlength="8" required')}<div class="row end" style="margin-top:12px"><button class="btn sec">Reset password</button></div></form></div>
  <div class="panel"><h2>KYC</h2>${d.kyc ? html`<div class="row">${badge(d.kyc.status)}<span class="muted small">${date(d.kyc.createdAt)}</span></div><div class="kv" style="margin:10px 0">${Object.entries(d.kyc.data).map(([k, v]) => html`<div>${k}</div><div>${v}</div>`)}</div><a href="#/admin/kyc?status=${d.kyc.status}" class="btn sec sm">Open in KYC queue</a>` : html`<div class="empty">Not submitted</div>`}
  <h2 style="margin-top:16px">Cards</h2>${table(['Card', 'Product', 'Status', 'Balance'], d.cards.map((c) => [html`${c.name || 'Card'} …${c.last4}`, c.product_code, badge(c.status), fmt(c.balance)]), 'No cards')}</div></div>
  <div class="panel"><h2>Latest wallet activity</h2>${table(['When', 'Type', 'Details', 'Amount', 'Balance'], d.ledger.map((l) => [date(l.created_at), label(l.type), l.note, signed(l.amount), fmt(l.balance_after)]), 'No activity')}</div>`;
});
forms['user-update'] = async (d, f) => { const b = { name: d.name, role: d.role, status: d.status, kycStatus: d.kycStatus, managerId: d.managerId ? Number(d.managerId) : null }; await patch(`/admin/users/${f.dataset.id}`, b); toast('Saved', 'ok'); await render({ soft: true }); };
forms['user-fees'] = async (d, f) => { await patch(`/admin/users/${f.dataset.id}`, { feeOverrides: d }); toast('Overrides saved', 'ok'); await render({ soft: true }); };
forms.adjust = async (d, f) => { if (!await confirmBox(`Apply ${fmt(Number(d.amount))} to this user's balance?`)) return; const r = await post(`/admin/users/${f.dataset.id}/adjust`, d); toast('New balance ' + fmt(r.balance), 'ok'); await render({ soft: true }); };
forms['reset-pw'] = async (d, f) => { await post(`/admin/users/${f.dataset.id}/reset-password`, d); f.reset(); toast('Password reset', 'ok'); };
// the PATCH helper in app.js is exposed via CH.patch
// ---------- KYC queue ----------
route('/admin/kyc', A, async (_, q) => {
  const status = q.status || 'pending';
  const { items } = await get('/admin/kyc?status=' + status);
  return html`<h1>KYC queue</h1><div class="tabs">${['pending', 'approved', 'declined'].map((s) => html`<a href="#/admin/kyc?status=${s}" class="${status === s ? 'on' : ''}">${s}</a>`)}</div>
  ${items.length ? items.map((k) => html`<div class="panel"><div class="row"><b class="sp">${k.name} <span class="muted">${k.email}</span></b>${badge(k.status)}<span class="muted small">${date(k.created_at)}</span></div>
  <div class="grid g2" style="margin-top:10px"><div class="kv">${Object.entries(k.data).map(([a, b]) => html`<div>${a}</div><div>${b}</div>`)}</div>
  <div class="row"><a href="/api/kyc/${k.id}/file/front" target="_blank"><img class="kyc-img" alt="front" src="/api/kyc/${k.id}/file/front" style="max-height:140px"></a><a href="/api/kyc/${k.id}/file/selfie" target="_blank"><img class="kyc-img" alt="selfie" src="/api/kyc/${k.id}/file/selfie" style="max-height:140px"></a></div></div>
  ${k.reason ? html`<div class="alert err small">Reason: ${k.reason}</div>` : ''}
  ${k.status === 'pending' ? html`<div class="row end"><button class="btn danger sm" data-action="kyc-decline" data-id="${k.id}">Decline…</button><button class="btn ok sm" data-action="kyc-approve" data-id="${k.id}">Approve</button></div>` : html`<div class="row end"><button class="btn sec sm" data-action="kyc-approve" data-id="${k.id}">Mark approved</button><button class="btn sec sm" data-action="kyc-decline" data-id="${k.id}">Mark declined…</button></div>`}</div>`) : html`<div class="panel empty">Nothing ${status}</div>`}`;
}, ADMIN_ONLY_LIVE);
actions['kyc-approve'] = async ({ id }) => { await put(`/admin/kyc/${id}`, { status: 'approved' }); toast('Approved', 'ok'); await render({ soft: true }); };
actions['kyc-decline'] = ({ id }) => modal('Decline KYC', html`<form data-form="kyc-decline" data-id="${id}">${field('reason', 'Reason shown to the user', 'text', '', 'required maxlength="300"')}<div class="row end" style="margin-top:12px"><button class="btn danger">Decline</button></div></form>`);
forms['kyc-decline'] = async (d, f) => { await put(`/admin/kyc/${f.dataset.id}`, { status: 'declined', reason: d.reason }); closeModal(); toast('Declined', 'ok'); await render({ soft: true }); };

// ---------- cards ----------
const cState = { q: '', status: '' };
route('/admin/cards', A, async () => {
  const { cards } = await get('/admin/cards?' + qstr({ ...cState, limit: 100 }));
  return html`<h1>All cards</h1><form class="panel row" data-form="card-filter"><input name="q" placeholder="Email, card name, last 4" value="${cState.q}" style="max-width:260px"><select name="status" style="max-width:150px"><option value="">Any status</option>${['pending', 'active', 'frozen', 'blocking', 'blocked', 'declined'].map((x) => html`<option ${cState.status === x ? 'selected' : ''}>${x}</option>`)}</select><button class="btn sm">Filter</button></form>
  <div class="panel">${table(['ID', 'User', 'Card', 'Product', 'Status', 'Balance', ''], cards.map((c) => [c.id, html`<a href="#/admin/users/${c.user_id}">${c.email}</a>`, `${c.name || 'Card'} …${c.last4}`, c.product_code, badge(c.status), fmt(c.balance), ['active', 'frozen'].includes(c.status) ? html`<button class="btn sec sm" data-action="admin-card" data-op="${c.status === 'frozen' ? 'unfreeze' : 'freeze'}" data-id="${c.id}">${c.status === 'frozen' ? 'Unfreeze' : 'Freeze'}</button> <button class="btn danger sm" data-action="admin-card" data-op="block" data-id="${c.id}">Block</button>` : '']))}</div>`;
}, ADMIN_ONLY_LIVE);
forms['card-filter'] = async (d) => { Object.assign(cState, d); await render({ soft: true }); };
actions['admin-card'] = async ({ op, id }) => { if (op === 'block' && !await confirmBox('Permanently block this card? The balance returns to the user.', 'Block', true)) return; await post(`/admin/cards/${op}/${id}`); toast('Done', 'ok'); await render({ soft: true }); };

// ---------- transactions ----------
route('/admin/tx', A, () => CH.txView('/admin'), ADMIN_ONLY_LIVE);

// ---------- fees & limits ----------
const FEE_SECTIONS = [
  ['Card issue fee', [['issue_fee_flat', 'Flat fee ($)'], ['issue_fee_pct', 'Percent of deposit (%)']]],
  ['Top-up fee', [['topup_fee_flat', 'Flat fee ($)'], ['topup_fee_pct', 'Percent of top-up (%)']]],
  ['Transaction fee (on every successful card payment)', [['txn_fee_flat', 'Flat fee ($)'], ['txn_fee_pct', 'Percent of payment (%)']]],
  ['Decline fee (on every declined authorization)', [['decline_fee_flat', 'Flat fee ($)']]],
  ['Minimum amounts & limits', [['card_min_deposit', 'Card minimum deposit ($)'], ['wallet_min_deposit', 'Wallet minimum crypto deposit ($)'], ['max_cards_per_user', 'Max open cards per user']]],
  ['Referral program', [['referral_pct', 'Commission (% of referred user fees)']]],
];
const SWITCHES = [['feature_cards', 'Card issuing'], ['feature_wallet', 'Crypto wallet deposits'], ['feature_referrals', 'Referral system'], ['feature_kyc', 'KYC module'], ['feature_manager', 'Account manager module'], ['kyc_required_for_cards', 'Require approved KYC to issue cards'], ['registration_open', 'Open registration'], ['maintenance_mode', 'Maintenance mode (blocks all non-admins)']];
route('/admin/fees', A, async () => {
  const { settings: s } = await get('/admin/settings');
  return html`<h1>Fees, limits & feature control</h1><p class="muted">Global defaults. Per-product and per-user overrides take priority (see Card products and each user page).</p>
  <form data-form="settings"><div class="grid g2">${FEE_SECTIONS.map(([t, fs]) => html`<div class="panel"><h2>${t}</h2><div class="form-grid">${fs.map(([k, l]) => field(k, l, 'number', s[k], 'step="0.01" min="0" required'))}</div></div>`)}
  <div class="panel"><h2>Feature switches</h2>${SWITCHES.map(([k, l]) => html`<label class="check"><input type="checkbox" name="${k}" ${s[k] ? 'checked' : ''}> ${l}</label>`)}<h2 style="margin-top:16px">Platform</h2>${field('site_name', 'Site name', 'text', s.site_name)}
  <label>Provider mode</label><select name="provider_mode"><option value="mock" ${s.provider_mode === 'mock' ? 'selected' : ''}>Simulator (no real money)</option><option value="live" ${s.provider_mode === 'live' ? 'selected' : ''}>Live (real CardsPro + Capitalist)</option></select></div></div>
  <div class="row end"><button class="btn">Save all settings</button></div></form>`;
});
forms.settings = async (d, f) => {
  const body = {};
  for (const [, fs] of FEE_SECTIONS) for (const [k] of fs) body[k] = d[k];
  for (const [k] of SWITCHES) body[k] = f.elements[k].checked ? 1 : 0;
  body.site_name = d.site_name; body.provider_mode = d.provider_mode;
  if (body.provider_mode === 'live' && !await confirmBox('Live mode uses real money and your real API credentials. Continue?', 'Go live', true)) return;
  await put('/admin/settings', body); S.cfg = null; toast('Settings saved', 'ok'); await render({ soft: true });
};

// ---------- products ----------
route('/admin/products', A, async () => {
  const { products } = await get('/admin/products');
  return html`<h1>Card products</h1><p class="muted">Pulled from the card provider. Override fees and minimum deposit per product, rename it, or hide it from users.</p>
  ${products.map((p) => html`<form class="panel" data-form="product" data-code="${p.code}"><div class="row"><b class="sp">${p.code}</b><span class="muted small">provider limits: issue ${fmt(p.issueMin)}–${fmt(p.issueMax)} · top-up ${fmt(p.topUpMin)}–${fmt(p.topUpMax)}${p.kycSort ? ' · KYC ' + p.kycSort : ''}</span><label class="check" style="margin:0"><input type="checkbox" name="enabled" ${p.enabled ? 'checked' : ''}> Enabled</label></div>
  <div class="form-grid">${field('label', 'Display name', 'text', p.label === p.code ? '' : p.label)}${field('issueFeeFlat', 'Issue fee flat $', 'number', '', `step="0.01" min="0" placeholder="${p.issueFeeFlat}"`)}${field('issueFeePct', 'Issue fee %', 'number', '', `step="0.01" min="0" placeholder="${p.issueFeePct}"`)}${field('topupFeeFlat', 'Top-up fee flat $', 'number', '', `step="0.01" min="0" placeholder="${p.topupFeeFlat}"`)}${field('topupFeePct', 'Top-up fee %', 'number', '', `step="0.01" min="0" placeholder="${p.topupFeePct}"`)}${field('minDeposit', 'Min. deposit $', 'number', '', `step="0.01" min="0" placeholder="${p.minDeposit}"`)}</div>
  <div class="row end" style="margin-top:10px"><button class="btn sm">Save product</button></div></form>`)}`;
});
// fields left blank mean "inherit global"; we re-read the saved overrides to prefill them
forms.product = async (d, f) => { await put(`/admin/products/${encodeURIComponent(f.dataset.code)}`, { ...d, enabled: f.elements.enabled.checked }); toast('Product saved', 'ok'); await render({ soft: true }); };

// ---------- referrals ----------
route('/admin/referrals', A, async () => {
  const r = await get('/admin/referrals');
  return html`<h1>Referral control</h1><div class="grid g3" style="margin-bottom:16px">${stat('Program', r.enabled ? 'Enabled' : 'Disabled')}${stat('Default commission', r.pct + '%')}${stat('Commissions paid', fmt(r.totals.paid), `${r.totals.n} payouts`)}</div>
  <div class="panel row"><span class="sp muted">Change the default rate or switch the program on/off under <a href="#/admin/fees">Fees & limits</a>. Set a custom rate for one user on their user page.</span></div>
  <div class="grid g2"><div class="panel"><h2>Top referrers</h2>${table(['User', 'Code', 'Invited', 'Earned'], r.top.map((u) => [html`<a href="#/admin/users/${u.id}">${u.email}</a>`, raw(`<span class="mono">${esc(u.referral_code)}</span>`), u.referred, fmt(u.earned)]), 'No referrals yet')}</div>
  <div class="panel"><h2>Recent payouts</h2>${table(['When', 'Referrer', 'From', 'Fee', 'Paid'], r.recent.map((x) => [date(x.created_at), x.referrer, x.referred, x.fee_type, fmt(x.commission)]), 'None yet')}</div></div>`;
}, ADMIN_ONLY_LIVE);

// ---------- crypto deposits ----------
route('/admin/wallet', A, async () => {
  const { deposits } = await get('/admin/deposits'); const c = await get('/admin/credentials');
  return html`<h1>Crypto wallet system</h1><p class="muted">Users receive a USDT (TRC-20) address from Capitalist's <span class="mono">depositAddressAutoUSDTt</span> endpoint. Incoming funds are auto-converted to USD on your Capitalist account and credited to the user here.</p>
  <div class="panel row"><div class="sp"><b>Receiving Capitalist account:</b> ${c.env.capitalist.account || html`<span class="neg">not set</span>`} <span class="muted small">(set under API credentials)</span></div><button class="btn sec sm" data-action="sync-all">Sync deposits now</button></div>
  <div class="panel">${table(['Created', 'User', 'Address', 'Amount', 'Status', 'Credited'], deposits.map((d) => [date(d.created_at), d.email, raw(`<span class="mono small">${esc(d.address)}</span>`), d.amount != null ? fmt(d.amount) : '–', badge(d.status), d.credited_at ? date(d.credited_at) : '']), 'No deposit addresses issued yet')}</div>`;
}, ADMIN_ONLY_LIVE);
actions['sync-all'] = async () => { const r = await post('/admin/deposits/sync'); toast(`${r.credited} deposit(s) credited`, 'ok'); await render({ soft: true }); };

// ---------- API credentials ----------
route('/admin/api', A, async () => {
  const c = await get('/admin/credentials');
  const env = (n, e) => html`<div class="panel"><h2>${n} <span class="muted small">(from server .env)</span></h2><div class="kv"><div>Configured</div><div>${e.configured ? '✅ yes' : '❌ no'}</div><div>API key</div><div class="mono">${e.key || '–'}</div><div>Base URL</div><div class="mono small">${e.base}</div>${e.account !== undefined ? html`<div>Account</div><div class="mono">${e.account || '–'}</div>` : ''}</div><div class="row" style="margin-top:10px"><button class="btn sec sm" data-action="test-api" data-p="${n === 'CardsPro' ? 'cardspro' : 'capitalist'}">Test connection</button></div></div>`;
  return html`<h1>API credentials</h1><div class="alert info">Secrets are encrypted at rest and never shown again after saving. Credentials saved here override the .env values. The current mode is <b>${c.mode === 'live' ? 'live' : 'simulator'}</b> – change it under Fees & limits.</div>
  <div class="grid g2">${env('CardsPro', c.env.cardspro)}${env('Capitalist', c.env.capitalist)}</div>
  <form class="panel" data-form="add-cred"><h2>Add / rotate credentials</h2><div class="form-grid"><div><label>Provider</label><select name="provider"><option value="cardspro">CardsPro (cards)</option><option value="capitalist">Capitalist (USDT wallet)</option></select></div>${field('label', 'Label', 'text', '', 'placeholder="production"')}${field('apiKey', 'API key', 'text', '', 'required autocomplete="off"')}${field('apiSecret', 'API secret', 'password', '', 'required autocomplete="new-password"')}${field('baseUrl', 'Base URL (optional)', 'text', '', 'placeholder="https://…"')}${field('account', 'Capitalist receiving account (e.g. U0123504)', 'text', '', 'autocomplete="off"')}</div><div class="row end" style="margin-top:12px"><button class="btn">Save & activate</button></div></form>
  <div class="panel"><h2>Saved credentials</h2>${table(['Provider', 'Label', 'Key', 'Account', 'Active', 'Added', ''], c.credentials.map((x) => [x.provider, x.label, raw(`<span class="mono">${esc(x.api_key)}</span>`), x.account || '–', x.active ? badge('active') : '', date(x.created_at), html`${x.active ? '' : html`<button class="btn sec sm" data-action="cred-activate" data-id="${x.id}">Activate</button> `}<button class="btn danger sm" data-action="cred-delete" data-id="${x.id}">Delete</button>`]), 'None saved – using .env values')}</div>
  <div class="panel"><h2>Webhook URLs</h2><p class="muted small">Give these to your providers. The secret part is your WEBHOOK_SECRET.</p><div class="addr small">${location.origin}/api/webhooks/cardspro/&lt;WEBHOOK_SECRET&gt;<br>${location.origin}/api/webhooks/capitalist/&lt;WEBHOOK_SECRET&gt;</div></div>`;
});
forms['add-cred'] = async (d, f) => { await post('/admin/credentials', d); f.reset(); toast('Credentials saved and activated', 'ok'); await render({ soft: true }); };
actions['cred-activate'] = async ({ id }) => { await post(`/admin/credentials/${id}/activate`); await render({ soft: true }); };
actions['cred-delete'] = async ({ id }) => { if (await confirmBox('Delete these credentials?', 'Delete', true)) { await del(`/admin/credentials/${id}`); await render({ soft: true }); } };
actions['test-api'] = async ({ p }) => {
  const r = await post(`/admin/credentials/test/${p}`);
  modal('Connection test', html`<div class="alert ${r.ok ? 'info' : 'err'}">${r.ok ? '✅ Connected – ' + r.sample : '❌ ' + r.error}</div><div class="muted small">Credentials source: ${r.source} · ${r.base}</div>`);
};

// ---------- pending ops + audit ----------
route('/admin/ops', A, async () => {
  const { ops } = await get('/admin/ops');
  return html`<h1>Pending card operations</h1><p class="muted">Operations the provider has not confirmed yet. If one is stuck after you verified its real outcome with the provider, settle it here. Declining refunds the user automatically.</p>
  <div class="panel">${table(['ID', 'User', 'Type', 'Amount', 'Fee', 'Request', 'Created', ''], ops.map((o) => [o.id, o.email, o.type, fmt(o.amount), fmt(o.fee), raw(`<span class="mono small">${esc(o.request_id)}</span>`), date(o.created_at), html`<button class="btn danger sm" data-action="op-decline" data-id="${o.id}">Decline + refund</button> <button class="btn ok sm" data-action="op-exec" data-id="${o.id}" data-type="${o.type}">Mark executed</button>`]), 'Nothing pending 🎉')}</div>`;
}, ADMIN_ONLY_LIVE);
actions['op-decline'] = async ({ id }) => { if (await confirmBox('Decline this operation and refund the user?', 'Decline', true)) { await post(`/admin/ops/${id}/resolve`, { status: 'DECLINED' }); toast('Declined', 'ok'); await render({ soft: true }); } };
actions['op-exec'] = ({ id, type }) => type === 'ISSUE'
  ? modal('Mark issue as executed', html`<form data-form="op-exec" data-id="${id}">${field('san', 'Card id (san) from the provider', 'text', '', 'required')}<div class="row end" style="margin-top:12px"><button class="btn ok">Confirm</button></div></form>`)
  : confirmBox('Mark executed? Make sure the provider really processed it.', 'Mark executed').then(async (y) => { if (y) { await post(`/admin/ops/${id}/resolve`, { status: 'EXECUTED' }); await render({ soft: true }); } });
forms['op-exec'] = async (d, f) => { await post(`/admin/ops/${f.dataset.id}/resolve`, { status: 'EXECUTED', san: d.san }); closeModal(); await render({ soft: true }); };

route('/admin/audit', A, async () => {
  const { log } = await get('/admin/audit');
  return html`<h1>Audit log</h1><div class="panel">${table(['When', 'Actor', 'Action', 'Detail'], log.map((l) => [date(l.created_at), l.actor || 'system', l.action, raw(`<span class="mono small">${esc(l.detail)}</span>`)]))}</div>`;
});

// ================= Account manager panel =================
route('/staff', STAFF, async () => {
  const [o, u] = await Promise.all([get('/manager/overview'), get('/manager/users?limit=100')]);
  const m = S.me;
  return html`<h1>${m.role === 'admin' ? 'All users – manager view' : 'My users'}</h1>
  <div class="grid g4" style="margin-bottom:14px">${stat('Users', o.users)}${stat('Pending KYC', o.pendingKyc)}${stat('Their balances', fmt(o.totalBalance))}${stat('Their spend (30d)', fmt(o.spend30), `${o.unread} awaiting reply`)}</div>
  <div class="panel"><div class="row"><h2 class="sp">Customers</h2><a class="btn sec sm" href="#/staff/profile">Edit my contact card</a></div>${table(['User', 'KYC', 'Balance', 'Cards', 'Spend 30d', 'Last message', ''], u.users.map((x) => [html`<b>${x.name}</b><div class="muted small">${x.email}</div>`, badge(x.kycStatus === 'none' ? 'pending' : x.kycStatus), fmt(x.balance), x.cards, fmt(x.spend30), x.lastMessage ? date(x.lastMessage) : '–', html`<a class="btn sm" href="#/staff/users/${x.id}">Open</a>`]), 'No users are assigned to you yet')}</div>`;
}, { live: true });

route('/staff/users/:id', STAFF, async ({ id }) => {
  const [d, msg, tx] = await Promise.all([get(`/manager/users/${id}`), get(`/manager/users/${id}/messages`), get(`/manager/users/${id}/transactions`)]);
  const u = d.user; const s = d.summary;
  return html`<div class="row"><a href="#/staff">← My users</a><span class="sp"></span>${badge(u.status)}</div><h1>${u.name} <span class="muted small">${u.email}</span></h1>
  <div class="grid g4" style="margin-bottom:14px">${stat('Balance', fmt(u.balance))}${stat('KYC', u.kycStatus)}${stat('Spend (30d)', fmt(s.spend30), `${s.declines30} declines`)}${stat('Fees (30d)', fmt(s.fees30))}</div>
  <div class="grid g2"><div class="panel"><h2>Conversation</h2><div class="chat" id="chat">${msg.messages.length ? msg.messages.map((x) => html`<div class="msg ${x.from_staff ? 'me' : 'staff'}">${x.body}<small>${x.from_staff ? 'You' : u.name} · ${date(x.created_at)}</small></div>`) : html`<div class="muted">No messages yet.</div>`}</div>
  <form class="row" data-form="staff-msg" data-id="${u.id}"><input name="body" placeholder="Reply…" required maxlength="2000" style="flex:1"><button class="btn">Send</button></form></div>
  <div class="panel"><h2>Private notes</h2><form class="row" data-form="staff-note" data-id="${u.id}"><input name="body" placeholder="Add a note (only staff see this)" required maxlength="2000" style="flex:1"><button class="btn sec">Add</button></form><div style="margin-top:10px">${d.notes.length ? d.notes.map((n) => html`<div class="small" style="margin-bottom:8px"><b>${n.author}</b> <span class="muted">${date(n.created_at)}</span><div>${n.body}</div></div>`) : html`<div class="muted small">No notes.</div>`}</div></div></div>
  <div class="grid g2"><div class="panel"><h2>Cards</h2>${table(['Card', 'Product', 'Status', 'Balance'], d.cards.map((c) => [`${c.name || 'Card'} …${c.last4}`, c.product_code, badge(c.status), fmt(c.balance)]), 'No cards')}</div>
  <div class="panel"><h2>KYC</h2>${d.kyc ? html`<div class="row">${badge(d.kyc.status)}</div><div class="kv" style="margin:8px 0">${Object.entries(d.kyc.data).map(([k, v]) => html`<div>${k}</div><div>${v}</div>`)}</div><div class="row"><a href="/api/kyc/${d.kyc.id}/file/front" target="_blank"><img class="kyc-img" alt="doc" src="/api/kyc/${d.kyc.id}/file/front" style="max-height:110px"></a><a href="/api/kyc/${d.kyc.id}/file/selfie" target="_blank"><img class="kyc-img" alt="selfie" src="/api/kyc/${d.kyc.id}/file/selfie" style="max-height:110px"></a></div>` : html`<div class="empty">Not submitted</div>`}</div></div>
  <div class="grid g2"><div class="panel"><h2>Wallet activity</h2>${table(['When', 'Type', 'Amount'], tx.wallet.slice(0, 12).map((l) => [date(l.created_at), label(l.type), signed(l.amount)]), 'None')}</div><div class="panel"><h2>Card payments</h2>${table(['When', 'Type', 'Merchant', 'Amount'], tx.card.slice(0, 12).map((t) => [date(t.created_at), badge(t.type), t.merchant, fmt(t.bill)]), 'None')}</div></div>`;
}, { live: true });
forms['staff-msg'] = async (d, f) => { await post(`/manager/users/${f.dataset.id}/messages`, d); f.reset(); await render({ soft: true }); const c = $('#chat'); if (c) c.scrollTop = c.scrollHeight; };
forms['staff-note'] = async (d, f) => { await post(`/manager/users/${f.dataset.id}/notes`, d); f.reset(); await render({ soft: true }); };

route('/staff/profile', STAFF, async () => {
  const me = S.me;
  return html`<a href="#/staff">← Back</a><h1>My contact card</h1><p class="muted">Shown to every user assigned to you.</p><form class="panel" data-form="staff-profile" style="max-width:520px">${field('title', 'Job title', 'text', '', 'placeholder="Senior account manager"')}${field('telegram', 'Telegram', 'text', me.telegram)}${field('whatsapp', 'WhatsApp')}${field('phone', 'Phone', 'text', me.phone)}${field('hours', 'Working hours', 'text', '', 'placeholder="Mon–Fri 9:00–18:00 UTC"')}<div class="row end" style="margin-top:12px"><button class="btn">Save</button></div></form>`;
});
forms['staff-profile'] = async (d) => { await put('/manager/profile', d); toast('Saved', 'ok'); };
})();
