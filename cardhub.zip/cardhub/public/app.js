/* CardHub frontend core: helpers, router, auth, user pages. Staff/admin pages live in admin.js */
(() => {
'use strict';
const CH = window.CH = { state: { me: null, manager: null, cfg: null, feed: [], live: false }, routes: [], forms: {}, actions: {}, nav: {} };
const S = CH.state;

// ---------- safe templating: everything interpolated is HTML-escaped unless wrapped by raw()/html`` ----------
class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const val = (v) => (v instanceof Raw ? v.s : Array.isArray(v) ? v.map(val).join('') : esc(v));
const html = (strs, ...vals) => new Raw(strs.reduce((o, s, i) => o + s + (i < vals.length ? val(vals[i]) : ''), ''));
const raw = (s) => new Raw(s);
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
Object.assign(CH, { esc, html, raw, $, $$, val });

const fmt = (n) => (n < 0 ? '-' : '') + '$' + Math.abs(Number(n || 0)).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const signed = (n) => html`<span class="${n >= 0 ? 'pos' : 'neg'}">${n >= 0 ? '+' : ''}${fmt(n)}</span>`;
const date = (s) => {
  if (!s) return '';
  const d = new Date(/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/.test(s) ? s.replace(' ', 'T') + 'Z' : s);
  return Number.isNaN(d.getTime()) ? s : d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
};
const badge = (s) => html`<span class="badge b-${s}">${String(s).replace(/_/g, ' ')}</span>`;
const LABELS = { deposit: 'Deposit', card_fund: 'Card funding', card_topup: 'Card top-up', card_withdraw: 'Card withdrawal', card_release: 'Released from card', referral: 'Referral commission', refund: 'Refund', fee_issue: 'Issue fee', fee_topup: 'Top-up fee', fee_txn: 'Transaction fee', fee_decline: 'Decline fee', admin_credit: 'Admin credit', admin_debit: 'Admin debit' };
const label = (t) => LABELS[t] || String(t).replace(/_/g, ' ');
Object.assign(CH, { fmt, signed, date, badge, label });

// ---------- API ----------
async function api(method, path, body) {
  const res = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json' }, body: method === 'GET' ? undefined : JSON.stringify(body ?? {}) });
  const text = await res.text(); let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    if (res.status === 401 && S.me) { S.me = null; stopStream(); location.hash = '#/login'; }
    throw new Error((data && data.error) || res.statusText);
  }
  return data;
}
CH.api = api;
const get = (p) => api('GET', p);
const post = (p, b) => api('POST', p, b);
Object.assign(CH, { get, post, put: (p, b) => api('PUT', p, b), patch: (p, b) => api('PATCH', p, b), del: (p) => api('DELETE', p) });
const qstr = (o) => Object.entries(o).filter(([, v]) => v !== '' && v != null).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&');
CH.qstr = qstr;

// ---------- toast / modal ----------
function toast(msg, kind = '') {
  const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg;
  $('#toasts').appendChild(t); setTimeout(() => t.remove(), kind === 'err' ? 6000 : 3500);
}
function modal(title, body) {
  $('#modal-root').innerHTML = html`<div class="overlay" data-action="close-overlay"><div class="modal" role="dialog" aria-modal="true"><div class="row"><h2 class="sp">${title}</h2><button class="btn sec sm" data-action="close">✕</button></div>${body}</div></div>`.s;
}
const closeModal = () => { $('#modal-root').innerHTML = ''; };
function confirmBox(message, okLabel = 'Confirm', danger = false) {
  return new Promise((resolve) => {
    modal('Please confirm', html`<p>${message}</p><div class="row end"><button class="btn sec" data-action="confirm-no">Cancel</button><button class="btn ${danger ? 'danger' : ''}" data-action="confirm-yes">${okLabel}</button></div>`);
    CH._confirm = (v) => { closeModal(); resolve(v); };
  });
}
Object.assign(CH, { toast, modal, closeModal, confirmBox });

// ---------- UI pieces ----------
function table(headers, rows, empty = 'Nothing here yet') {
  if (!rows.length) return html`<div class="empty">${empty}</div>`;
  return html`<div class="scroll"><table><thead><tr>${headers.map((h) => html`<th>${h}</th>`)}</tr></thead><tbody>${rows.map((r) => html`<tr>${r.map((c) => html`<td>${c}</td>`)}</tr>`)}</tbody></table></div>`;
}
const stat = (l, v, s = '') => html`<div class="stat"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div></div>`;
function cardVisual(c) {
  const exp = c.expMonth ? `${String(c.expMonth).padStart(2, '0')}/${String(c.expYear).slice(-2)}` : '••/••';
  return html`<div class="vcard ${c.status}"><div class="t"><b>${c.name || 'Virtual card'}</b><span>${(c.brand || 'VISA')}</span></div><div class="n">•••• •••• •••• ${c.last4 || '••••'}</div><div class="t"><span>${exp}</span><span>${c.status.toUpperCase()}</span></div></div>`;
}
function chart(labels, series) {
  const W = 640; const H = 180; const P = 28;
  const max = Math.max(1, ...series.flatMap((s) => s.values));
  const x = (i) => P + (i * (W - P * 1.5)) / Math.max(labels.length - 1, 1);
  const y = (v) => H - 22 - (v / max) * (H - 40);
  const lines = series.map((s) => {
    const pts = s.values.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
    return `<polyline fill="none" stroke="${s.color}" stroke-width="2.5" stroke-linejoin="round" points="${pts}"/>` + s.values.map((v, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(v).toFixed(1)}" r="3" fill="${s.color}"><title>${esc(s.name)} ${esc(labels[i])}: ${fmt(v)}</title></circle>`).join('');
  }).join('');
  const grid = [0, 0.5, 1].map((f) => `<line x1="${P}" x2="${W - 8}" y1="${y(max * f)}" y2="${y(max * f)}" stroke="#243049" stroke-dasharray="3 4"/><text x="2" y="${y(max * f) + 4}" fill="#8d9bb8" font-size="10">${Math.round(max * f)}</text>`).join('');
  return html`<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img">${raw(grid + lines)}<text x="${P}" y="${H - 4}" fill="#8d9bb8" font-size="10">${labels[0].slice(5)}</text><text x="${W - 40}" y="${H - 4}" fill="#8d9bb8" font-size="10">${labels[labels.length - 1].slice(5)}</text></svg><div class="legend">${series.map((s) => raw(`<span><i style="background:${s.color}"></i>${esc(s.name)}</span>`))}</div>`;
}
function pager(page, total, limit, key) {
  const pages = Math.max(1, Math.ceil(total / limit));
  return html`<div class="pager"><span class="muted small">${total} result(s) · page ${page}/${pages}</span><button class="btn sec sm" data-action="page" data-key="${key}" data-to="${page - 1}" ${page <= 1 ? 'disabled' : ''}>‹ Prev</button><button class="btn sec sm" data-action="page" data-key="${key}" data-to="${page + 1}" ${page >= pages ? 'disabled' : ''}>Next ›</button></div>`;
}
Object.assign(CH, { table, stat, cardVisual, chart, pager });
const field = (name, lbl, type = 'text', v = '', extra = '') => html`<label>${lbl}</label><input name="${name}" type="${type}" value="${v}" ${raw(extra)}>`;
CH.field = field;

// ---------- router ----------
function route(pattern, roles, handler, opts = {}) {
  const keys = []; const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  CH.routes.push({ re, keys, roles, handler, ...opts });
}
CH.route = route;
const home = () => (S.me.role === 'admin' ? '/admin' : S.me.role === 'manager' ? '/staff' : '/dashboard');
let current = null;

function navItems() {
  const f = S.cfg.features; const r = S.me.role;
  const a = (to, icon, t) => ({ to, icon, t });
  if (r === 'admin') return [
    { sec: 'Admin' }, a('/admin', '📊', 'Live dashboard'), a('/admin/users', '👥', 'Users'), a('/admin/kyc', '🪪', 'KYC queue'), a('/admin/cards', '💳', 'Cards'),
    a('/admin/tx', '🧾', 'Transactions'), a('/admin/fees', '⚙️', 'Fees & limits'), a('/admin/products', '🏷️', 'Card products'), a('/admin/referrals', '🎁', 'Referrals'),
    a('/admin/wallet', '🪙', 'Crypto deposits'), a('/admin/api', '🔑', 'API credentials'), a('/admin/ops', '⏳', 'Pending operations'), a('/admin/audit', '📜', 'Audit log'),
    { sec: 'Staff' }, a('/staff', '🧑‍💼', 'Manager panel'), { sec: 'Account' }, a('/profile', '🙍', 'Profile'),
  ];
  if (r === 'manager') return [{ sec: 'Account manager' }, a('/staff', '🧑‍💼', 'Overview & my users'), a('/profile', '🙍', 'Profile')];
  return [
    a('/dashboard', '📊', 'Dashboard'), f.cards && a('/cards', '💳', 'Cards'), f.wallet && a('/wallet', '🪙', 'Wallet'), a('/transactions', '🧾', 'Transactions'),
    f.kyc && a('/kyc', '🪪', 'Verification (KYC)'), f.referrals && a('/referrals', '🎁', 'Referrals'), f.manager && a('/manager', '🧑‍💼', 'My account manager'), a('/profile', '🙍', 'Profile'),
  ].filter(Boolean);
}

function shell(path, content) {
  const items = navItems();
  const links = items.map((i) => (i.sec ? html`<div class="sec">${i.sec}</div>` : html`<a href="#${i.to}" class="${path === i.to || (i.to !== '/admin' && i.to !== '/staff' && path.startsWith(i.to + '/')) ? 'on' : ''}"><span>${i.icon}</span>${i.t}</a>`));
  return html`<div class="shell"><aside class="side" id="side"><div class="brand"><i></i>${S.cfg.siteName}</div><nav class="nav">${links}</nav></aside>
  <main class="main"><div class="top"><div class="row"><button class="btn sec sm menu-btn" data-action="menu">☰</button>${S.cfg.mock ? html`<span class="pill" title="Built-in simulator: no real money moves">🧪 Simulator mode</span>` : html`<span class="pill">🟢 Live providers</span>`}</div>
  <div class="who"><span class="pill"><span class="dot ${S.live ? 'on' : ''}" id="livedot"></span>${S.live ? 'Live' : 'Offline'}</span>${S.me.role === 'user' ? html`<a class="pill" href="#/wallet">Balance <b id="topbal">${fmt(S.me.balance)}</b></a>` : ''}<span class="muted">${S.me.name}</span><button class="btn sec sm" data-action="logout">Log out</button></div></div>
  <div id="view">${content}</div></main></div>`;
}

async function refreshMe() {
  const r = await get('/auth/me'); S.me = r.user; S.manager = r.manager;
}

async function render({ soft = false } = {}) {
  const hash = location.hash.replace(/^#/, '') || '/';
  const [path, query] = hash.split('?');
  const q = Object.fromEntries(new URLSearchParams(query || ''));
  if (!S.cfg) S.cfg = await get('/auth/public-config');
  if (!S.me) {
    try { await refreshMe(); startStream(); } catch { /* not logged in */ }
  }
  const app = $('#app');
  if (!S.me) {
    if (path !== '/signup') { app.innerHTML = authPage('login', q).s; return; }
    app.innerHTML = authPage('signup', q).s; return;
  }
  if (!soft) { try { await refreshMe(); } catch { return; } }
  if (['/', '/login', '/signup'].includes(path)) { location.hash = '#' + home(); return; }
  const rt = CH.routes.find((r) => r.re.test(path));
  if (!rt || !rt.roles.includes(S.me.role)) { location.hash = '#' + home(); return; }
  const m = rt.re.exec(path); const params = Object.fromEntries(rt.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
  current = { rt, params, q, path };
  let content;
  try { content = await rt.handler(params, q); } catch (e) { content = html`<div class="alert err">${e.message}</div>`; }
  if (soft && $('#view')) { $('#view').innerHTML = content.s; const tb = $('#topbal'); if (tb) tb.textContent = fmt(S.me.balance); return; }
  app.innerHTML = shell(path, content).s;
  window.scrollTo(0, 0);
}
CH.render = render;
window.addEventListener('hashchange', () => render());

// ---------- live stream ----------
let es = null; let refreshTimer = null;
function startStream() {
  if (es) return;
  es = new EventSource('/api/stream');
  es.addEventListener('hello', () => { S.live = true; const d = $('#livedot'); if (d) d.classList.add('on'); });
  es.onerror = () => { S.live = false; const d = $('#livedot'); if (d) d.classList.remove('on'); };
  const msgs = {
    ledger: (e) => (e.data.amount >= 0 ? `Balance +${fmt(e.data.amount)}` : `Balance ${fmt(e.data.amount)}`),
    deposit: (e) => `Deposit received: ${fmt(e.data.amount)}`, card_op: (e) => `Card ${String(e.data.type).toLowerCase()} ${String(e.data.status).toLowerCase()}`,
    card_tx: (e) => `Card ${e.data.type.replace(/_/g, ' ')}: ${fmt(e.data.amount)} ${e.data.merchant || ''}`, kyc: (e) => `KYC status: ${e.data.status || e.data.providerStatus}`,
    message: () => 'New message from your account manager', referral: (e) => `Referral commission +${fmt(e.data.commission)}`, otp: (e) => `3DS code for your card: ${e.data.code}`,
  };
  for (const t of Object.keys(msgs)) {
    es.addEventListener(t, (ev) => {
      const e = JSON.parse(ev.data);
      S.feed.unshift({ ...e, text: msgs[t](e) }); S.feed = S.feed.slice(0, 30);
      if (S.me?.role === 'user' && !(t === 'ledger')) toast(msgs[t](e), 'ok');
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(async () => {
        if (!current?.rt.live || /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || '') || $('#modal-root').children.length) return;
        try { await refreshMe(); await render({ soft: true }); } catch { /* ignore */ }
      }, 500);
    });
  }
}
function stopStream() { if (es) { es.close(); es = null; } S.live = false; }

// ---------- auth pages ----------
function authPage(mode, q) {
  const signup = mode === 'signup';
  return html`<div class="auth"><div class="box panel"><div class="brand"><i></i>${S.cfg.siteName}</div>
  <h1>${signup ? 'Create your account' : 'Welcome back'}</h1><p class="muted">${signup ? 'Virtual cards for ad spend, funded with USDT.' : 'Log in to manage your cards and wallet.'}</p>
  ${S.cfg.mock ? html`<div class="alert info small">Simulator mode is on – no real cards or money are involved.</div>` : ''}
  ${S.cfg.maintenance ? html`<div class="alert warn">The platform is under maintenance.</div>` : ''}
  <form data-form="${mode}" autocomplete="on">
    ${signup ? field('name', 'Full name', 'text', '', 'required autocomplete="name"') : ''}
    ${field('email', 'Email', 'email', '', 'required autocomplete="email"')}
    ${field('password', 'Password' + (signup ? ' (min 8 characters)' : ''), 'password', '', `required minlength="${signup ? 8 : 1}" autocomplete="${signup ? 'new-password' : 'current-password'}"`)}
    ${signup ? field('referralCode', 'Referral code (optional)', 'text', q.ref || '', 'autocomplete="off"') : ''}
    <div class="row end" style="margin-top:16px"><button class="btn" style="width:100%">${signup ? 'Sign up' : 'Log in'}</button></div>
  </form>
  <p class="muted small" style="margin-top:14px">${signup ? html`Already registered? <a href="#/login">Log in</a>` : S.cfg.registrationOpen ? html`New here? <a href="#/signup">Create an account</a>` : 'Registration is closed.'}</p></div></div>`;
}
CH.forms.login = async (d) => { await post('/auth/login', d); S.me = null; location.hash = '#/'; await render(); };
CH.forms.signup = async (d) => { await post('/auth/signup', d); S.me = null; location.hash = '#/'; await render(); };
CH.actions.logout = async () => { await post('/auth/logout'); S.me = null; stopStream(); location.hash = '#/login'; await render(); };

// ---------- user: dashboard ----------
route('/dashboard', ['user'], async () => {
  const [s, c] = await Promise.all([get('/reports/summary'), S.cfg.features.cards ? get('/cards') : { cards: [] }]);
  const active = s.cards.filter((x) => ['active', 'frozen'].includes(x.status));
  const onCards = active.reduce((a, x) => a + x.balance, 0);
  const kycNeeded = S.cfg.features.kyc && S.cfg.kycRequiredForCards && S.me.kycStatus !== 'approved';
  const rate = s.successful30 + s.declines30 ? Math.round((s.declines30 / (s.successful30 + s.declines30)) * 100) : 0;
  return html`<h1>Dashboard</h1><p class="muted">Real-time overview of your account.</p>
  ${kycNeeded ? html`<div class="alert warn">Identity verification is required before you can issue cards. <a href="#/kyc">${S.me.kycStatus === 'pending' ? 'Your KYC is under review' : S.me.kycStatus === 'declined' ? 'KYC declined – resubmit' : 'Start verification'}</a></div>` : ''}
  <div class="grid g4" style="margin-bottom:16px">${stat('Wallet balance', fmt(s.balance), 'available to spend')}${stat('Cards balance', fmt(onCards), `${active.length} active card(s)`)}${stat('Spend (30d)', fmt(s.spend30), `${s.successful30} successful payments`)}${stat('Fees paid (30d)', fmt(s.fees30), `decline rate ${rate}%`)}</div>
  <div class="grid g2"><div class="panel"><h2>Activity – last 14 days</h2>${chart(s.labels, [{ name: 'Card spend', color: '#5b8cff', values: s.spendSeries }, { name: 'Deposits', color: '#34d6a8', values: s.depositSeries }, { name: 'Fees', color: '#ffbe55', values: s.feeSeries }])}</div>
  <div class="panel"><h2>Top merchants (30d)</h2>${table(['Merchant', 'Payments', 'Total'], s.topMerchants.map((m) => [m.merchant, m.n, fmt(m.total)]), 'No spend yet')}</div></div>
  <div class="grid g2"><div class="panel"><div class="row"><h2 class="sp">Recent card activity</h2><a href="#/transactions">All</a></div>${table(['When', 'Type', 'Merchant', 'Amount'], s.recent.map((t) => [date(t.created_at), badge(t.type), t.merchant, fmt(t.amount)]), 'No card activity yet')}</div>
  <div class="panel"><h2>Quick actions</h2><div class="row"><a class="btn" href="#/wallet">Deposit USDT</a>${S.cfg.features.cards ? html`<a class="btn sec" href="#/cards/new">Issue a card</a>` : ''}${S.cfg.features.referrals ? html`<a class="btn sec" href="#/referrals">Invite & earn ${S.cfg.referralPct}%</a>` : ''}</div>
  <h3 style="margin-top:18px">Live feed</h3>${S.feed.length ? html`<div class="small">${S.feed.slice(0, 6).map((f) => html`<div>• ${f.text} <span class="muted">${new Date(f.at).toLocaleTimeString()}</span></div>`)}</div>` : html`<div class="muted small">Events appear here the moment they happen.</div>`}</div></div>`;
}, { live: true });

// ---------- user: cards ----------
route('/cards', ['user'], async () => {
  const { cards } = await get('/cards');
  return html`<div class="row"><div class="sp"><h1>Cards</h1><p class="muted">Virtual cards for Facebook, Google, TikTok and other ad platforms.</p></div><a class="btn" href="#/cards/new">+ Issue card</a></div>
  ${cards.length ? html`<div class="cards-grid">${cards.map((c) => html`<div class="cardbox"><a href="#/cards/${c.id}">${cardVisual(c)}<div class="meta"><b>${fmt(c.balance)}</b><span>${badge(c.status)}</span></div></a></div>`)}</div>` : html`<div class="panel empty">No cards yet. Issue your first card to start advertising.</div>`}`;
}, { live: true });

let productsCache = [];
route('/cards/new', ['user'], async () => {
  const { products } = await get('/cards/products'); productsCache = products;
  const kycNeeded = S.cfg.features.kyc && S.cfg.kycRequiredForCards && S.me.kycStatus !== 'approved';
  if (!products.length) return html`<h1>Issue a card</h1><div class="alert warn">No card products are available right now.</div>`;
  return html`<h1>Issue a card</h1><p class="muted">Wallet balance: <b>${fmt(S.me.balance)}</b></p>
  ${kycNeeded ? html`<div class="alert warn">You must <a href="#/kyc">complete KYC</a> before issuing cards.</div>` : ''}
  <form class="panel" data-form="issue" data-calc="issue">
    <h3>Choose a product</h3>
    ${products.map((p, i) => html`<label class="product"><input type="radio" name="productCode" value="${p.code}" ${i === 0 ? 'checked' : ''}><b>${p.label}</b> <span class="muted small">· deposit ${fmt(p.issueMin)} – ${fmt(p.issueMax)} · fee ${fmt(p.issueFeeFlat)} + ${p.issueFeePct}% · top-up fee ${p.topupFeePct}%${p.kycSort ? ' · needs provider KYC' : ''}</span></label>`)}
    <div class="form-grid">${field('amount', 'Initial deposit (USD)', 'number', '', 'required step="0.01" min="1" inputmode="decimal"')}${field('name', 'Card name (optional)', 'text', '', 'maxlength="32"')}${field('email', 'Cardholder email (if required)', 'email')}</div>
    <div class="form-grid">${field('firstName', 'First name (optional)')}${field('lastName', 'Last name (optional)')}</div>
    <div class="alert info" id="issue-summary" style="margin-top:14px">Enter an amount to see the total cost.</div>
    <button class="btn" ${kycNeeded ? 'disabled' : ''}>Issue card</button></form>`;
});
CH.calc = (form) => {
  if (form.dataset.calc !== 'issue') return;
  const code = new FormData(form).get('productCode'); const p = productsCache.find((x) => x.code === code); const a = Number(form.amount.value);
  const box = $('#issue-summary'); if (!p || !(a > 0)) { box.textContent = 'Enter an amount to see the total cost.'; return; }
  const fee = Math.round((p.issueFeeFlat + (a * p.issueFeePct) / 100) * 100) / 100;
  box.innerHTML = `Deposit <b>${fmt(a)}</b> + fee <b>${fmt(fee)}</b> = <b>${fmt(a + fee)}</b> from your wallet (${fmt(S.me.balance)}).` + (a < p.issueMin ? ` <span class="neg">Minimum is ${fmt(p.issueMin)}.</span>` : '') + (a + fee > S.me.balance ? ' <span class="neg">Insufficient balance.</span>' : '');
};
CH.forms.issue = async (d) => { const r = await post('/cards/issue', d); toast('Card requested – it will be active in a moment', 'ok'); location.hash = `#/cards/${r.card.id}`; };

route('/cards/:id', ['user'], async ({ id }) => {
  const { card: c, ops, transactions } = await get(`/cards/${id}`);
  const usable = ['active', 'frozen'].includes(c.status);
  return html`<div class="row"><a href="#/cards">← Cards</a><span class="sp"></span>${badge(c.status)}</div><h1>${c.name || 'Virtual card'}</h1>
  <div class="grid g2"><div>${cardVisual(c)}<div class="panel" style="margin-top:16px;max-width:340px"><div class="kv"><div>Balance</div><div><b>${fmt(c.balance)}</b></div><div>Initial deposit</div><div>${fmt(c.initial)}</div><div>Product</div><div>${c.productCode}</div><div>Created</div><div>${date(c.createdAt)}</div></div></div></div>
  <div>${c.status === 'pending' ? html`<div class="alert warn">Your card is being created…</div>` : ''}
  ${usable ? html`<div class="panel"><h2>Manage</h2>
    <form class="row" data-form="topup" data-id="${c.id}"><input name="amount" type="number" step="0.01" min="1" placeholder="Top-up amount" required style="max-width:170px"><button class="btn">Top up</button></form>
    <form class="row" data-form="withdraw" data-id="${c.id}" style="margin-top:8px"><input name="amount" type="number" step="0.01" min="0.02" placeholder="Withdraw to wallet" required style="max-width:170px"><button class="btn sec">Withdraw</button></form>
    <div class="row" style="margin-top:12px"><button class="btn sec sm" data-action="reveal" data-id="${c.id}">👁 Show card details</button><button class="btn sec sm" data-action="otp" data-id="${c.id}">🔐 3DS codes</button><button class="btn sec sm" data-action="refresh-card" data-id="${c.id}">↻ Sync</button>
    <button class="btn sec sm" data-action="${c.status === 'frozen' ? 'unfreeze' : 'freeze'}" data-id="${c.id}">${c.status === 'frozen' ? '▶ Unfreeze' : '⏸ Freeze'}</button><button class="btn danger sm" data-action="block" data-id="${c.id}">Block permanently</button></div></div>` : ''}
  ${usable && S.cfg.mock ? html`<div class="panel"><h2>🧪 Simulator</h2><p class="muted small">Pretend a merchant charges this card. The same callbacks the real provider sends are fired.</p>
    <form class="row" data-form="spend" data-id="${c.id}"><input name="amount" type="number" step="0.01" min="0.01" value="10" style="max-width:100px"><input name="merchant" value="FACEBK ADS" style="max-width:160px"><select name="mode" style="max-width:130px"><option value="expense">Purchase</option><option value="decline">Declined</option><option value="refund">Refund</option></select><button class="btn sec">Charge card</button></form>
    <div class="row" style="margin-top:8px"><button class="btn sec sm" data-action="sim-otp" data-id="${c.id}">Send 3DS code</button></div></div>` : ''}</div></div>
  <div class="grid g2"><div class="panel"><h2>Operations</h2>${table(['When', 'Type', 'Amount', 'Fee', 'Status'], ops.map((o) => [date(o.created_at), o.type, fmt(o.amount), fmt(o.fee), badge(o.status)]), 'No operations')}</div>
  <div class="panel"><h2>Card transactions</h2>${table(['When', 'Type', 'Merchant', 'Amount', 'Our fee'], transactions.map((t) => [date(t.created_at), badge(t.type), t.merchant, fmt(t.bill), t.platform_fee ? fmt(t.platform_fee) : '–']), 'No transactions yet')}</div></div>`;
}, { live: true });
const cardAct = (path, msg) => async ({ id }) => { await post(`/cards/${id}/${path}`); toast(msg, 'ok'); await render({ soft: true }); };
CH.actions.freeze = cardAct('freeze', 'Card frozen'); CH.actions.unfreeze = cardAct('unfreeze', 'Card unfrozen');
CH.actions.block = async ({ id }) => { if (await confirmBox('Blocking is permanent and cannot be undone. The remaining balance returns to your wallet.', 'Block card', true)) { await post(`/cards/${id}/block`); toast('Block requested', 'ok'); await render({ soft: true }); } };
CH.actions['refresh-card'] = async ({ id }) => { await post(`/cards/${id}/refresh`); toast('Synced with provider', 'ok'); await render({ soft: true }); };
CH.actions.reveal = async ({ id }) => {
  const r = await post(`/cards/${id}/reveal`);
  modal('Card details', html`<div class="kv"><div>Number</div><div class="mono">${r.number.replace(/(.{4})/g, '$1 ').trim()}</div><div>Expiry</div><div class="mono">${String(r.expMonth).padStart(2, '0')}/${r.expYear}</div><div>CVV</div><div class="mono">${r.cvv}</div></div><p class="muted small">Never share these details. This view is logged.</p>`);
};
CH.actions.otp = async ({ id }) => { const r = await get(`/cards/${id}/otp`); modal('Latest 3DS / OTP codes', r.length ? table(['Code', 'Received'], r.map((x) => [raw(`<b class="mono">${esc(x.code)}</b>`), date(x.date)])) : html`<div class="empty">No codes received yet</div>`); };
CH.actions['sim-otp'] = async ({ id }) => { const r = await post(`/cards/${id}/simulate-otp`); toast('3DS code sent: ' + r.code, 'ok'); };
CH.forms.topup = async (d, f) => { const r = await post(`/cards/${f.dataset.id}/topup`, d); toast(`Top-up requested (fee ${fmt(r.fee)})`, 'ok'); await render({ soft: true }); };
CH.forms.withdraw = async (d, f) => { await post(`/cards/${f.dataset.id}/withdraw`, d); toast('Withdrawal requested', 'ok'); await render({ soft: true }); };
CH.forms.spend = async (d, f) => { await post(`/cards/${f.dataset.id}/simulate-spend`, { amount: d.amount, merchant: d.merchant, decline: d.mode === 'decline', refund: d.mode === 'refund' }); toast('Charge simulated', 'ok'); };

// ---------- user: wallet ----------
route('/wallet', ['user'], async () => {
  const w = await get('/wallet'); const addr = S.lastAddress;
  return html`<h1>Wallet</h1><p class="muted">Deposit USDT (TRC-20). It is converted to USD automatically and credited to your balance.</p>
  <div class="grid g2"><div class="panel"><h3>Balance</h3><div style="font-size:32px;font-weight:800">${fmt(w.balance)}</div><p class="muted small">Minimum deposit ${fmt(w.minDeposit)}. Smaller amounts are held for manual review.</p></div>
  <div class="panel"><h2>Deposit address</h2>${addr ? html`<div class="addr" id="addr">${addr.address}</div><p class="small muted">Network: <b>USDT TRC-20 only</b>. Valid for 8 hours – generate a new address for each deposit. Sending other coins or networks loses funds.</p><div class="row"><button class="btn sec sm" data-action="copy" data-text="${addr.address}">Copy address</button><button class="btn sec sm" data-action="sync">Check for payment</button>${S.cfg.mock ? html`<button class="btn sec sm" data-action="sim-deposit">🧪 Simulate $100 deposit</button>` : ''}</div>` : html`<p class="muted">Generate a fresh address to receive USDT.</p>`}
  <div class="row" style="margin-top:10px"><button class="btn" data-action="new-address">${addr ? 'New address' : 'Generate deposit address'}</button></div></div></div>
  <div class="panel"><h2>Deposits</h2>${table(['Created', 'Address', 'Amount', 'Status'], w.deposits.map((d) => [date(d.created_at), raw(`<span class="mono small">${esc(d.address.slice(0, 10))}…${esc(d.address.slice(-6))}</span>`), d.amount != null ? fmt(d.amount) : '–', badge(d.status)]), 'No deposits yet')}</div>`;
}, { live: true });
CH.actions['new-address'] = async () => { S.lastAddress = (await post('/wallet/deposit-address')).deposit; await render({ soft: true }); };
CH.actions.sync = async () => { const r = await post('/wallet/sync'); toast(r.credited ? `${r.credited} deposit(s) credited` : 'No new payments yet', r.credited ? 'ok' : ''); await render({ soft: true }); };
CH.actions['sim-deposit'] = async () => { await post('/wallet/simulate-deposit', { amount: 100 }); toast('Deposit simulated', 'ok'); await render({ soft: true }); };
CH.actions.copy = async ({ text }) => { try { await navigator.clipboard.writeText(text); toast('Copied', 'ok'); } catch { toast('Copy failed – select and copy manually', 'err'); } };

// ---------- transactions (shared with admin) ----------
const txState = { tab: 'wallet', page: 1, f: {} };
async function txView(prefix) {
  const t = txState; const limit = 20;
  const data = await get(`${prefix}/transactions/${t.tab}?${qstr({ ...t.f, page: t.page, limit })}`);
  const admin = prefix === '/admin';
  const rows = t.tab === 'wallet'
    ? data.rows.map((r) => [date(r.created_at), admin ? r.email : '', label(r.type), r.note || '', signed(r.amount), fmt(r.balance_after)])
    : data.rows.map((r) => [date(r.created_at), admin ? r.email : '', badge(r.type), r.merchant, fmt(r.bill), r.platform_fee ? fmt(r.platform_fee) : '–']);
  const heads = t.tab === 'wallet' ? ['When', admin ? 'User' : '', 'Type', 'Details', 'Amount', 'Balance after'] : ['When', admin ? 'User' : '', 'Type', 'Merchant', 'Amount', 'Our fee'];
  const keep = (r) => (admin ? r : r.filter((_, i) => i !== 1)); // drop the user column for normal users
  return html`<h1>Transactions</h1><div class="tabs"><a href="#" class="${t.tab === 'wallet' ? 'on' : ''}" data-action="tx-tab" data-tab="wallet" data-prefix="${prefix}">Wallet</a><a href="#" class="${t.tab === 'card' ? 'on' : ''}" data-action="tx-tab" data-tab="card" data-prefix="${prefix}">Card payments</a></div>
  <form class="panel row" data-form="tx-filter" data-prefix="${prefix}"><input name="q" placeholder="Search…" value="${t.f.q || ''}" style="max-width:200px"><input name="from" type="date" value="${t.f.from || ''}" style="max-width:150px"><input name="to" type="date" value="${t.f.to || ''}" style="max-width:150px">
  ${t.tab === 'wallet' ? html`<select name="type" style="max-width:190px"><option value="">All types</option>${Object.entries(LABELS).map(([k, v]) => html`<option value="${k}" ${t.f.type === k ? 'selected' : ''}>${v}</option>`)}</select>` : ''}
  <button class="btn sm">Filter</button><a class="btn sec sm" href="/api${prefix}/transactions/${t.tab}/export.csv?${qstr(t.f)}">⬇ CSV</a></form>
  <div class="panel">${table(keep(heads), data.rows.length ? rows.map(keep) : [], 'No transactions match')}${pager(t.page, data.total, limit, 'tx')}</div>`;
}
CH.txView = txView; CH.txState = txState;
route('/transactions', ['user'], () => txView(''), { live: true });
CH.actions['tx-tab'] = async ({ tab }) => { txState.tab = tab; txState.page = 1; await render({ soft: true }); };
CH.forms['tx-filter'] = async (d) => { txState.f = Object.fromEntries(Object.entries(d).filter(([, v]) => v)); txState.page = 1; await render({ soft: true }); };
const pageKeys = {};
CH.pageKeys = pageKeys;
CH.actions.page = async ({ key, to }) => { if (key === 'tx') txState.page = Number(to); else pageKeys[key] = Number(to); await render({ soft: true }); };

// ---------- user: KYC ----------
route('/kyc', ['user'], async () => {
  const { status, kyc } = await get('/kyc');
  const done = status === 'approved'; const pending = status === 'pending';
  return html`<h1>Identity verification</h1><p class="muted">Required before issuing cards. Documents are stored privately and reviewed by our compliance team.</p>
  <div class="panel row"><span>Status</span>${badge(status === 'none' ? 'pending' : status)}<b>${{ none: 'Not submitted', pending: 'Under review', approved: 'Verified', declined: 'Declined' }[status]}</b></div>
  ${kyc?.status === 'declined' ? html`<div class="alert err">Declined: ${kyc.reason}. Please correct and resubmit.</div>` : ''}
  ${done || pending ? html`<div class="panel"><h2>Submitted details</h2><div class="kv">${Object.entries(kyc.data).map(([k, v]) => html`<div>${k}</div><div>${v}</div>`)}</div></div>` : html`
  <form class="panel" data-form="kyc"><h2>Personal details</h2><div class="form-grid">${field('fullName', 'Full legal name', 'text', S.me.name, 'required')}${field('dob', 'Date of birth', 'date', '', 'required')}${field('country', 'Country of residence', 'text', '', 'required')}${field('address', 'Residential address', 'text', '', 'required')}
  <div><label>Document type</label><select name="docType"><option value="passport">Passport</option><option value="id_card">National ID card</option><option value="driver_license">Driver license</option></select></div>${field('docNumber', 'Document number', 'text', '', 'required')}</div>
  <h2 style="margin-top:18px">Documents (PNG or JPEG, max 3 MB each)</h2><div class="form-grid"><div><label>Document – front</label><input type="file" name="front" accept="image/png,image/jpeg" required></div><div><label>Document – back (if any)</label><input type="file" name="back" accept="image/png,image/jpeg"></div><div><label>Selfie holding the document</label><input type="file" name="selfie" accept="image/png,image/jpeg" required></div></div>
  <div class="row end" style="margin-top:16px"><button class="btn">Submit for review</button></div></form>`}
  ${kyc?.providerUuid ? html`<div class="panel"><h2>Provider verification</h2><p>Status: ${badge(kyc.providerStatus || 'INITIATED')}</p><button class="btn sec sm" data-action="kyc-refresh">Refresh status</button></div>` : kyc ? html`<div class="panel"><h2>Provider verification</h2><p class="muted small">Some card products need an additional verification with the card provider.</p><button class="btn sec sm" data-action="kyc-provider">Start provider KYC</button></div>` : ''}`;
}, { live: true });
const readFile = (file) => new Promise((res, rej) => {
  if (!file || !file.size) return res(null);
  if (file.size > 3 * 1024 * 1024) return rej(new Error(`${file.name} is larger than 3 MB`));
  const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error('Could not read file')); r.readAsDataURL(file);
});
CH.forms.kyc = async (d, f) => {
  const body = { ...d }; for (const k of ['front', 'back', 'selfie']) body[k] = await readFile(f.elements[k].files[0]);
  await post('/kyc', body); toast('Submitted – we will review it shortly', 'ok'); await render({ soft: true });
};
CH.actions['kyc-provider'] = async () => { const r = await post('/kyc/provider/start', {}); modal('Provider verification', html`<p>Open this link to finish verification:</p><div class="addr">${r.url}</div>`); };
CH.actions['kyc-refresh'] = async () => { const r = await post('/kyc/provider/refresh', {}); toast('Provider status: ' + r.providerStatus, 'ok'); await render({ soft: true }); };

// ---------- user: referrals ----------
route('/referrals', ['user'], async () => {
  const r = await get('/referrals');
  return html`<h1>Referral program</h1><p class="muted">Earn ${r.pct}% of every platform fee paid by people you invite – automatically credited to your wallet.</p>
  <div class="grid g3" style="margin-bottom:16px">${stat('Total earned', fmt(r.totalEarned))}${stat('People invited', r.count)}${stat('Commission rate', r.pct + '%')}</div>
  <div class="panel"><h2>Your link</h2><div class="addr">${r.link}</div><div class="row" style="margin-top:10px"><button class="btn sec sm" data-action="copy" data-text="${r.link}">Copy link</button><span class="muted small">Code: <b class="mono">${r.code}</b></span></div></div>
  <div class="grid g2"><div class="panel"><h2>Invited users</h2>${table(['User', 'Joined', 'You earned'], r.referred.map((u) => [`${u.name} (${u.email})`, date(u.created_at), fmt(u.earned)]), 'Nobody yet – share your link!')}</div>
  <div class="panel"><h2>Recent commissions</h2>${table(['When', 'From', 'Amount'], r.recent.map((c) => [date(c.created_at), label('fee_' + c.fee_type), signed(c.commission)]), 'No commissions yet')}</div></div>`;
}, { live: true });

// ---------- user: account manager ----------
route('/manager', ['user'], async () => {
  const m = S.manager; const { messages } = await get('/support/messages');
  return html`<h1>Your account manager</h1>
  ${m ? html`<div class="panel row"><div style="font-size:34px">🧑‍💼</div><div class="sp"><b style="font-size:16px">${m.name}</b> <span class="muted">${m.title || 'Account manager'}</span><div class="muted small">${m.hours ? 'Hours: ' + m.hours : ''}</div></div><div class="small">${m.telegram ? html`<div>Telegram: <b>${m.telegram}</b></div>` : ''}${m.whatsapp ? html`<div>WhatsApp: <b>${m.whatsapp}</b></div>` : ''}<div>Email: <b>${m.email}</b></div></div></div>` : html`<div class="alert info">A personal manager will be assigned to you soon. You can still leave a message below.</div>`}
  <div class="panel"><h2>Messages</h2><div class="chat" id="chat">${messages.length ? messages.map((x) => html`<div class="msg ${x.from_staff ? 'staff' : 'me'}">${x.body}<small>${x.from_staff ? 'Manager' : 'You'} · ${date(x.created_at)}</small></div>`) : html`<div class="muted">No messages yet.</div>`}</div>
  <form class="row" data-form="support-msg"><input name="body" placeholder="Write a message…" required maxlength="2000" style="flex:1"><button class="btn">Send</button></form></div>`;
}, { live: true });
CH.forms['support-msg'] = async (d, f) => { await post('/support/messages', d); f.reset(); await render({ soft: true }); const c = $('#chat'); if (c) c.scrollTop = c.scrollHeight; };

// ---------- profile ----------
route('/profile', ['user', 'manager', 'admin'], async () => {
  const u = S.me;
  return html`<h1>Profile</h1><div class="grid g2"><form class="panel" data-form="profile"><h2>Your details</h2><label>Email</label><input value="${u.email}" disabled>${field('name', 'Name', 'text', u.name, 'required')}${field('phone', 'Phone', 'text', u.phone)}${field('telegram', 'Telegram', 'text', u.telegram)}<div class="row end" style="margin-top:14px"><button class="btn">Save</button></div></form>
  <form class="panel" data-form="password"><h2>Change password</h2>${field('current', 'Current password', 'password', '', 'required autocomplete="current-password"')}${field('next', 'New password (min 8)', 'password', '', 'required minlength="8" autocomplete="new-password"')}<div class="row end" style="margin-top:14px"><button class="btn">Update password</button></div></form></div>`;
});
CH.forms.profile = async (d) => { await api('PATCH', '/auth/profile', d); toast('Profile saved', 'ok'); await render({ soft: true }); };
CH.forms.password = async (d, f) => { await post('/auth/change-password', d); f.reset(); toast('Password updated', 'ok'); };

// ---------- global event delegation ----------
document.addEventListener('submit', async (e) => {
  const f = e.target.closest('[data-form]'); if (!f) return;
  e.preventDefault();
  const h = CH.forms[f.dataset.form]; if (!h) return;
  const btn = f.querySelector('button:not([type=button])'); if (btn) btn.disabled = true;
  try { await h(Object.fromEntries(new FormData(f).entries()), f, e); } catch (err) { toast(err.message, 'err'); } finally { if (btn) btn.disabled = false; }
});
document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-action]'); if (!el) return;
  const a = el.dataset.action;
  if (a === 'close' || (a === 'close-overlay' && e.target === el)) return closeModal();
  if (a === 'close-overlay') return;
  if (a === 'confirm-yes') return CH._confirm?.(true);
  if (a === 'confirm-no') return CH._confirm?.(false);
  if (a === 'menu') return $('#side').classList.toggle('open');
  e.preventDefault();
  const h = CH.actions[a]; if (!h) return;
  try { await h({ ...el.dataset }, el); } catch (err) { toast(err.message, 'err'); }
});
document.addEventListener('input', (e) => { const f = e.target.closest('[data-calc]'); if (f) CH.calc(f); });
document.addEventListener('change', (e) => { const f = e.target.closest('[data-calc]'); if (f) CH.calc(f); });

CH.start = () => render().catch((e) => { $('#app').innerHTML = `<div class="boot">Failed to load: ${esc(e.message)}</div>`; });
})();
