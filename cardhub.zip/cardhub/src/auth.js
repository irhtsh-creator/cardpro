const jwt = require('jsonwebtoken');
const config = require('./config');
const { get, settings } = require('./db');
const { HttpError } = require('./util');

const sign = (user) => jwt.sign({ uid: user.id }, config.appSecret, { expiresIn: '7d' });

function readToken(req) {
  const h = req.headers.authorization;
  if (h?.startsWith('Bearer ')) return h.slice(7);
  const m = /(?:^|;\s*)token=([^;]+)/.exec(req.headers.cookie || '');
  return m ? decodeURIComponent(m[1]) : null;
}

function auth(req, res, next) {
  const t = readToken(req);
  if (!t) return next(new HttpError(401, 'Not logged in'));
  try {
    const { uid } = jwt.verify(t, config.appSecret);
    const user = get('SELECT * FROM users WHERE id=?', uid);
    if (!user) throw new Error('no user');
    if (settings().maintenance_mode && user.role !== 'admin') return next(new HttpError(503, 'Platform is under maintenance. Please try again later.'));
    req.user = user;
    next();
  } catch { next(new HttpError(401, 'Session expired, please log in again')); }
}

const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : next(new HttpError(403, 'Forbidden'));

// Cookie-authenticated mutations must be JSON, which browsers cannot send cross-site without a CORS preflight (CSRF defence).
function jsonOnly(req, res, next) {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.headers.cookie && !/^application\/json/i.test(req.headers['content-type'] || '') && !req.headers.authorization) {
    return next(new HttpError(415, 'Content-Type must be application/json'));
  }
  next();
}

function setCookie(res, token) {
  const secure = config.publicUrl.startsWith('https') ? '; Secure' : '';
  res.setHeader('Set-Cookie', `token=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${7 * 86400}${secure}`);
}
const clearCookie = (res) => res.setHeader('Set-Cookie', 'token=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');

const hits = new Map();
function rateLimit(max = Number(process.env.RATE_LIMIT) || 60, windowMs = 60000) {
  return (req, res, next) => {
    const k = req.ip; const now = Date.now();
    const arr = (hits.get(k) || []).filter((t) => now - t < windowMs);
    arr.push(now); hits.set(k, arr);
    if (arr.length > max) return next(new HttpError(429, 'Too many requests, slow down'));
    next();
  };
}

const publicUser = (u) => u && ({
  id: u.id, email: u.email, name: u.name, phone: u.phone, telegram: u.telegram, role: u.role, status: u.status,
  balance: u.balance_c / 100, kycStatus: u.kyc_status, referralCode: u.referral_code, createdAt: u.created_at, managerId: u.manager_id,
});

module.exports = { auth, requireRole, jsonOnly, sign, setCookie, clearCookie, rateLimit, publicUser };
