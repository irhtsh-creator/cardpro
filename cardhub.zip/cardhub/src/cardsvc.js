const { get, all, run, tx, settings, audit } = require('./db');
const providers = require('./providers');
const { setCallbackSink } = require('./providers/mock');
const { emit } = require('./events');
const { post, chargeFee, payReferral } = require('./ledger');
const fees = require('./fees');
const { rid, toC, bad, HttpError, parseMoney } = require('./util');

// ---------- products ----------
let cache = { at: 0, mode: '', data: [] };
async function providerProducts() {
  const mode = settings().provider_mode;
  if (Date.now() - cache.at < 60000 && cache.mode === mode) return cache.data;
  const data = (await providers.cards.products()).filter((p) => p.currency === 'USD'); // wallet is USD
  cache = { at: Date.now(), mode, data };
  return data;
}

async function listProducts(user, { includeDisabled = false } = {}) {
  const out = [];
  for (const p of await providerProducts()) {
    const ps = get('SELECT * FROM product_settings WHERE code=?', p.productCode);
    if (ps && !ps.enabled && !includeDisabled) continue;
    const minDeposit = fees.minDepositC(user, p.productCode) / 100;
    out.push({
      code: p.productCode, label: ps?.label || p.productCode, enabled: ps ? !!ps.enabled : true,
      currency: p.currency, kycSort: p.kycSort || null, params: p.params || {},
      issueMin: Math.max(p.issueMinAmount ?? 0, minDeposit), issueMax: p.issueMaxAmount,
      topUpMin: p.topUpMinAmount, topUpMax: p.topUpMaxAmount, minDeposit,
      issueFeeFlat: fees.effective(user, 'issue_fee_flat', p.productCode), issueFeePct: fees.effective(user, 'issue_fee_pct', p.productCode),
      topupFeeFlat: fees.effective(user, 'topup_fee_flat', p.productCode), topupFeePct: fees.effective(user, 'topup_fee_pct', p.productCode),
    });
  }
  return out;
}

// ---------- helpers ----------
const refund = (userId, amountC, ref, note) => amountC > 0 && post(userId, 'refund', amountC, { ref, note });

function requireOwnedCard(user, id) {
  const c = get('SELECT * FROM cards WHERE id=?', id);
  if (!c || (c.user_id !== user.id && user.role !== 'admin')) throw new HttpError(404, 'Card not found');
  return c;
}
function assertUsable(user, card, { allowFrozen = false } = {}) {
  const s = settings();
  if (!s.feature_cards) throw new HttpError(403, 'Cards are disabled');
  if (user.status !== 'active') throw new HttpError(403, 'Account suspended');
  if (!card.san || card.status === 'pending') throw bad('Card is still being created');
  if (card.status === 'blocked' || card.status === 'blocking' || card.status === 'declined') throw bad(`Card is ${card.status}`);
  if (card.status === 'frozen' && !allowFrozen) throw bad('Card is frozen');
}
// Only a network timeout/reset leaves the outcome unknown (the provider may have processed the request) -> keep the op pending for reconciliation.
// Any other failure (HTTP error, bug) is definitive: the caller refunds immediately.
const isUnknownOutcome = (e) => !e.status && (['TimeoutError', 'AbortError'].includes(e.name) || /ECONNRESET|ETIMEDOUT|UND_ERR_SOCKET|other side closed/.test(`${e.code || ''} ${e.cause?.code || ''} ${e.cause?.message || ''}`));
const providerFailure = (e) => {
  if (isUnknownOutcome(e)) return null;
  if (!e.status) console.error('card provider call failed:', e);
  return new HttpError(e.status ? 502 : 500, e.status ? `Card provider error: ${e.message}` : 'Card provider call failed, you were not charged');
};

// ---------- operations finalization (shared by callbacks and admin resolve) ----------
function finalizeOp(op, status, params = {}, san) {
  if (op.status !== 'INPROCESS') return false; // idempotent
  tx(() => {
    run("UPDATE card_ops SET status=?, updated_at=datetime('now') WHERE id=?", status, op.id);
    const card = get('SELECT * FROM cards WHERE id=?', op.card_id);
    if (status === 'DECLINED') {
      if (op.type === 'ISSUE') { run("UPDATE cards SET status='declined' WHERE id=?", card.id); refund(op.user_id, op.amount_c + op.fee_c, op.request_id, 'Card issue declined'); }
      if (op.type === 'TOPUP') refund(op.user_id, op.amount_c + op.fee_c, op.request_id, 'Top-up declined');
      if (op.type === 'WITHDRAWAL') run('UPDATE cards SET balance_c=balance_c+? WHERE id=?', op.amount_c, card.id);
      if (op.type === 'BLOCK') run("UPDATE cards SET status='active' WHERE id=?", card.id);
      return;
    }
    if (op.type === 'ISSUE') {
      if (!san) throw bad('Missing card id (san) for executed issue');
      run("UPDATE cards SET san=?, status='active', balance_c=?, initial_c=? WHERE id=?", san, op.amount_c, op.amount_c, card.id);
      payReferral(op.user_id, op.fee_c, 'issue', op.request_id);
    } else if (op.type === 'TOPUP') {
      run('UPDATE cards SET balance_c=balance_c+? WHERE id=?', op.amount_c, card.id);
      payReferral(op.user_id, op.fee_c, 'topup', op.request_id);
    } else if (op.type === 'WITHDRAWAL') {
      post(op.user_id, 'card_withdraw', op.amount_c, { ref: op.request_id, note: `Withdrawal from card …${card.last4 || card.id}` });
    } else if (op.type === 'BLOCK') {
      const released = params.amount !== undefined ? toC(params.amount) : card.balance_c;
      run("UPDATE cards SET status='blocked', balance_c=0 WHERE id=?", card.id);
      if (released > 0) post(op.user_id, 'card_release', released, { ref: op.request_id, note: 'Balance released from blocked card' });
    }
  });
  emit(op.user_id, 'card_op', { type: op.type, status, cardId: op.card_id });
  return true;
}

async function enrichCard(cardId) {
  const card = get('SELECT * FROM cards WHERE id=?', cardId);
  if (!card?.san) return;
  try {
    const d = await providers.cards.details(card.san);
    run('UPDATE cards SET last4=?, brand=?, exp_month=?, exp_year=? WHERE id=?', String(d.cardNumber || '').slice(-4), d.cardSystem || '', d.expMonth ?? null, d.expYear ?? null, cardId);
  } catch (e) { console.warn('card enrich failed:', e.message); }
}

// ---------- callbacks (provider -> us) ----------
function handleCallback(type, body) {
  const san = body.san;
  const opByRequest = body.request_id ? get('SELECT * FROM card_ops WHERE request_id=?', body.request_id) : null;
  switch (type) {
    case 'CARD_ISSUE': case 'CARD_TOPUP': case 'CARD_WITHDRAWAL': case 'CARD_BLOCK': {
      if (!opByRequest) return { ignored: 'unknown request_id' };
      if (body.docid) run('UPDATE card_ops SET docid=? WHERE id=?', body.docid, opByRequest.id);
      const changed = finalizeOp(opByRequest, body.status === 'EXECUTED' ? 'EXECUTED' : 'DECLINED', body.params || {}, san);
      if (changed && type === 'CARD_ISSUE' && body.status === 'EXECUTED') enrichCard(opByRequest.card_id);
      return { ok: true };
    }
    case 'CARD_FREEZE': run("UPDATE cards SET status='frozen' WHERE san=? AND status='active'", san); break;
    case 'CARD_UNFREEZE': run("UPDATE cards SET status='active' WHERE san=? AND status='frozen'", san); break;
    case 'CARD_TRANSACTION': return handleCardTx(body);
    case 'EXTRA_FEE_CARD': case 'EXTRA_FEE_CAP': {
      const card = get('SELECT * FROM cards WHERE san=?', san); if (!card) return { ignored: 'unknown card' };
      run('INSERT OR IGNORE INTO card_tx(card_id,user_id,tx_id,type,amount_c,bill_c,merchant) VALUES(?,?,?,?,?,?,?)', card.id, card.user_id, body.txId, `fee_${body.feeType}`, toC(body.amount), toC(body.amount), 'Provider fee');
      break;
    }
    case 'OTP_CODE': {
      const card = get('SELECT * FROM cards WHERE san=?', san); if (card) emit(card.user_id, 'otp', { cardId: card.id, code: body.otpCode });
      break;
    }
    case 'KYC_CHANGE': {
      run('UPDATE kyc SET provider_status=? WHERE provider_uuid=?', body.status, body.uuid);
      const k = get('SELECT user_id FROM kyc WHERE provider_uuid=?', body.uuid);
      if (k) emit(k.user_id, 'kyc', { providerStatus: body.status });
      break;
    }
    default: return { ignored: `unknown type ${type}` };
  }
  return { ok: true };
}

function handleCardTx(b) {
  const card = get('SELECT * FROM cards WHERE san=?', b.san);
  if (!card) return { ignored: 'unknown card' };
  const user = get('SELECT * FROM users WHERE id=?', card.user_id);
  const bill = toC(b.billAmount ?? b.txAmount ?? 0);
  const t = b.txType;
  const isExpense = t === 'expense' || t === 'verification_expense' || t === 'maintenance_fee';
  const isDecline = t === 'authorization_decline' || t === 'verification_decline';
  let inserted = false;
  tx(() => {
    const r = run('INSERT OR IGNORE INTO card_tx(card_id,user_id,tx_id,type,amount_c,currency,bill_c,merchant,mcc,country,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
      card.id, card.user_id, b.txId, t, toC(b.txAmount ?? 0), b.txCurrency || 'USD', bill, b.merchantName || '', b.mcc || '', b.merchantCountry || '', (b.txDate || new Date().toISOString()).replace('T', ' ').slice(0, 19));
    if (!r.changes) return; // duplicate callback
    inserted = true;
    if (isExpense) run('UPDATE cards SET balance_c=balance_c-? WHERE id=?', bill, card.id);
    if (t === 'refund') run('UPDATE cards SET balance_c=balance_c+? WHERE id=?', bill, card.id);
    let pf = 0;
    if (isExpense && t !== 'maintenance_fee') pf = chargeFee(user.id, 'txn', fees.txnFee(user, bill), { ref: b.txId, note: `Transaction fee – ${b.merchantName || ''}` });
    if (isDecline) pf = chargeFee(user.id, 'decline', fees.declineFee(user), { ref: b.txId, note: `Decline fee – ${b.merchantName || ''}` });
    if (pf) run('UPDATE card_tx SET platform_fee_c=? WHERE card_id=? AND tx_id=? AND type=?', pf, card.id, b.txId, t);
  });
  if (inserted) emit(card.user_id, 'card_tx', { cardId: card.id, type: t, amount: bill / 100, merchant: b.merchantName || '' });
  return { ok: true };
}
setCallbackSink(handleCallback);

// ---------- user actions ----------
async function issueCard(user, input) {
  const s = settings();
  if (!s.feature_cards) throw new HttpError(403, 'Card issuing is disabled');
  if (user.status !== 'active') throw new HttpError(403, 'Account suspended');
  if (s.feature_kyc && s.kyc_required_for_cards && user.kyc_status !== 'approved') throw new HttpError(403, 'Complete KYC verification before issuing cards');
  const prod = (await listProducts(user)).find((p) => p.code === input.productCode);
  if (!prod) throw bad('Card product is not available');
  const amountC = parseMoney(input.amount, 'deposit');
  if (amountC < Math.round(prod.issueMin * 100)) throw bad(`Minimum initial deposit is $${prod.issueMin}`);
  if (prod.issueMax && amountC > prod.issueMax * 100) throw bad(`Maximum initial deposit is $${prod.issueMax}`);
  if (prod.params.issueCardEmailRequired && !input.email) throw bad('Email is required for this card product');
  const n = get("SELECT COUNT(*) n FROM cards WHERE user_id=? AND status NOT IN ('declined','blocked')", user.id).n;
  if (n >= s.max_cards_per_user) throw bad('Card limit reached');
  let kycUuid;
  if (prod.kycSort && providers.isMock() === false) {
    const k = get("SELECT provider_uuid FROM kyc WHERE user_id=? AND provider_uuid IS NOT NULL AND provider_status='APPROVED' ORDER BY id DESC", user.id);
    if (!k) throw bad(`This product needs provider KYC (${prod.kycSort}). Start it on the KYC page first.`);
    kycUuid = k.provider_uuid;
  }
  const feeC = fees.issueFee(user, prod.code, amountC);
  const requestId = rid();
  const name = String(input.name || '').slice(0, 32);
  const { cardId, opId } = tx(() => {
    const u = get('SELECT balance_c FROM users WHERE id=?', user.id);
    if (u.balance_c < amountC + feeC) throw bad(`Insufficient balance: need $${((amountC + feeC) / 100).toFixed(2)} (deposit + fee)`);
    post(user.id, 'card_fund', -amountC, { ref: requestId, note: 'Initial card deposit' });
    chargeFee(user.id, 'issue', feeC, { ref: requestId, note: 'Card issue fee', deferReferral: true });
    const c = run('INSERT INTO cards(user_id,product_code,name,currency,status,balance_c,initial_c) VALUES(?,?,?,?,?,?,?)', user.id, prod.code, name, 'USD', 'pending', 0, 0);
    const o = run("INSERT INTO card_ops(user_id,card_id,type,request_id,amount_c,fee_c) VALUES(?,?,'ISSUE',?,?,?)", user.id, c.id, requestId, amountC, feeC);
    return { cardId: c.id, opId: o.id };
  });
  try {
    const resp = await providers.cards.issue({
      productCode: prod.code, request_id: requestId, amount: amountC / 100, currency: 'USD', cardName: name || undefined,
      firstName: input.firstName || undefined, lastName: input.lastName || undefined, email: input.email || undefined,
      cardValidityYears: input.validityYears ? Number(input.validityYears) : undefined, kycUuid,
    });
    run('UPDATE card_ops SET docid=? WHERE id=?', resp.docid ?? null, opId);
    if (resp.status === 'DECLINED') finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED');
  } catch (e) {
    const def = providerFailure(e);
    if (def) { finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED'); throw def; }
    audit(user.id, 'op_unknown_state', { opId, error: e.message }); // timeout: provider may have processed it, leave INPROCESS for admin
    throw new HttpError(504, 'The provider did not answer in time. Your card is pending and will update automatically or be resolved by support.');
  }
  emit(user.id, 'card_op', { type: 'ISSUE', status: 'INPROCESS', cardId });
  return get('SELECT * FROM cards WHERE id=?', cardId);
}

async function topupCard(user, cardId, amount) {
  const card = requireOwnedCard(user, cardId); assertUsable(user, card, { allowFrozen: true });
  const amountC = parseMoney(amount);
  const prod = (await listProducts(user, { includeDisabled: true })).find((p) => p.code === card.product_code);
  if (prod) {
    if (amountC < prod.topUpMin * 100) throw bad(`Minimum top-up is $${prod.topUpMin}`);
    if (amountC > prod.topUpMax * 100) throw bad(`Maximum top-up is $${prod.topUpMax}`);
  }
  const feeC = fees.topupFee(user, card.product_code, amountC);
  const requestId = rid();
  const opId = tx(() => {
    const u = get('SELECT balance_c FROM users WHERE id=?', user.id);
    if (u.balance_c < amountC + feeC) throw bad(`Insufficient balance: need $${((amountC + feeC) / 100).toFixed(2)} (amount + fee)`);
    post(user.id, 'card_topup', -amountC, { ref: requestId, note: `Top-up card …${card.last4 || card.id}` });
    chargeFee(user.id, 'topup', feeC, { ref: requestId, note: 'Top-up fee', deferReferral: true });
    return run("INSERT INTO card_ops(user_id,card_id,type,request_id,amount_c,fee_c) VALUES(?,?,'TOPUP',?,?,?)", user.id, card.id, requestId, amountC, feeC).id;
  });
  try {
    const resp = await providers.cards.topup(card.san, { amount: amountC / 100, currency: 'USD', request_id: requestId });
    run('UPDATE card_ops SET docid=? WHERE id=?', resp.docid ?? null, opId);
    if (resp.status === 'DECLINED') finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED');
  } catch (e) {
    const def = providerFailure(e);
    if (def) { finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED'); throw def; }
    audit(user.id, 'op_unknown_state', { opId, error: e.message });
    throw new HttpError(504, 'The provider did not answer in time. The top-up is pending.');
  }
  return { requestId, fee: feeC / 100 };
}

async function withdrawCard(user, cardId, amount) {
  const card = requireOwnedCard(user, cardId); assertUsable(user, card, { allowFrozen: true });
  const amountC = parseMoney(amount);
  if (amountC < 2) throw bad('Minimum withdrawal is $0.02');
  const requestId = rid();
  const opId = tx(() => {
    const c = get('SELECT balance_c FROM cards WHERE id=?', card.id);
    if (c.balance_c < amountC) throw bad('Insufficient card balance');
    run('UPDATE cards SET balance_c=balance_c-? WHERE id=?', amountC, card.id); // hold until confirmed
    return run("INSERT INTO card_ops(user_id,card_id,type,request_id,amount_c) VALUES(?,?,'WITHDRAWAL',?,?)", user.id, card.id, requestId, amountC).id;
  });
  try {
    const resp = await providers.cards.withdraw(card.san, { amount: amountC / 100, currency: 'USD', request_id: requestId });
    run('UPDATE card_ops SET docid=? WHERE id=?', resp.docid ?? null, opId);
    if (resp.status === 'DECLINED') finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED');
  } catch (e) {
    const def = providerFailure(e);
    if (def) { finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED'); throw def; }
    audit(user.id, 'op_unknown_state', { opId, error: e.message });
    throw new HttpError(504, 'The provider did not answer in time. The withdrawal is pending.');
  }
  return { requestId };
}

async function blockCard(user, cardId) {
  const card = requireOwnedCard(user, cardId); assertUsable(user, card, { allowFrozen: true });
  const requestId = rid();
  const opId = tx(() => {
    run("UPDATE cards SET status='blocking' WHERE id=?", card.id);
    return run("INSERT INTO card_ops(user_id,card_id,type,request_id) VALUES(?,?,'BLOCK',?)", card.user_id, card.id, requestId).id;
  });
  try {
    const resp = await providers.cards.block(card.san, { request_id: requestId });
    run('UPDATE card_ops SET docid=? WHERE id=?', resp.docid ?? null, opId);
    if (resp.status === 'DECLINED') finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED');
  } catch (e) {
    const def = providerFailure(e);
    if (def) { finalizeOp(get('SELECT * FROM card_ops WHERE id=?', opId), 'DECLINED'); throw def; }
    throw new HttpError(504, 'The provider did not answer in time. The block is pending.');
  }
  return { requestId };
}

async function setFrozen(user, cardId, frozen) {
  const card = requireOwnedCard(user, cardId); assertUsable(user, card, { allowFrozen: true });
  try { frozen ? await providers.cards.freeze(card.san) : await providers.cards.unfreeze(card.san); }
  catch (e) { throw providerFailure(e) || new HttpError(504, 'Provider timeout'); }
  run('UPDATE cards SET status=? WHERE id=?', frozen ? 'frozen' : 'active', card.id);
  emit(card.user_id, 'card_op', { type: frozen ? 'FREEZE' : 'UNFREEZE', status: 'EXECUTED', cardId });
  return { status: frozen ? 'frozen' : 'active' };
}

async function revealCard(user, cardId) {
  const card = requireOwnedCard(user, cardId); assertUsable(user, card, { allowFrozen: true });
  const d = await providers.cards.details(card.san);
  audit(user.id, 'card_reveal', { cardId });
  return { number: d.cardNumber, cvv: d.cvv, expMonth: d.expMonth, expYear: d.expYear, brand: d.cardSystem };
}

async function refreshCard(user, cardId) {
  const card = requireOwnedCard(user, cardId);
  if (!card.san) return card;
  const d = await providers.cards.details(card.san);
  const st = { active: 'active', frozen: 'frozen', blocked: 'blocked', blocking: 'blocking' }[d.status];
  const pending = get("SELECT 1 x FROM card_ops WHERE card_id=? AND status='INPROCESS'", card.id);
  if (!pending) {
    if (d.balance !== null && d.balance !== undefined) run('UPDATE cards SET balance_c=? WHERE id=?', toC(d.balance), card.id);
    if (st) run('UPDATE cards SET status=? WHERE id=?', st, card.id);
  }
  run('UPDATE cards SET last4=?, brand=?, exp_month=?, exp_year=? WHERE id=?', String(d.cardNumber || '').slice(-4), d.cardSystem || '', d.expMonth ?? null, d.expYear ?? null, card.id);
  return get('SELECT * FROM cards WHERE id=?', card.id);
}

async function otpCodes(user, cardId) {
  const card = requireOwnedCard(user, cardId); assertUsable(user, card, { allowFrozen: true });
  return providers.cards.otp(card.san);
}

// Admin: settle an operation that the provider never called back about.
function resolveOp(opId, status, san, adminId) {
  const op = get('SELECT * FROM card_ops WHERE id=?', opId);
  if (!op) throw new HttpError(404, 'Operation not found');
  if (op.status !== 'INPROCESS') throw bad('Operation already settled');
  finalizeOp(op, status, {}, san);
  audit(adminId, 'op_resolve', { opId, status });
}

module.exports = {
  listProducts, issueCard, topupCard, withdrawCard, blockCard, setFrozen, revealCard, refreshCard, otpCodes,
  handleCallback, resolveOp, enrichCard, requireOwnedCard,
};
