const path = require('path');

const env = process.env;
module.exports = {
  port: Number(env.PORT) || 3000,
  appSecret: env.APP_SECRET || 'dev-only-secret-change-me',
  publicUrl: env.PUBLIC_URL || 'http://localhost:3000',
  dbFile: env.DB_FILE || path.join(__dirname, '..', 'data', 'cardhub.db'),
  uploadDir: env.UPLOAD_DIR || path.join(__dirname, '..', 'data', 'uploads'),
  // "mock" uses the built-in simulator (no real money moves). "live" calls the real APIs.
  defaultProviderMode: env.PROVIDER_MODE === 'live' ? 'live' : 'mock',
  cardspro: {
    base: env.CARDSPRO_BASE_URL || 'https://api.cardspro.com/cards/v1',
    key: env.CARDSPRO_API_KEY || '',
    secret: env.CARDSPRO_API_SECRET || '',
  },
  capitalist: {
    base: env.CAPITALIST_BASE_URL || 'https://api2.capitalist.net',
    key: env.CAPITALIST_API_KEY || env.CARDSPRO_API_KEY || '',
    secret: env.CAPITALIST_API_SECRET || env.CARDSPRO_API_SECRET || '',
    account: env.CAPITALIST_ACCOUNT || '', // your Capitalist account that receives the converted USDT, e.g. U0123504
  },
  webhookSecret: env.WEBHOOK_SECRET || 'change-this-webhook-secret',
  adminEmail: env.ADMIN_EMAIL || 'admin@cardhub.local',
  adminPassword: env.ADMIN_PASSWORD || 'ChangeMe!234',
};
