const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');

fs.mkdirSync(path.dirname(config.dbFile), { recursive: true });
fs.mkdirSync(config.uploadDir, { recursive: true });

const db = new DatabaseSync(config.dbFile);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  phone TEXT DEFAULT '',
  telegram TEXT DEFAULT '',
  role TEXT NOT NULL DEFAULT 'user',            -- user | manager | admin
  status TEXT NOT NULL DEFAULT 'active',        -- active | suspended
  balance_c INTEGER NOT NULL DEFAULT 0,
  kyc_status TEXT NOT NULL DEFAULT 'none',      -- none | pending | approved | declined
  referral_code TEXT UNIQUE,
  referred_by INTEGER REFERENCES users(id),
  manager_id INTEGER REFERENCES users(id),
  fee_overrides TEXT NOT NULL DEFAULT '{}',
  contact TEXT NOT NULL DEFAULT '{}',           -- manager public contact card (json)
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_login TEXT
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS product_settings(
  code TEXT PRIMARY KEY, label TEXT, enabled INTEGER NOT NULL DEFAULT 1,
  issue_fee_flat REAL, issue_fee_pct REAL, topup_fee_flat REAL, topup_fee_pct REAL, min_deposit REAL
);
CREATE TABLE IF NOT EXISTS kyc(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  data TEXT NOT NULL DEFAULT '{}',
  doc_front TEXT, doc_back TEXT, selfie TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  reason TEXT DEFAULT '',
  provider_uuid TEXT, provider_status TEXT,
  reviewed_by INTEGER, reviewed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS cards(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  san TEXT UNIQUE,
  product_code TEXT NOT NULL,
  name TEXT DEFAULT '',
  currency TEXT NOT NULL DEFAULT 'USD',
  balance_c INTEGER NOT NULL DEFAULT 0,
  initial_c INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',        -- pending | active | frozen | blocked | declined
  last4 TEXT DEFAULT '', brand TEXT DEFAULT '', exp_month INTEGER, exp_year INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS card_ops(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, card_id INTEGER NOT NULL,
  type TEXT NOT NULL,                             -- ISSUE | TOPUP | WITHDRAWAL | BLOCK
  request_id TEXT UNIQUE NOT NULL, docid INTEGER,
  amount_c INTEGER NOT NULL DEFAULT 0, fee_c INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'INPROCESS',       -- INPROCESS | EXECUTED | DECLINED
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT
);
CREATE TABLE IF NOT EXISTS card_tx(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  card_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
  tx_id TEXT NOT NULL, type TEXT NOT NULL,
  amount_c INTEGER NOT NULL DEFAULT 0, currency TEXT DEFAULT 'USD',
  bill_c INTEGER NOT NULL DEFAULT 0, platform_fee_c INTEGER NOT NULL DEFAULT 0,
  merchant TEXT DEFAULT '', mcc TEXT DEFAULT '', country TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(tx_id, type)
);
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, type TEXT NOT NULL,
  amount_c INTEGER NOT NULL, balance_after_c INTEGER NOT NULL,
  ref TEXT DEFAULT '', note TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger(user_id, id);
CREATE TABLE IF NOT EXISTS deposits(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, address TEXT NOT NULL, network TEXT NOT NULL DEFAULT 'USDT-TRC20',
  status TEXT NOT NULL DEFAULT 'waiting',         -- waiting | credited | expired
  amount_c INTEGER, fee_c INTEGER DEFAULT 0, provider_tx TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), expires_at TEXT NOT NULL, credited_at TEXT
);
CREATE TABLE IF NOT EXISTS referrals(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_id INTEGER NOT NULL, referred_id INTEGER NOT NULL,
  commission_c INTEGER NOT NULL, fee_type TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS api_credentials(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL,                         -- cardspro | capitalist
  label TEXT DEFAULT '', api_key TEXT NOT NULL, api_secret_enc TEXT NOT NULL,
  base_url TEXT DEFAULT '', account TEXT DEFAULT '',
  active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, sender_id INTEGER NOT NULL, from_staff INTEGER NOT NULL DEFAULT 0,
  body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS manager_notes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, manager_id INTEGER NOT NULL, body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER, action TEXT NOT NULL, detail TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS mock_cards(san TEXT PRIMARY KEY, json TEXT NOT NULL);
`);

const all = (sql, ...p) => db.prepare(sql).all(...p).map((r) => ({ ...r }));
const get = (sql, ...p) => { const r = db.prepare(sql).get(...p); return r ? { ...r } : undefined; };
const run = (sql, ...p) => {
  const r = db.prepare(sql).run(...p);
  return { changes: Number(r.changes), id: Number(r.lastInsertRowid) };
};

let depth = 0;
function tx(fn) {
  const name = `sp${depth}`;
  db.exec(depth === 0 ? 'BEGIN IMMEDIATE' : `SAVEPOINT ${name}`);
  depth++;
  try {
    const r = fn();
    depth--;
    db.exec(depth === 0 ? 'COMMIT' : `RELEASE ${name}`);
    return r;
  } catch (e) {
    depth--;
    db.exec(depth === 0 ? 'ROLLBACK' : `ROLLBACK TO ${name}`);
    throw e;
  }
}

// ---- settings ----
const DEFAULTS = {
  issue_fee_flat: 2, issue_fee_pct: 2,
  topup_fee_flat: 0, topup_fee_pct: 3,
  txn_fee_flat: 0, txn_fee_pct: 0.5,
  decline_fee_flat: 0.3,
  card_min_deposit: 10,
  wallet_min_deposit: 10,
  max_cards_per_user: 50,
  referral_pct: 10,
  feature_referrals: 1, feature_wallet: 1, feature_cards: 1, feature_kyc: 1, feature_manager: 1,
  kyc_required_for_cards: 1,
  registration_open: 1,
  maintenance_mode: 0,
  provider_mode: config.defaultProviderMode,
  site_name: 'CardHub',
};
function settings() {
  const out = { ...DEFAULTS };
  for (const r of all('SELECT key,value FROM settings')) {
    try { out[r.key] = JSON.parse(r.value); } catch { /* ignore */ }
  }
  return out;
}
function setSetting(key, value) {
  if (!(key in DEFAULTS)) throw new Error(`Unknown setting: ${key}`);
  run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, JSON.stringify(value));
}
const audit = (actorId, action, detail = '') =>
  run('INSERT INTO audit_log(actor_id,action,detail) VALUES(?,?,?)', actorId ?? null, action, typeof detail === 'string' ? detail : JSON.stringify(detail));

module.exports = { db, all, get, run, tx, settings, setSetting, DEFAULTS, audit };
