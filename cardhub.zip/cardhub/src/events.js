// Real-time event hub: Server-Sent Events. Users receive their own events, staff receive everything.
const clients = new Set();
const recent = [];

function addClient(res, user) {
  const c = { res, userId: user.id, role: user.role };
  clients.add(c);
  res.on('close', () => clients.delete(c));
  return c;
}

function emit(userId, type, data = {}) {
  const ev = { type, userId, data, at: new Date().toISOString() };
  recent.push(ev);
  if (recent.length > 200) recent.shift();
  const line = `event: ${type}\ndata: ${JSON.stringify(ev)}\n\n`;
  for (const c of clients) {
    if (c.role === 'admin' || c.userId === userId) {
      try { c.res.write(line); } catch { clients.delete(c); }
    }
  }
}

setInterval(() => {
  for (const c of clients) { try { c.res.write(': ping\n\n'); } catch { clients.delete(c); } }
}, 25000).unref();

module.exports = { addClient, emit, recent, clientCount: () => clients.size };
