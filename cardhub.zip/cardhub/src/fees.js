const { get, settings } = require('./db');

const PRODUCT_KEYS = ['issue_fee_flat', 'issue_fee_pct', 'topup_fee_flat', 'topup_fee_pct'];

// Resolution order: per-user override > per-product override > global setting
function effective(user, key, productCode) {
  let v = settings()[key];
  if (productCode) {
    const p = get('SELECT * FROM product_settings WHERE code=?', productCode);
    if (p) {
      const pk = key === 'card_min_deposit' ? 'min_deposit' : PRODUCT_KEYS.includes(key) ? key : null;
      if (pk && p[pk] !== null && p[pk] !== undefined) v = p[pk];
    }
  }
  let o = {};
  try { o = JSON.parse(user?.fee_overrides || '{}'); } catch { /* ignore */ }
  if (o[key] !== undefined && o[key] !== null && o[key] !== '') v = Number(o[key]);
  return Number(v);
}

const calc = (flat, pct, amountC) => Math.round(flat * 100 + (amountC * pct) / 100);

const issueFee = (u, code, amountC) => calc(effective(u, 'issue_fee_flat', code), effective(u, 'issue_fee_pct', code), amountC);
const topupFee = (u, code, amountC) => calc(effective(u, 'topup_fee_flat', code), effective(u, 'topup_fee_pct', code), amountC);
const txnFee = (u, billC) => calc(effective(u, 'txn_fee_flat'), effective(u, 'txn_fee_pct'), billC);
const declineFee = (u) => Math.round(effective(u, 'decline_fee_flat') * 100);
const minDepositC = (u, code) => Math.round(effective(u, 'card_min_deposit', code) * 100);

module.exports = { effective, issueFee, topupFee, txnFee, declineFee, minDepositC };
