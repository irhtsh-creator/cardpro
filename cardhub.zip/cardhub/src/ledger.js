const { get, run, tx, settings } = require('./db');
const { emit } = require('./events');
const { bad } = require('./util');
const { effective } = require('./fees');

// Single place where a wallet balance changes. amountC is signed (credit +, debit -).
function post(userId, type, amountC, { ref = '', note = '', allowNegative = true } = {}) {
  return tx(() => {
    const u = get('SELECT balance_c FROM users WHERE id=?', userId);
    if (!u) throw bad('user not found');
    const nb = u.balance_c + amountC;
    if (!allowNegative && nb < 0) throw bad('Insufficient balance');
    run('UPDATE users SET balance_c=? WHERE id=?', nb, userId);
    const r = run('INSERT INTO ledger(user_id,type,amount_c,balance_after_c,ref,note) VALUES(?,?,?,?,?,?)', userId, type, amountC, nb, String(ref), note);
    emit(userId, 'ledger', { id: r.id, type, amount: amountC / 100, balance: nb / 100 });
    return { id: r.id, balance_c: nb };
  });
}

// Commission paid to the referrer from a platform fee the referred user paid.
function payReferral(userId, feeC, feeType, ref = '') {
  const s = settings();
  if (!s.feature_referrals || feeC <= 0) return 0;
  const u = get('SELECT referred_by FROM users WHERE id=?', userId);
  if (!u?.referred_by) return 0;
  const referrer = get('SELECT * FROM users WHERE id=? AND status=?', u.referred_by, 'active');
  if (!referrer) return 0;
  const pct = effective(referrer, 'referral_pct');
  const commission = Math.floor((feeC * pct) / 100);
  if (commission <= 0) return 0;
  tx(() => {
    post(referrer.id, 'referral', commission, { ref, note: `Commission on ${feeType} fee` });
    run('INSERT INTO referrals(referrer_id,referred_id,commission_c,fee_type) VALUES(?,?,?,?)', referrer.id, userId, commission, feeType);
  });
  emit(referrer.id, 'referral', { commission: commission / 100 });
  return commission;
}

// Charge a platform fee to the wallet. Referral is paid immediately unless deferred (card ops pay on success).
function chargeFee(userId, feeType, feeC, { ref = '', note = '', deferReferral = false } = {}) {
  if (feeC <= 0) return 0;
  post(userId, `fee_${feeType}`, -feeC, { ref, note });
  if (!deferReferral) payReferral(userId, feeC, feeType, ref);
  return feeC;
}

module.exports = { post, payReferral, chargeFee };
