// Real Capitalist client. Signature: sha256(X-Request-Timestamp + body + API-secret)
const { creds } = require('./credentials');
const { sha256hex } = require('../util');

async function call(method, path, { query, body } = {}) {
  const { key, secret, base } = creds('capitalist');
  if (!key || !secret) throw new Error('Capitalist API credentials are not configured');
  const qs = query ? `?${new URLSearchParams(query)}` : '';
  const bodyStr = body !== undefined ? JSON.stringify(body) : '';
  const ts = Date.now().toString();
  const headers = {
    'API-Key': key, 'X-Request-Timestamp': ts,
    Signature: sha256hex(ts + bodyStr + secret), Accept: 'application/json',
  };
  if (method !== 'GET') headers['Content-Type'] = 'application/json';
  const res = await fetch(base + path + qs, { method, headers, body: bodyStr || undefined, signal: AbortSignal.timeout(20000) });
  const text = await res.text();
  let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    const err = new Error(`Capitalist ${method} ${path} failed (${res.status}): ${typeof data === 'string' ? data : JSON.stringify(data)}`);
    err.status = res.status; throw err;
  }
  return data;
}

module.exports = {
  accounts: (currency) => call('GET', '/v1/account/list', { query: { currency } }),
  // USDT TRC-20 address whose deposits are auto-converted into the given Capitalist account. Valid ~8h, never cache.
  depositAddressAuto: (account) => call('GET', `/v1/depositAddressAutoUSDTt/${encodeURIComponent(account)}`),
  transactions: (q = {}) => call('GET', '/v1/transactions', { query: q }),
};
