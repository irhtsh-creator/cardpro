// Real CardsPro client. Signature: CAP-SIGN = sha256(CAP-NONCE + body + query + secret)  (GET: nonce + query + secret)
const { creds } = require('./credentials');
const { sha256hex } = require('../util');

async function call(method, path, { query, body } = {}) {
  const { key, secret, base } = creds('cardspro');
  if (!key || !secret) throw new Error('CardsPro API credentials are not configured');
  const qs = query ? new URLSearchParams(query).toString() : '';
  const bodyStr = body !== undefined ? JSON.stringify(body) : '';
  const nonce = Date.now().toString();
  const sign = method === 'GET' ? sha256hex(nonce + qs + secret) : sha256hex(nonce + bodyStr + qs + secret);
  const headers = { 'CAP-TOKEN': key, 'CAP-NONCE': nonce, 'CAP-SIGN': sign, Accept: 'application/json' };
  if (method !== 'GET') headers['Content-Type'] = 'application/json';
  const res = await fetch(base + path + (qs ? `?${qs}` : ''), {
    method, headers, body: bodyStr || undefined, signal: AbortSignal.timeout(20000),
  });
  const text = await res.text();
  let data; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    const err = new Error(`CardsPro ${method} ${path} failed (${res.status}): ${typeof data === 'string' ? data : JSON.stringify(data)}`);
    err.status = res.status; err.body = data; throw err;
  }
  return data;
}

module.exports = {
  products: () => call('GET', '/products'),
  balance: (currency) => call('GET', '/account/balance', currency ? { query: { currency } } : {}),
  issue: (p) => call('POST', '/issue', { body: p }),
  details: (san) => call('GET', `/${san}/details`),
  topup: (san, b) => call('POST', `/${san}/topup`, { body: b }),
  withdraw: (san, b) => call('POST', `/${san}/withdraw`, { body: b }),
  block: (san, b) => call('POST', `/${san}/block`, { body: b }),
  freeze: (san) => call('POST', `/${san}/freeze`),
  unfreeze: (san) => call('POST', `/${san}/unfreeze`),
  otp: (san) => call('GET', `/${san}/otp-codes`),
  kycStart: (b) => call('POST', '/kyc/start', { body: b }),
  kycStatus: (externalId, sort) => call('GET', `/kyc/status/${encodeURIComponent(externalId)}/${encodeURIComponent(sort)}`),
};
