const config = require('../config');
const { get } = require('../db');
const { decrypt } = require('../util');

// Active credentials saved by the admin override the .env values.
function creds(provider) {
  const row = get('SELECT * FROM api_credentials WHERE provider=? AND active=1 ORDER BY id DESC LIMIT 1', provider);
  const env = config[provider];
  if (row) {
    return {
      key: row.api_key,
      secret: decrypt(row.api_secret_enc),
      base: row.base_url || env.base,
      account: row.account || env.account || '',
      source: 'admin',
    };
  }
  return { key: env.key, secret: env.secret, base: env.base, account: env.account || '', source: 'env' };
}

module.exports = { creds };
