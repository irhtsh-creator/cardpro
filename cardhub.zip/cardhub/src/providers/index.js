const { settings } = require('../db');
const live = { cards: require('./cardspro'), capitalist: require('./capitalist') };
const mock = require('./mock');

const mode = () => settings().provider_mode;
const isMock = () => mode() !== 'live';

// Resolve the provider at call time so the admin can flip mock/live without a restart.
const proxy = (name) => new Proxy({}, {
  get: (_, fn) => (...args) => (isMock() ? mock[name] : live[name])[fn](...args),
});

module.exports = { cards: proxy('cards'), capitalist: proxy('capitalist'), isMock, mock };
