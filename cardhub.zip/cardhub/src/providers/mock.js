// Built-in simulator that mimics the CardsPro + Capitalist APIs. No real money moves.
// Async operations answer INPROCESS and then fire the same callbacks the real provider sends.
const crypto = require('crypto');
const { get, run } = require('../db');

let callbackSink = null; // set by cardsvc to avoid circular imports
const setCallbackSink = (fn) => { callbackSink = fn; };
const later = (type, body, ms = 120) => setTimeout(() => { try { callbackSink?.(type, body); } catch (e) { console.error('mock callback failed', e); } }, ms).unref();

const load = (san) => { const r = get('SELECT json FROM mock_cards WHERE san=?', san); return r ? JSON.parse(r.json) : null; };
const save = (c) => run('INSERT INTO mock_cards(san,json) VALUES(?,?) ON CONFLICT(san) DO UPDATE SET json=excluded.json', c.san, JSON.stringify(c));
let doc = Date.now() % 1e9;
const nextDoc = () => ++doc;

const PRODUCTS = [
  { productCode: 'MOCK-VISA-ADS', currency: 'USD', issueMinAmount: 10, issueMaxAmount: 5000, topUpMinAmount: 10, topUpMaxAmount: 5000, params: { cardValidityPeriodSupported: true } },
  { productCode: 'MOCK-MC-META', currency: 'USD', issueMinAmount: 20, issueMaxAmount: 20000, topUpMinAmount: 20, topUpMaxAmount: 20000 },
  { productCode: 'MOCK-VISA-KYC', kycSort: 'S00', currency: 'USD', issueMinAmount: 50, issueMaxAmount: 100000, topUpMinAmount: 20, topUpMaxAmount: 100000, params: { issueCardEmailRequired: true } },
];

const cards = {
  products: async () => PRODUCTS,
  balance: async () => [{ total: 1000000, currency: 'USD' }],
  issue: async (p) => {
    const prod = PRODUCTS.find((x) => x.productCode === p.productCode);
    if (!prod) throw Object.assign(new Error('Unknown product'), { status: 400 });
    const san = 'mock' + crypto.randomBytes(8).toString('hex');
    const pan = '4' + String(crypto.randomInt(0, 1e7)).padStart(7, '0') + String(crypto.randomInt(0, 1e8)).padStart(8, '0');
    const d = new Date();
    save({
      san, pan, cvv: String(crypto.randomInt(100, 999)), expMonth: d.getMonth() + 1, expYear: d.getFullYear() + (p.cardValidityYears || 3),
      cardSystem: p.productCode.includes('MC') ? 'MC' : 'VISA', currency: p.currency, balance: Number(p.amount), initialBalance: Number(p.amount),
      productCode: p.productCode, cardName: p.cardName || '', status: 'active', created: d.toISOString(), otp: [],
    });
    const docid = nextDoc();
    later('CARD_ISSUE', { docid, request_id: p.request_id, status: 'EXECUTED', san, params: { amount: Number(p.amount), currency: p.currency } });
    return { type: 'ISSUE', status: 'INPROCESS', docid, request_id: p.request_id };
  },
  details: async (san) => {
    const c = load(san);
    if (!c) throw Object.assign(new Error('Card not found'), { status: 404 });
    return { created: c.created, currency: c.currency, cvv: c.cvv, san, initialBalance: c.initialBalance, productCode: c.productCode, status: c.status, balance: c.status === 'blocked' ? null : c.balance, cardNumber: c.pan, expYear: c.expYear, expMonth: c.expMonth, cardSystem: c.cardSystem, cardName: c.cardName };
  },
  topup: async (san, b) => {
    const c = load(san); if (!c || c.status === 'blocked') throw Object.assign(new Error('Card unavailable'), { status: 400 });
    c.balance += Number(b.amount); save(c);
    const docid = nextDoc();
    later('CARD_TOPUP', { docid, request_id: b.request_id, status: 'EXECUTED', san, params: { amount: Number(b.amount), currency: b.currency } });
    return { type: 'TOPUP', status: 'INPROCESS', docid, request_id: b.request_id, topup: { san, amount: Number(b.amount), currency: b.currency } };
  },
  withdraw: async (san, b) => {
    const c = load(san); if (!c || c.balance < Number(b.amount)) throw Object.assign(new Error('Insufficient card balance'), { status: 400 });
    c.balance -= Number(b.amount); save(c);
    const docid = nextDoc();
    later('CARD_WITHDRAWAL', { docid, request_id: b.request_id, status: 'EXECUTED', san, params: { amount: Number(b.amount), currency: b.currency } });
    return { type: 'WITHDRAWAL', status: 'INPROCESS', docid, request_id: b.request_id, withdrawal: { san, amount: Number(b.amount), currency: b.currency } };
  },
  block: async (san, b) => {
    const c = load(san); if (!c) throw Object.assign(new Error('Card not found'), { status: 404 });
    const released = c.balance; c.status = 'blocked'; c.balance = 0; save(c);
    const docid = nextDoc();
    later('CARD_BLOCK', { docid, request_id: b.request_id, status: 'EXECUTED', san, params: { amount: released, currency: c.currency } });
    return { type: 'BLOCK', status: 'INPROCESS', docid, request_id: b.request_id };
  },
  freeze: async (san) => { const c = load(san); c.status = 'frozen'; save(c); later('CARD_FREEZE', { san }); return { success: true, message: 'Card frozen successfully' }; },
  unfreeze: async (san) => { const c = load(san); c.status = 'active'; save(c); later('CARD_UNFREEZE', { san }); return { success: true, message: 'Card activated successfully' }; },
  otp: async (san) => (load(san)?.otp || []),
  kycStart: async (b) => ({ uuid: crypto.randomUUID(), urlForUser: `${'https://kyc.example.invalid'}/${b.kycExternalUserId}` }),
  kycStatus: async (id) => ({ kycExternalUserId: id, status: 'APPROVED', uuid: 'mock' }),

  // simulator-only: pretend the merchant side charged the card
  _simulateSpend(san, { amount, merchant = 'FACEBK ADS', mcc = '7311 ADVERTISING SERVICES', decline = false, refund = false }) {
    const c = load(san); if (!c) throw new Error('Card not found');
    const txType = decline ? 'authorization_decline' : refund ? 'refund' : 'expense';
    if (txType === 'expense') { if (c.balance < amount) throw new Error('Insufficient card balance'); c.balance -= amount; }
    if (txType === 'refund') c.balance += amount;
    save(c);
    const body = { san, txId: 'TX' + crypto.randomBytes(6).toString('hex'), txType, txDate: new Date().toISOString(), txAmount: amount, txCurrency: 'USD', billAmount: amount, billCurrency: 'USD', merchantName: merchant, merchantCountry: 'USA', mcc, authCode: String(crypto.randomInt(100000, 999999)) };
    later('CARD_TRANSACTION', body, 20);
    return body;
  },
  _simulateOtp(san, code = String(crypto.randomInt(100000, 999999))) {
    const c = load(san); c.otp = [{ code, date: new Date().toISOString() }, ...c.otp].slice(0, 10); save(c);
    later('OTP_CODE', { san, otpCode: code }, 20); return code;
  },
};

// ---- Capitalist simulator ----
const capTx = [];
const capitalist = {
  accounts: async () => [{ number: 'U0000001', currency: 'USD', name: 'Mock', balance: 0 }],
  depositAddressAuto: async () => ({ address: 'T' + crypto.randomBytes(16).toString('hex').slice(0, 33).replace(/[^a-zA-Z0-9]/g, 'x') }),
  transactions: async () => ({ transactions: capTx.map((t) => ({ ...t })), count: capTx.length }),
  _simulateIncoming(address, amount) {
    const t = { docType: 'IN', type: 'USDTTRC20', state: 'EXECUTED', fee: 0, amount: Number(amount), currency: 'USD', txId: crypto.randomBytes(16).toString('hex'), dstAddress: address, documentId: nextDoc(), createDate: new Date().toISOString() };
    capTx.push(t); return t;
  },
};

module.exports = { cards, capitalist, setCallbackSink };
