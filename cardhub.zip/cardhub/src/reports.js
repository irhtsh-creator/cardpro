const { all, get } = require('./db');

// Real-time report numbers. userId=null aggregates the whole platform (admin).
function summary(userId = null) {
  const u = userId ? 'AND user_id=?' : '';
  const p = userId ? [userId] : [];
  const num = (sql, ...a) => Object.values(get(sql, ...a) || { v: 0 })[0] || 0;
  const days = 14;
  const labels = [];
  for (let i = days - 1; i >= 0; i--) labels.push(new Date(Date.now() - i * 86400e3).toISOString().slice(0, 10));
  const series = (sql, ...a) => {
    const m = Object.fromEntries(all(sql, ...a).map((r) => [r.d, r.v]));
    return labels.map((d) => (m[d] || 0) / 100);
  };
  const since = `created_at>=date('now','-${days - 1} day')`;
  return {
    balance: userId ? get('SELECT balance_c FROM users WHERE id=?', userId).balance_c / 100 : num('SELECT COALESCE(SUM(balance_c),0) v FROM users') / 100,
    cards: all(`SELECT status, COUNT(*) n, COALESCE(SUM(balance_c),0)/100.0 AS balance FROM cards WHERE 1=1 ${u} GROUP BY status`, ...p),
    spend30: num(`SELECT COALESCE(SUM(bill_c),0) v FROM card_tx WHERE type IN ('expense','verification_expense') AND created_at>=date('now','-30 day') ${u}`, ...p) / 100,
    declines30: num(`SELECT COUNT(*) v FROM card_tx WHERE type LIKE '%decline' AND created_at>=date('now','-30 day') ${u}`, ...p),
    successful30: num(`SELECT COUNT(*) v FROM card_tx WHERE type IN ('expense','verification_expense') AND created_at>=date('now','-30 day') ${u}`, ...p),
    fees30: num(`SELECT COALESCE(-SUM(amount_c),0) v FROM ledger WHERE type LIKE 'fee_%' AND created_at>=date('now','-30 day') ${u}`, ...p) / 100,
    depositsTotal: num(`SELECT COALESCE(SUM(amount_c),0) v FROM ledger WHERE type='deposit' ${u}`, ...p) / 100,
    referralEarned: num(`SELECT COALESCE(SUM(amount_c),0) v FROM ledger WHERE type='referral' ${u}`, ...p) / 100,
    labels,
    spendSeries: series(`SELECT date(created_at) d, SUM(bill_c) v FROM card_tx WHERE type IN ('expense','verification_expense') AND ${since} ${u} GROUP BY d`, ...p),
    depositSeries: series(`SELECT date(created_at) d, SUM(amount_c) v FROM ledger WHERE type='deposit' AND ${since} ${u} GROUP BY d`, ...p),
    feeSeries: series(`SELECT date(created_at) d, -SUM(amount_c) v FROM ledger WHERE type LIKE 'fee_%' AND ${since} ${u} GROUP BY d`, ...p),
    topMerchants: all(`SELECT merchant, COUNT(*) n, SUM(bill_c)/100.0 AS total FROM card_tx WHERE type IN ('expense','verification_expense') AND merchant<>'' AND created_at>=date('now','-30 day') ${u} GROUP BY merchant ORDER BY SUM(bill_c) DESC LIMIT 5`, ...p),
    recent: all(`SELECT t.type, t.bill_c/100.0 AS amount, t.merchant, t.created_at FROM card_tx t WHERE 1=1 ${u.replace('user_id', 't.user_id')} ORDER BY t.id DESC LIMIT 8`, ...p),
  };
}

module.exports = { summary };
