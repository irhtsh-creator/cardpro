const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { get, all, run, settings, audit } = require('../db');
const { auth, sign, setCookie, clearCookie, rateLimit, publicUser } = require('../auth');
const { wrap, bad, HttpError } = require('../util');

const r = express.Router();
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function newReferralCode() {
  for (;;) {
    const c = crypto.randomBytes(5).toString('hex').toUpperCase();
    if (!get('SELECT 1 x FROM users WHERE referral_code=?', c)) return c;
  }
}
// least-loaded manager gets the new user
function pickManager() {
  if (!settings().feature_manager) return null;
  const m = get(`SELECT u.id FROM users u WHERE u.role='manager' AND u.status='active'
    ORDER BY (SELECT COUNT(*) FROM users x WHERE x.manager_id=u.id), u.id LIMIT 1`);
  return m?.id ?? null;
}

r.get('/public-config', (req, res) => {
  const s = settings();
  res.json({
    siteName: s.site_name, registrationOpen: !!s.registration_open, maintenance: !!s.maintenance_mode,
    features: { cards: !!s.feature_cards, wallet: !!s.feature_wallet, referrals: !!s.feature_referrals, kyc: !!s.feature_kyc, manager: !!s.feature_manager },
    mock: s.provider_mode !== 'live', walletMinDeposit: s.wallet_min_deposit, referralPct: s.referral_pct, kycRequiredForCards: !!s.kyc_required_for_cards,
  });
});

r.post('/signup', rateLimit(), wrap(async (req, res) => {
  const s = settings();
  if (!s.registration_open) throw new HttpError(403, 'Registration is currently closed');
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const name = String(req.body.name || '').trim().slice(0, 80);
  if (!emailRe.test(email)) throw bad('Enter a valid email address');
  if (password.length < 8) throw bad('Password must be at least 8 characters');
  if (!name) throw bad('Name is required');
  if (get('SELECT 1 x FROM users WHERE email=?', email)) throw bad('Email already registered');
  let referrer = null;
  if (req.body.referralCode) {
    referrer = get('SELECT id FROM users WHERE referral_code=?', String(req.body.referralCode).trim().toUpperCase());
    if (!referrer) throw bad('Referral code not found');
  }
  const hash = await bcrypt.hash(password, 10);
  const ins = run('INSERT INTO users(email,password_hash,name,referral_code,referred_by,manager_id) VALUES(?,?,?,?,?,?)',
    email, hash, name, newReferralCode(), referrer?.id ?? null, pickManager());
  const user = get('SELECT * FROM users WHERE id=?', ins.id);
  audit(user.id, 'signup', { referredBy: referrer?.id ?? null });
  setCookie(res, sign(user));
  res.status(201).json({ user: publicUser(user) });
}));

r.post('/login', rateLimit(), wrap(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const user = get('SELECT * FROM users WHERE email=?', email);
  const ok = user && (await bcrypt.compare(String(req.body.password || ''), user.password_hash));
  if (!ok) throw new HttpError(401, 'Invalid email or password');
  if (settings().maintenance_mode && user.role !== 'admin') throw new HttpError(503, 'Platform is under maintenance');
  run("UPDATE users SET last_login=datetime('now') WHERE id=?", user.id);
  setCookie(res, sign(user));
  res.json({ user: publicUser(user) });
}));

r.post('/logout', (req, res) => { clearCookie(res); res.json({ ok: true }); });

r.get('/me', auth, (req, res) => {
  const u = req.user;
  let manager = null;
  if (u.manager_id) {
    const m = get('SELECT id,name,email,telegram,phone,contact FROM users WHERE id=?', u.manager_id);
    if (m) manager = { id: m.id, name: m.name, email: m.email, telegram: m.telegram, phone: m.phone, ...JSON.parse(m.contact || '{}') };
  }
  res.json({ user: publicUser(u), manager });
});

r.patch('/profile', auth, wrap((req, res) => {
  const name = String(req.body.name ?? req.user.name).trim().slice(0, 80);
  if (!name) throw bad('Name is required');
  run('UPDATE users SET name=?, phone=?, telegram=? WHERE id=?', name, String(req.body.phone ?? req.user.phone).slice(0, 40), String(req.body.telegram ?? req.user.telegram).slice(0, 60), req.user.id);
  res.json({ user: publicUser(get('SELECT * FROM users WHERE id=?', req.user.id)) });
}));

r.post('/change-password', auth, rateLimit(), wrap(async (req, res) => {
  if (!(await bcrypt.compare(String(req.body.current || ''), req.user.password_hash))) throw bad('Current password is incorrect');
  const next = String(req.body.next || '');
  if (next.length < 8) throw bad('New password must be at least 8 characters');
  run('UPDATE users SET password_hash=? WHERE id=?', await bcrypt.hash(next, 10), req.user.id);
  audit(req.user.id, 'password_change');
  res.json({ ok: true });
}));

module.exports = r;
