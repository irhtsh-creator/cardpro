const express = require('express');
const bcrypt = require('bcryptjs');
const { get, all, run, tx, settings, setSetting, DEFAULTS, audit } = require('../db');
const { auth, requireRole, publicUser } = require('../auth');
const providers = require('../providers');
const { creds } = require('../providers/credentials');
const cardsvc = require('../cardsvc');
const walletsvc = require('../walletsvc');
const { post } = require('../ledger');
const { walletTx, cardTx, toCsv } = require('../txlist');
const { summary } = require('../reports');
const events = require('../events');
const { wrap, bad, HttpError, encrypt, toC } = require('../util');

const r = express.Router();
r.use(auth, requireRole('manager', 'admin'));

const page = (q, def = 25) => { const limit = Math.min(Number(q.limit) || def, 200); return { limit, offset: (Math.max(Number(q.page) || 1, 1) - 1) * limit }; };
const userRow = (u) => ({ ...publicUser(u), managerId: u.manager_id, lastLogin: u.last_login });

// A manager may only touch users assigned to them; admins may touch everyone.
function scopedUser(staff, id) {
  const u = get('SELECT * FROM users WHERE id=?', id);
  if (!u) throw new HttpError(404, 'User not found');
  if (staff.role === 'manager' && u.manager_id !== staff.id) throw new HttpError(403, 'This user is not assigned to you');
  return u;
}
const myUserIds = (staff) => all('SELECT id FROM users WHERE manager_id=?', staff.id).map((x) => x.id);

// ================= Account manager panel (manager + admin) =================
r.get('/manager/overview', (req, res) => {
  const ids = req.user.role === 'admin' ? all("SELECT id FROM users WHERE role='user'").map((x) => x.id) : myUserIds(req.user);
  const ph = ids.map(() => '?').join(',') || 'NULL';
  res.json({
    users: ids.length,
    pendingKyc: get(`SELECT COUNT(*) n FROM users WHERE kyc_status='pending' AND id IN (${ph})`, ...ids).n,
    totalBalance: (get(`SELECT COALESCE(SUM(balance_c),0) v FROM users WHERE id IN (${ph})`, ...ids).v) / 100,
    spend30: (get(`SELECT COALESCE(SUM(bill_c),0) v FROM card_tx WHERE type IN ('expense','verification_expense') AND created_at>=date('now','-30 day') AND user_id IN (${ph})`, ...ids).v) / 100,
    unread: get(`SELECT COUNT(DISTINCT user_id) n FROM messages WHERE from_staff=0 AND user_id IN (${ph}) AND id>COALESCE((SELECT MAX(id) FROM messages m2 WHERE m2.user_id=messages.user_id AND m2.from_staff=1),0)`, ...ids).n,
  });
});

r.get('/manager/users', (req, res) => {
  const w = ["u.role='user'"]; const p = [];
  if (req.user.role === 'manager') { w.push('u.manager_id=?'); p.push(req.user.id); }
  if (req.query.q) { w.push('(u.email LIKE ? OR u.name LIKE ?)'); p.push(`%${req.query.q}%`, `%${req.query.q}%`); }
  const { limit, offset } = page(req.query);
  const total = get(`SELECT COUNT(*) n FROM users u WHERE ${w.join(' AND ')}`, ...p).n;
  const rows = all(`SELECT u.*, (SELECT COUNT(*) FROM cards c WHERE c.user_id=u.id AND c.status IN ('active','frozen')) AS cards,
      (SELECT COALESCE(SUM(bill_c),0) FROM card_tx t WHERE t.user_id=u.id AND t.type IN ('expense','verification_expense') AND t.created_at>=date('now','-30 day'))/100.0 AS spend30,
      (SELECT MAX(created_at) FROM messages m WHERE m.user_id=u.id) AS last_message
    FROM users u WHERE ${w.join(' AND ')} ORDER BY u.id DESC LIMIT ? OFFSET ?`, ...p, limit, offset);
  res.json({ total, users: rows.map((u) => ({ ...userRow(u), cards: u.cards, spend30: u.spend30, lastMessage: u.last_message })) });
});

r.get('/manager/users/:id', wrap((req, res) => {
  const u = scopedUser(req.user, req.params.id);
  const k = get('SELECT * FROM kyc WHERE user_id=? ORDER BY id DESC', u.id);
  res.json({
    user: userRow(u),
    cards: all('SELECT id,name,product_code,status,balance_c/100.0 AS balance,last4,created_at FROM cards WHERE user_id=? ORDER BY id DESC', u.id),
    kyc: k && { id: k.id, status: k.status, reason: k.reason, data: JSON.parse(k.data), createdAt: k.created_at },
    summary: summary(u.id),
    notes: all('SELECT n.id,n.body,n.created_at,m.name AS author FROM manager_notes n JOIN users m ON m.id=n.manager_id WHERE n.user_id=? ORDER BY n.id DESC LIMIT 50', u.id),
  });
}));

r.post('/manager/users/:id/notes', wrap((req, res) => {
  const u = scopedUser(req.user, req.params.id);
  const body = String(req.body.body || '').trim().slice(0, 2000);
  if (!body) throw bad('Note is empty');
  run('INSERT INTO manager_notes(user_id,manager_id,body) VALUES(?,?,?)', u.id, req.user.id, body);
  res.status(201).json({ ok: true });
}));

r.get('/manager/users/:id/messages', wrap((req, res) => {
  const u = scopedUser(req.user, req.params.id);
  res.json({ messages: all('SELECT id,body,from_staff,created_at FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 100', u.id).reverse() });
}));
r.post('/manager/users/:id/messages', wrap((req, res) => {
  const u = scopedUser(req.user, req.params.id);
  const body = String(req.body.body || '').trim().slice(0, 2000);
  if (!body) throw bad('Message is empty');
  run('INSERT INTO messages(user_id,sender_id,from_staff,body) VALUES(?,?,1,?)', u.id, req.user.id, body);
  events.emit(u.id, 'message', { fromStaff: true });
  res.status(201).json({ ok: true });
}));

r.get('/manager/users/:id/transactions', wrap((req, res) => {
  const u = scopedUser(req.user, req.params.id);
  res.json({ wallet: walletTx({ userId: u.id, limit: 50 }).rows, card: cardTx({ userId: u.id, limit: 50 }).rows });
}));

r.put('/manager/profile', wrap((req, res) => {
  const c = {};
  for (const k of ['title', 'hours', 'whatsapp', 'bio']) if (req.body[k] !== undefined) c[k] = String(req.body[k]).slice(0, 200);
  const old = JSON.parse(req.user.contact || '{}');
  run('UPDATE users SET contact=?, telegram=?, phone=? WHERE id=?', JSON.stringify({ ...old, ...c }), String(req.body.telegram ?? req.user.telegram).slice(0, 60), String(req.body.phone ?? req.user.phone).slice(0, 40), req.user.id);
  res.json({ ok: true });
}));

// ================= Admin only =================
const admin = express.Router();
admin.use(requireRole('admin'));

admin.get('/stats', (req, res) => {
  const n = (sql, ...a) => Object.values(get(sql, ...a))[0] || 0;
  res.json({
    ...summary(null),
    users: n("SELECT COUNT(*) FROM users WHERE role='user'"),
    newUsers7: n("SELECT COUNT(*) FROM users WHERE role='user' AND created_at>=date('now','-7 day')"),
    pendingKyc: n("SELECT COUNT(*) FROM kyc WHERE status='pending'"),
    pendingOps: n("SELECT COUNT(*) FROM card_ops WHERE status='INPROCESS'"),
    revenueTotal: n("SELECT COALESCE(-SUM(amount_c),0) FROM ledger WHERE type LIKE 'fee_%'") / 100,
    referralPaid: n("SELECT COALESCE(SUM(commission_c),0) FROM referrals") / 100,
    liabilities: n("SELECT COALESCE(SUM(balance_c),0) FROM users") / 100,
    liveClients: events.clientCount(),
    mode: settings().provider_mode,
    recentEvents: events.recent.slice(-25).reverse(),
  });
});

admin.get('/users', (req, res) => {
  const w = ['1=1']; const p = [];
  if (req.query.q) { w.push('(email LIKE ? OR name LIKE ? OR referral_code LIKE ?)'); p.push(...Array(3).fill(`%${req.query.q}%`)); }
  if (req.query.role) { w.push('role=?'); p.push(req.query.role); }
  if (req.query.status) { w.push('status=?'); p.push(req.query.status); }
  const { limit, offset } = page(req.query);
  const total = get(`SELECT COUNT(*) n FROM users WHERE ${w.join(' AND ')}`, ...p).n;
  const rows = all(`SELECT u.*, m.name AS manager_name, (SELECT COUNT(*) FROM users x WHERE x.referred_by=u.id) AS referrals
    FROM users u LEFT JOIN users m ON m.id=u.manager_id WHERE ${w.join(' AND ').replace(/\b(email|name|referral_code|role|status)\b/g, 'u.$1')} ORDER BY u.id DESC LIMIT ? OFFSET ?`, ...p, limit, offset);
  res.json({ total, users: rows.map((u) => ({ ...userRow(u), managerName: u.manager_name, referrals: u.referrals })) });
});

admin.post('/users', wrap(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const role = ['user', 'manager', 'admin'].includes(req.body.role) ? req.body.role : 'user';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw bad('Invalid email');
  if (String(req.body.password || '').length < 8) throw bad('Password must be at least 8 characters');
  if (get('SELECT 1 x FROM users WHERE email=?', email)) throw bad('Email already exists');
  const code = require('crypto').randomBytes(5).toString('hex').toUpperCase();
  const id = run('INSERT INTO users(email,password_hash,name,role,referral_code) VALUES(?,?,?,?,?)', email, await bcrypt.hash(req.body.password, 10), String(req.body.name || email).slice(0, 80), role, code).id;
  audit(req.user.id, 'user_create', { id, role });
  res.status(201).json({ id });
}));

admin.get('/users/:id', wrap((req, res) => {
  const u = get('SELECT * FROM users WHERE id=?', req.params.id);
  if (!u) throw new HttpError(404, 'User not found');
  const k = get('SELECT * FROM kyc WHERE user_id=? ORDER BY id DESC', u.id);
  res.json({
    user: { ...userRow(u), feeOverrides: JSON.parse(u.fee_overrides || '{}'), contact: JSON.parse(u.contact || '{}'), referredBy: u.referred_by },
    cards: all('SELECT id,name,product_code,status,balance_c/100.0 AS balance,last4,created_at FROM cards WHERE user_id=? ORDER BY id DESC', u.id),
    kyc: k && { id: k.id, status: k.status, reason: k.reason, data: JSON.parse(k.data), createdAt: k.created_at },
    ledger: walletTx({ userId: u.id, limit: 30 }).rows,
    referrals: get('SELECT COUNT(*) n FROM users WHERE referred_by=?', u.id).n,
    summary: summary(u.id),
  });
}));

const FEE_KEYS = ['issue_fee_flat', 'issue_fee_pct', 'topup_fee_flat', 'topup_fee_pct', 'txn_fee_flat', 'txn_fee_pct', 'decline_fee_flat', 'card_min_deposit', 'referral_pct'];
admin.patch('/users/:id', wrap((req, res) => {
  const u = get('SELECT * FROM users WHERE id=?', req.params.id);
  if (!u) throw new HttpError(404, 'User not found');
  const b = req.body; const sets = []; const p = []; const changes = {};
  if (b.name !== undefined) { sets.push('name=?'); p.push(String(b.name).slice(0, 80)); changes.name = b.name; }
  if (b.phone !== undefined) { sets.push('phone=?'); p.push(String(b.phone).slice(0, 40)); }
  if (b.telegram !== undefined) { sets.push('telegram=?'); p.push(String(b.telegram).slice(0, 60)); }
  if (b.role !== undefined) {
    if (!['user', 'manager', 'admin'].includes(b.role)) throw bad('Invalid role');
    if (u.id === req.user.id && b.role !== 'admin') throw bad('You cannot remove your own admin role');
    sets.push('role=?'); p.push(b.role); changes.role = b.role;
  }
  if (b.status !== undefined) {
    if (!['active', 'suspended'].includes(b.status)) throw bad('Invalid status');
    if (u.id === req.user.id) throw bad('You cannot suspend yourself');
    sets.push('status=?'); p.push(b.status); changes.status = b.status;
  }
  if (b.managerId !== undefined) {
    if (b.managerId !== null) {
      const m = get("SELECT id FROM users WHERE id=? AND role IN ('manager','admin')", b.managerId);
      if (!m) throw bad('Manager not found');
    }
    sets.push('manager_id=?'); p.push(b.managerId); changes.managerId = b.managerId;
  }
  if (b.feeOverrides !== undefined) {
    const o = {};
    for (const k of FEE_KEYS) {
      const v = b.feeOverrides[k];
      if (v === '' || v === null || v === undefined) continue;
      if (!Number.isFinite(Number(v)) || Number(v) < 0) throw bad(`${k} must be a non-negative number`);
      o[k] = Number(v);
    }
    sets.push('fee_overrides=?'); p.push(JSON.stringify(o)); changes.feeOverrides = o;
  }
  if (b.kycStatus !== undefined) {
    if (!['none', 'pending', 'approved', 'declined'].includes(b.kycStatus)) throw bad('Invalid KYC status');
    sets.push('kyc_status=?'); p.push(b.kycStatus); changes.kycStatus = b.kycStatus;
  }
  if (!sets.length) throw bad('Nothing to update');
  run(`UPDATE users SET ${sets.join(',')} WHERE id=?`, ...p, u.id);
  audit(req.user.id, 'user_update', { id: u.id, ...changes });
  res.json({ ok: true });
}));

admin.post('/users/:id/adjust', wrap((req, res) => {
  const u = get('SELECT * FROM users WHERE id=?', req.params.id);
  if (!u) throw new HttpError(404, 'User not found');
  const amt = Number(req.body.amount);
  if (!Number.isFinite(amt) || amt === 0 || Math.abs(amt) > 1e7) throw bad('Enter a non-zero amount');
  const note = String(req.body.note || '').trim().slice(0, 200);
  if (!note) throw bad('A reason is required');
  const out = post(u.id, amt > 0 ? 'admin_credit' : 'admin_debit', toC(amt), { note: `${note} (by ${req.user.email})` });
  audit(req.user.id, 'balance_adjust', { user: u.id, amount: amt, note });
  res.json({ balance: out.balance_c / 100 });
}));

admin.post('/users/:id/reset-password', wrap(async (req, res) => {
  if (String(req.body.password || '').length < 8) throw bad('Password must be at least 8 characters');
  run('UPDATE users SET password_hash=? WHERE id=?', await bcrypt.hash(req.body.password, 10), req.params.id);
  audit(req.user.id, 'password_reset', { user: req.params.id });
  res.json({ ok: true });
}));

admin.get('/managers', (req, res) => {
  res.json({ managers: all(`SELECT u.id,u.name,u.email,u.status,(SELECT COUNT(*) FROM users x WHERE x.manager_id=u.id) AS users FROM users u WHERE u.role IN ('manager','admin') ORDER BY u.id`) });
});

// ----- global settings (fees, minimums, feature switches) -----
admin.get('/settings', (req, res) => res.json({ settings: settings(), defaults: DEFAULTS }));
admin.put('/settings', wrap((req, res) => {
  const changed = {};
  tx(() => {
    for (const [k, v] of Object.entries(req.body)) {
      if (!(k in DEFAULTS)) throw bad(`Unknown setting: ${k}`);
      const def = DEFAULTS[k];
      let val = v;
      if (typeof def === 'number') {
        val = Number(v);
        if (!Number.isFinite(val) || val < 0) throw bad(`${k} must be a non-negative number`);
        if (k.endsWith('_pct') && val > 100) throw bad(`${k} cannot exceed 100`);
      } else if (k === 'provider_mode') {
        if (!['mock', 'live'].includes(v)) throw bad('provider_mode must be mock or live');
      } else val = String(v).slice(0, 80);
      setSetting(k, val); changed[k] = val;
    }
  });
  audit(req.user.id, 'settings_update', changed);
  res.json({ settings: settings() });
}));

// ----- per-card-product control -----
admin.get('/products', wrap(async (req, res) => {
  res.json({ products: await cardsvc.listProducts({ fee_overrides: '{}' }, { includeDisabled: true }), raw: all('SELECT * FROM product_settings') });
}));
admin.put('/products/:code', wrap((req, res) => {
  const b = req.body;
  const n = (v) => (v === '' || v === null || v === undefined ? null : (Number.isFinite(Number(v)) && Number(v) >= 0 ? Number(v) : (() => { throw bad('Values must be non-negative numbers'); })()));
  run(`INSERT INTO product_settings(code,label,enabled,issue_fee_flat,issue_fee_pct,topup_fee_flat,topup_fee_pct,min_deposit) VALUES(?,?,?,?,?,?,?,?)
    ON CONFLICT(code) DO UPDATE SET label=excluded.label, enabled=excluded.enabled, issue_fee_flat=excluded.issue_fee_flat, issue_fee_pct=excluded.issue_fee_pct,
    topup_fee_flat=excluded.topup_fee_flat, topup_fee_pct=excluded.topup_fee_pct, min_deposit=excluded.min_deposit`,
  req.params.code, String(b.label || '').slice(0, 60), b.enabled === false || b.enabled === 0 ? 0 : 1, n(b.issueFeeFlat), n(b.issueFeePct), n(b.topupFeeFlat), n(b.topupFeePct), n(b.minDeposit));
  audit(req.user.id, 'product_update', { code: req.params.code, ...b });
  res.json({ ok: true });
}));

// ----- KYC review -----
admin.get('/kyc', (req, res) => {
  const st = req.query.status || 'pending';
  res.json({ items: all(`SELECT k.id,k.user_id,k.status,k.reason,k.data,k.created_at,k.provider_status,u.email,u.name FROM kyc k JOIN users u ON u.id=k.user_id WHERE k.status=? ORDER BY k.id DESC LIMIT 200`, st).map((k) => ({ ...k, data: JSON.parse(k.data) })) });
});
admin.put('/kyc/:id', wrap((req, res) => {
  const k = get('SELECT * FROM kyc WHERE id=?', req.params.id);
  if (!k) throw new HttpError(404, 'Not found');
  const status = req.body.status;
  if (!['approved', 'declined'].includes(status)) throw bad('status must be approved or declined');
  const reason = String(req.body.reason || '').slice(0, 300);
  if (status === 'declined' && !reason) throw bad('Give the user a reason for declining');
  tx(() => {
    run("UPDATE kyc SET status=?, reason=?, reviewed_by=?, reviewed_at=datetime('now') WHERE id=?", status, reason, req.user.id, k.id);
    run('UPDATE users SET kyc_status=? WHERE id=?', status, k.user_id);
  });
  audit(req.user.id, 'kyc_review', { id: k.id, status });
  events.emit(k.user_id, 'kyc', { status });
  res.json({ ok: true });
}));

// ----- cards, transactions, operations, deposits -----
admin.get('/cards', (req, res) => {
  const w = ['1=1']; const p = [];
  if (req.query.status) { w.push('c.status=?'); p.push(req.query.status); }
  if (req.query.q) { w.push('(u.email LIKE ? OR c.name LIKE ? OR c.last4 LIKE ?)'); p.push(...Array(3).fill(`%${req.query.q}%`)); }
  const { limit, offset } = page(req.query, 50);
  res.json({ cards: all(`SELECT c.id,c.name,c.product_code,c.status,c.balance_c/100.0 AS balance,c.last4,c.created_at,u.email,u.id AS user_id FROM cards c JOIN users u ON u.id=c.user_id WHERE ${w.join(' AND ')} ORDER BY c.id DESC LIMIT ? OFFSET ?`, ...p, limit, offset) });
});
for (const [path, fn] of [['freeze', (u, id) => cardsvc.setFrozen(u, id, true)], ['unfreeze', (u, id) => cardsvc.setFrozen(u, id, false)], ['block', (u, id) => cardsvc.blockCard(u, id)]]) {
  admin.post(`/cards/${path}/:id`, wrap(async (req, res) => { audit(req.user.id, `card_${path}`, { id: req.params.id }); res.json(await fn(req.user, req.params.id)); }));
}
admin.get('/transactions/wallet', (req, res) => res.json(walletTx(req.query)));
admin.get('/transactions/card', (req, res) => res.json(cardTx(req.query)));
admin.get('/transactions/:kind/export.csv', (req, res) => {
  const rows = (req.params.kind === 'card' ? cardTx({ ...req.query, limit: 500 }) : walletTx({ ...req.query, limit: 500 })).rows;
  res.setHeader('Content-Type', 'text/csv'); res.setHeader('Content-Disposition', `attachment; filename="all-${req.params.kind}.csv"`);
  res.send(toCsv(rows));
});
admin.get('/ops', (req, res) => {
  res.json({ ops: all(`SELECT o.id,o.type,o.status,o.amount_c/100.0 AS amount,o.fee_c/100.0 AS fee,o.request_id,o.created_at,u.email,o.card_id FROM card_ops o JOIN users u ON u.id=o.user_id WHERE o.status=? ORDER BY o.id DESC LIMIT 100`, req.query.status || 'INPROCESS') });
});
admin.post('/ops/:id/resolve', wrap((req, res) => {
  cardsvc.resolveOp(Number(req.params.id), req.body.status === 'EXECUTED' ? 'EXECUTED' : 'DECLINED', req.body.san, req.user.id);
  res.json({ ok: true });
}));
admin.get('/deposits', (req, res) => {
  res.json({ deposits: all('SELECT d.id,d.address,d.status,d.amount_c/100.0 AS amount,d.created_at,d.expires_at,d.credited_at,u.email FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC LIMIT 200') });
});
admin.post('/deposits/sync', wrap(async (req, res) => res.json({ credited: await walletsvc.syncDeposits() })));

// ----- referral control -----
admin.get('/referrals', (req, res) => {
  res.json({
    pct: settings().referral_pct, enabled: !!settings().feature_referrals,
    totals: get('SELECT COUNT(*) n, COALESCE(SUM(commission_c),0)/100.0 AS paid FROM referrals'),
    top: all(`SELECT u.id,u.email,u.name,u.referral_code,(SELECT COUNT(*) FROM users x WHERE x.referred_by=u.id) AS referred,
      COALESCE((SELECT SUM(commission_c) FROM referrals r WHERE r.referrer_id=u.id),0)/100.0 AS earned
      FROM users u WHERE EXISTS(SELECT 1 FROM users x WHERE x.referred_by=u.id) ORDER BY earned DESC LIMIT 50`),
    recent: all('SELECT r.id,a.email AS referrer,b.email AS referred,r.commission_c/100.0 AS commission,r.fee_type,r.created_at FROM referrals r JOIN users a ON a.id=r.referrer_id JOIN users b ON b.id=r.referred_id ORDER BY r.id DESC LIMIT 50'),
  });
});

// ----- API credentials -----
const maskKey = (k) => (k.length > 8 ? `${k.slice(0, 4)}…${k.slice(-4)}` : '••••');
admin.get('/credentials', (req, res) => {
  const rows = all('SELECT id,provider,label,api_key,base_url,account,active,created_at FROM api_credentials ORDER BY id DESC').map((c) => ({ ...c, api_key: maskKey(c.api_key) }));
  const env = (p) => { const c = require('../config')[p]; return { configured: !!(c.key && c.secret), key: c.key ? maskKey(c.key) : '', base: c.base, account: c.account || '' }; };
  res.json({ credentials: rows, env: { cardspro: env('cardspro'), capitalist: env('capitalist') }, mode: settings().provider_mode });
});
admin.post('/credentials', wrap((req, res) => {
  const b = req.body;
  if (!['cardspro', 'capitalist'].includes(b.provider)) throw bad('provider must be cardspro or capitalist');
  if (!b.apiKey || !b.apiSecret) throw bad('API key and secret are required');
  if (b.baseUrl && !/^https:\/\//.test(b.baseUrl)) throw bad('Base URL must start with https://');
  const id = tx(() => {
    run('UPDATE api_credentials SET active=0 WHERE provider=?', b.provider);
    return run('INSERT INTO api_credentials(provider,label,api_key,api_secret_enc,base_url,account,active) VALUES(?,?,?,?,?,?,1)',
      b.provider, String(b.label || '').slice(0, 60), String(b.apiKey).trim(), encrypt(String(b.apiSecret).trim()), String(b.baseUrl || '').trim(), String(b.account || '').trim()).id;
  });
  audit(req.user.id, 'credentials_add', { id, provider: b.provider });
  res.status(201).json({ id });
}));
admin.post('/credentials/:id/activate', wrap((req, res) => {
  const c = get('SELECT * FROM api_credentials WHERE id=?', req.params.id);
  if (!c) throw new HttpError(404, 'Not found');
  tx(() => { run('UPDATE api_credentials SET active=0 WHERE provider=?', c.provider); run('UPDATE api_credentials SET active=1 WHERE id=?', c.id); });
  audit(req.user.id, 'credentials_activate', { id: c.id });
  res.json({ ok: true });
}));
admin.delete('/credentials/:id', wrap((req, res) => { run('DELETE FROM api_credentials WHERE id=?', req.params.id); audit(req.user.id, 'credentials_delete', { id: req.params.id }); res.json({ ok: true }); }));
admin.post('/credentials/test/:provider', wrap(async (req, res) => {
  const p = req.params.provider;
  if (!['cardspro', 'capitalist'].includes(p)) throw bad('Unknown provider');
  const live = { cardspro: require('../providers/cardspro'), capitalist: require('../providers/capitalist') }[p];
  const c = creds(p);
  try {
    const out = p === 'cardspro' ? await live.products() : await live.accounts('USD');
    res.json({ ok: true, source: c.source, base: c.base, sample: Array.isArray(out) ? `${out.length} item(s) returned` : 'ok' });
  } catch (e) { res.json({ ok: false, source: c.source, base: c.base, error: e.message }); }
}));

admin.get('/audit', (req, res) => {
  res.json({ log: all('SELECT a.id,a.action,a.detail,a.created_at,u.email AS actor FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 200') });
});

r.use('/admin', admin);
module.exports = r;
