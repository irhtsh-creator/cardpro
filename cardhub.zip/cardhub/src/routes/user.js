const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('../config');
const { get, all, run, tx, settings, audit } = require('../db');
const { auth } = require('../auth');
const providers = require('../providers');
const cardsvc = require('../cardsvc');
const walletsvc = require('../walletsvc');
const { walletTx, cardTx, toCsv } = require('../txlist');
const { summary } = require('../reports');
const events = require('../events');
const { wrap, bad, HttpError, toC } = require('../util');

const r = express.Router();
r.use(auth);

const feature = (name) => (req, res, next) => (settings()[`feature_${name}`] ? next() : next(new HttpError(403, `${name} is disabled`)));

// ---------- KYC ----------
const IMG = /^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/;
function saveImage(dataUrl, label) {
  const m = IMG.exec(String(dataUrl || ''));
  if (!m) throw bad(`${label}: upload a PNG or JPEG image`);
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 4 * 1024 * 1024) throw bad(`${label}: image must be under 4 MB`);
  const png = buf.subarray(0, 4).toString('hex') === '89504e47';
  const jpg = buf.subarray(0, 2).toString('hex') === 'ffd8';
  if (!png && !jpg) throw bad(`${label}: not a valid image`);
  const name = `${crypto.randomUUID()}.${png ? 'png' : 'jpg'}`;
  fs.writeFileSync(path.join(config.uploadDir, name), buf);
  return name;
}
const kycDto = (k) => k && ({ id: k.id, status: k.status, reason: k.reason, data: JSON.parse(k.data), createdAt: k.created_at, providerUuid: k.provider_uuid, providerStatus: k.provider_status, hasFiles: { front: !!k.doc_front, back: !!k.doc_back, selfie: !!k.selfie } });

r.get('/kyc', feature('kyc'), (req, res) => {
  res.json({ status: req.user.kyc_status, kyc: kycDto(get('SELECT * FROM kyc WHERE user_id=? ORDER BY id DESC', req.user.id)) });
});

r.post('/kyc', feature('kyc'), wrap((req, res) => {
  if (req.user.kyc_status === 'approved') throw bad('You are already verified');
  if (req.user.kyc_status === 'pending') throw bad('Your verification is already under review');
  const b = req.body;
  const data = {};
  for (const [k, label, max] of [['fullName', 'Full name', 100], ['dob', 'Date of birth', 10], ['country', 'Country', 60], ['address', 'Address', 200], ['docType', 'Document type', 20], ['docNumber', 'Document number', 40]]) {
    const v = String(b[k] || '').trim();
    if (!v) throw bad(`${label} is required`);
    data[k] = v.slice(0, max);
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data.dob) || Number.isNaN(Date.parse(data.dob))) throw bad('Date of birth must be YYYY-MM-DD');
  const age = (Date.now() - Date.parse(data.dob)) / (365.25 * 86400e3);
  if (age < 18 || age > 110) throw bad('You must be at least 18 years old');
  if (!['passport', 'id_card', 'driver_license'].includes(data.docType)) throw bad('Invalid document type');
  const front = saveImage(b.front, 'Document front');
  const back = b.back ? saveImage(b.back, 'Document back') : null;
  const selfie = saveImage(b.selfie, 'Selfie');
  tx(() => {
    run("INSERT INTO kyc(user_id,data,doc_front,doc_back,selfie,status) VALUES(?,?,?,?,?,'pending')", req.user.id, JSON.stringify(data), front, back, selfie);
    run("UPDATE users SET kyc_status='pending' WHERE id=?", req.user.id);
  });
  events.emit(req.user.id, 'kyc', { status: 'pending' });
  res.status(201).json({ status: 'pending' });
}));

// KYC image: owner, admin, or the user's account manager
r.get('/kyc/:id/file/:kind', wrap((req, res) => {
  const k = get('SELECT * FROM kyc WHERE id=?', req.params.id);
  if (!k) throw new HttpError(404, 'Not found');
  const owner = get('SELECT manager_id FROM users WHERE id=?', k.user_id);
  const allowed = req.user.id === k.user_id || req.user.role === 'admin' || (req.user.role === 'manager' && owner.manager_id === req.user.id);
  if (!allowed) throw new HttpError(403, 'Forbidden');
  const col = { front: 'doc_front', back: 'doc_back', selfie: 'selfie' }[req.params.kind];
  if (!col || !k[col]) throw new HttpError(404, 'Not found');
  res.setHeader('Cache-Control', 'private, no-store');
  res.sendFile(path.resolve(config.uploadDir, path.basename(k[col])));
}));

// Provider-side KYC (needed by some card products, e.g. kycSort S00)
r.post('/kyc/provider/start', feature('kyc'), wrap(async (req, res) => {
  const k = get('SELECT * FROM kyc WHERE user_id=? ORDER BY id DESC', req.user.id);
  if (!k) throw bad('Submit your KYC details first');
  const sort = String(req.body.sort || 'S00');
  try {
    const out = await providers.cards.kycStart({ kycExternalUserId: `u${req.user.id}`, sort, callbackUrl: `${config.publicUrl}/api/webhooks/cardspro/${config.webhookSecret}` });
    run("UPDATE kyc SET provider_uuid=?, provider_status='INITIATED' WHERE id=?", out.uuid, k.id);
    res.json({ url: out.urlForUser, uuid: out.uuid });
  } catch (e) { throw new HttpError(502, `Provider KYC error: ${e.message}`); }
}));
r.post('/kyc/provider/refresh', feature('kyc'), wrap(async (req, res) => {
  const k = get('SELECT * FROM kyc WHERE user_id=? AND provider_uuid IS NOT NULL ORDER BY id DESC', req.user.id);
  if (!k) throw bad('Provider KYC not started');
  const st = await providers.cards.kycStatus(`u${req.user.id}`, String(req.body.sort || 'S00'));
  run('UPDATE kyc SET provider_status=? WHERE id=?', st.status, k.id);
  res.json({ providerStatus: st.status, reason: st.reason || '' });
}));

// ---------- cards ----------
const cardDto = (c) => ({
  id: c.id, name: c.name, productCode: c.product_code, status: c.status, balance: c.balance_c / 100, initial: c.initial_c / 100,
  last4: c.last4, brand: c.brand, expMonth: c.exp_month, expYear: c.exp_year, createdAt: c.created_at, currency: c.currency,
});

r.get('/cards/products', feature('cards'), wrap(async (req, res) => res.json({ products: await cardsvc.listProducts(req.user) })));

r.get('/cards', feature('cards'), (req, res) => {
  res.json({ cards: all('SELECT * FROM cards WHERE user_id=? ORDER BY id DESC', req.user.id).map(cardDto) });
});

r.post('/cards/issue', feature('cards'), wrap(async (req, res) => {
  res.status(201).json({ card: cardDto(await cardsvc.issueCard(req.user, req.body)) });
}));

r.get('/cards/:id', feature('cards'), wrap((req, res) => {
  const c = cardsvc.requireOwnedCard(req.user, req.params.id);
  res.json({
    card: cardDto(c),
    ops: all('SELECT type,status,amount_c/100.0 AS amount,fee_c/100.0 AS fee,created_at FROM card_ops WHERE card_id=? ORDER BY id DESC LIMIT 30', c.id),
    transactions: cardTx({ cardId: c.id, limit: 50 }).rows,
  });
}));

const act = (fn) => wrap(async (req, res) => res.json(await fn(req)));
r.post('/cards/:id/topup', feature('cards'), act((req) => cardsvc.topupCard(req.user, req.params.id, req.body.amount)));
r.post('/cards/:id/withdraw', feature('cards'), act((req) => cardsvc.withdrawCard(req.user, req.params.id, req.body.amount)));
r.post('/cards/:id/freeze', feature('cards'), act((req) => cardsvc.setFrozen(req.user, req.params.id, true)));
r.post('/cards/:id/unfreeze', feature('cards'), act((req) => cardsvc.setFrozen(req.user, req.params.id, false)));
r.post('/cards/:id/block', feature('cards'), act((req) => cardsvc.blockCard(req.user, req.params.id)));
r.post('/cards/:id/reveal', feature('cards'), act((req) => cardsvc.revealCard(req.user, req.params.id)));
r.get('/cards/:id/otp', feature('cards'), act((req) => cardsvc.otpCodes(req.user, req.params.id)));
r.post('/cards/:id/refresh', feature('cards'), wrap(async (req, res) => res.json({ card: cardDto(await cardsvc.refreshCard(req.user, req.params.id)) })));

// Simulator-only helpers so every flow can be exercised without real money
const mockOnly = (req, res, next) => (providers.isMock() ? next() : next(new HttpError(403, 'Only available in simulator mode')));
r.post('/cards/:id/simulate-spend', mockOnly, wrap((req, res) => {
  const c = cardsvc.requireOwnedCard(req.user, req.params.id);
  const amount = Number(req.body.amount);
  if (!(amount > 0)) throw bad('amount must be positive');
  res.json(providers.mock.cards._simulateSpend(c.san, { amount, merchant: req.body.merchant || 'FACEBK ADS', decline: !!req.body.decline, refund: !!req.body.refund }));
}));
r.post('/cards/:id/simulate-otp', mockOnly, wrap((req, res) => {
  const c = cardsvc.requireOwnedCard(req.user, req.params.id);
  res.json({ code: providers.mock.cards._simulateOtp(c.san) });
}));

// ---------- wallet ----------
r.get('/wallet', feature('wallet'), (req, res) => {
  const s = settings();
  res.json({
    balance: req.user.balance_c / 100, network: 'USDT TRC-20', minDeposit: s.wallet_min_deposit,
    deposits: all('SELECT id,address,network,status,amount_c/100.0 AS amount,created_at,expires_at,credited_at FROM deposits WHERE user_id=? ORDER BY id DESC LIMIT 20', req.user.id),
  });
});
r.post('/wallet/deposit-address', feature('wallet'), wrap(async (req, res) => {
  const d = await walletsvc.createDepositAddress(req.user);
  res.status(201).json({ deposit: { id: d.id, address: d.address, network: d.network, expiresAt: d.expires_at } });
}));
r.post('/wallet/sync', feature('wallet'), wrap(async (req, res) => res.json({ credited: await walletsvc.syncDeposits() })));
r.post('/wallet/simulate-deposit', mockOnly, wrap(async (req, res) => {
  const amount = Number(req.body.amount);
  if (!(amount > 0)) throw bad('amount must be positive');
  const dep = get('SELECT * FROM deposits WHERE user_id=? ORDER BY id DESC', req.user.id);
  if (!dep) throw bad('Generate a deposit address first');
  providers.mock.capitalist._simulateIncoming(dep.address, amount);
  res.json({ credited: await walletsvc.syncDeposits() });
}));

// ---------- transactions ----------
r.get('/transactions/wallet', (req, res) => res.json(walletTx({ ...req.query, userId: req.user.id })));
r.get('/transactions/card', (req, res) => res.json(cardTx({ ...req.query, userId: req.user.id })));
r.get('/transactions/:kind/export.csv', wrap((req, res) => {
  const f = { ...req.query, userId: req.user.id, limit: 500, page: 1 };
  const rows = req.params.kind === 'card' ? cardTx(f).rows : walletTx(f).rows;
  res.setHeader('Content-Type', 'text/csv'); res.setHeader('Content-Disposition', `attachment; filename="${req.params.kind}-transactions.csv"`);
  res.send(toCsv(rows));
}));

// ---------- referrals ----------
r.get('/referrals', feature('referrals'), (req, res) => {
  const s = settings();
  const referred = all(`SELECT u.id, u.name, u.email, u.created_at,
      COALESCE((SELECT SUM(commission_c) FROM referrals x WHERE x.referred_id=u.id AND x.referrer_id=?),0)/100.0 AS earned
    FROM users u WHERE u.referred_by=? ORDER BY u.id DESC`, req.user.id, req.user.id)
    .map((x) => ({ ...x, email: x.email.replace(/^(.).*(@.*)$/, '$1***$2') }));
  res.json({
    code: req.user.referral_code, link: `${config.publicUrl}/#/signup?ref=${req.user.referral_code}`,
    pct: JSON.parse(req.user.fee_overrides || '{}').referral_pct ?? s.referral_pct,
    totalEarned: all("SELECT COALESCE(SUM(amount_c),0)/100.0 AS v FROM ledger WHERE user_id=? AND type='referral'", req.user.id)[0].v,
    count: referred.length, referred,
    recent: all('SELECT commission_c/100.0 AS commission, fee_type, created_at FROM referrals WHERE referrer_id=? ORDER BY id DESC LIMIT 20', req.user.id),
  });
});

// ---------- reports + realtime stream ----------
r.get('/reports/summary', (req, res) => res.json(summary(req.user.id)));
r.get('/stream', (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders();
  res.write('event: hello\ndata: {}\n\n');
  events.addClient(res, req.user);
});

// ---------- account manager / support chat ----------
r.get('/support/messages', feature('manager'), (req, res) => {
  res.json({ messages: all('SELECT id,body,from_staff,created_at FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 100', req.user.id).reverse() });
});
r.post('/support/messages', feature('manager'), wrap((req, res) => {
  const body = String(req.body.body || '').trim().slice(0, 2000);
  if (!body) throw bad('Message is empty');
  const id = run('INSERT INTO messages(user_id,sender_id,from_staff,body) VALUES(?,?,0,?)', req.user.id, req.user.id, body).id;
  if (req.user.manager_id) events.emit(req.user.manager_id, 'message', { userId: req.user.id });
  events.emit(req.user.id, 'message', { id });
  res.status(201).json({ id });
}));

module.exports = r;
