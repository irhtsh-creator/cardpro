const express = require('express');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const config = require('./config');
const { get, run, settings, audit } = require('./db');
const { jsonOnly } = require('./auth');
const { HttpError } = require('./util');
const cardsvc = require('./cardsvc');
const walletsvc = require('./walletsvc');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'");
  next();
});
app.use(express.json({ limit: '20mb' })); // KYC images arrive as base64
app.use((req, res, next) => { if (req.body === undefined) req.body = {}; next(); }); // Express 5 leaves body undefined when empty
app.use('/api', jsonOnly);

// ---- provider webhooks (public, protected by secret in URL) ----
const safeEq = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
app.post('/api/webhooks/cardspro/:secret', (req, res, next) => {
  if (!safeEq(String(req.params.secret), config.webhookSecret)) return next(new HttpError(403, 'Forbidden'));
  const type = req.headers['x-cp-callback-type'];
  if (!type) return next(new HttpError(400, 'Missing X-CP-Callback-Type'));
  try { res.json(cardsvc.handleCallback(String(type), req.body || {})); } catch (e) { console.error('callback error', e); next(new HttpError(500, 'callback failed')); }
});
app.post('/api/webhooks/capitalist/:secret', (req, res, next) => {
  if (!safeEq(String(req.params.secret), config.webhookSecret)) return next(new HttpError(403, 'Forbidden'));
  walletsvc.syncDeposits().catch((e) => console.error('sync failed', e.message)); // never trust the payload; re-read from the API
  res.json({ ok: true });
});

app.use('/api/auth', require('./routes/auth'));
app.use('/api', require('./routes/user'));
app.use('/api', require('./routes/staff'));
app.use('/api', (req, res, next) => next(new HttpError(404, 'Not found')));

app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: 0 }));
app.get('/{*splat}', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err.type === 'entity.too.large') err = new HttpError(413, 'Upload too large');
  if (err instanceof SyntaxError && err.status === 400) err = new HttpError(400, 'Invalid JSON');
  const status = err.status || 500;
  if (!err.status) console.error(err);
  res.status(status).json({ error: status >= 500 && !err.status ? 'Internal server error' : err.message });
});

async function seedAdmin() {
  if (get("SELECT 1 x FROM users WHERE role='admin'")) return;
  const code = crypto.randomBytes(5).toString('hex').toUpperCase();
  run("INSERT INTO users(email,password_hash,name,role,referral_code) VALUES(?,?,?,'admin',?)", config.adminEmail, await bcrypt.hash(config.adminPassword, 10), 'Administrator', code);
  audit(null, 'seed_admin', config.adminEmail);
  console.log(`Seeded admin ${config.adminEmail}${config.adminPassword === 'ChangeMe!234' ? '  (default password – change it now!)' : ''}`);
}

async function start(port = config.port) {
  await seedAdmin();
  if (config.webhookSecret === 'change-this-webhook-secret' || config.appSecret === 'dev-only-secret-change-me') {
    console.warn('WARNING: APP_SECRET / WEBHOOK_SECRET are defaults. Set strong values in .env before going live.');
  }
  const timer = setInterval(() => walletsvc.syncDeposits().catch((e) => console.error('deposit sync failed:', e.message)), 60000);
  timer.unref();
  return new Promise((resolve) => {
    const server = app.listen(port, () => {
      console.log(`CardHub running on http://localhost:${server.address().port}  [provider mode: ${settings().provider_mode}]`);
      resolve(server);
    });
  });
}

if (require.main === module) start();
module.exports = { app, start };
