const { all, get } = require('./db');

function filters(q, alias, cols) {
  const w = []; const p = [];
  if (q.userId) { w.push(`${alias}.user_id=?`); p.push(Number(q.userId)); }
  if (q.type) { w.push(`${alias}.type=?`); p.push(String(q.type)); }
  if (q.from) { w.push(`${alias}.created_at>=?`); p.push(String(q.from)); }
  if (q.to) { w.push(`${alias}.created_at<=?`); p.push(String(q.to) + ' 23:59:59'); }
  if (q.cardId) { w.push(`${alias}.card_id=?`); p.push(Number(q.cardId)); }
  if (q.q) { w.push('(' + cols.map((c) => `${c} LIKE ?`).join(' OR ') + ')'); cols.forEach(() => p.push(`%${q.q}%`)); }
  if (q.scopeUserIds) { w.push(`${alias}.user_id IN (${q.scopeUserIds.map(() => '?').join(',') || 'NULL'})`); p.push(...q.scopeUserIds); }
  return { where: w.length ? 'WHERE ' + w.join(' AND ') : '', p };
}
const page = (q) => {
  const limit = Math.min(Math.max(Number(q.limit) || 25, 1), 500);
  return { limit, offset: ((Math.max(Number(q.page) || 1, 1)) - 1) * limit };
};

function walletTx(q) {
  const { where, p } = filters(q, 'l', ['l.note', 'l.ref', 'l.type']);
  const { limit, offset } = page(q);
  const total = get(`SELECT COUNT(*) n FROM ledger l ${where}`, ...p).n;
  const rows = all(`SELECT l.id,l.user_id,u.email,l.created_at,l.type,l.amount_c/100.0 AS amount,l.balance_after_c/100.0 AS balance_after,l.note,l.ref
    FROM ledger l JOIN users u ON u.id=l.user_id ${where} ORDER BY l.id DESC LIMIT ? OFFSET ?`, ...p, limit, offset);
  return { total, rows };
}

function cardTx(q) {
  const { where, p } = filters(q, 't', ['t.merchant', 't.tx_id', 't.mcc']);
  const { limit, offset } = page(q);
  const total = get(`SELECT COUNT(*) n FROM card_tx t ${where}`, ...p).n;
  const rows = all(`SELECT t.id,t.user_id,u.email,t.card_id,c.last4,t.created_at,t.type,t.amount_c/100.0 AS amount,t.currency,t.bill_c/100.0 AS bill,
    t.platform_fee_c/100.0 AS platform_fee,t.merchant,t.mcc,t.country,t.tx_id
    FROM card_tx t JOIN users u ON u.id=t.user_id JOIN cards c ON c.id=t.card_id ${where} ORDER BY t.id DESC LIMIT ? OFFSET ?`, ...p, limit, offset);
  return { total, rows };
}

function toCsv(rows) {
  if (!rows.length) return '';
  const cols = Object.keys(rows[0]);
  const esc = (v) => {
    let s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@]/.test(s)) s = "'" + s; // neutralize spreadsheet formula injection
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [cols.join(','), ...rows.map((r) => cols.map((c) => esc(r[c])).join(','))].join('\n');
}

module.exports = { walletTx, cardTx, toCsv };
