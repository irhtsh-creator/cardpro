const crypto = require('crypto');
const config = require('./config');

const toC = (x) => Math.round(Number(x) * 100);
const toD = (c) => Math.round(c) / 100;
const rid = () => crypto.randomUUID().replace(/-/g, ''); // 32 chars, fits provider's 12-36 rule
const sha256hex = (s) => crypto.createHash('sha256').update(s).digest('hex');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (m) => new HttpError(400, m);

function parseMoney(v, field = 'amount') {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) throw bad(`${field} must be a positive number`);
  const c = toC(n);
  if (c <= 0) throw bad(`${field} is too small`);
  return c;
}

// AES-256-GCM for API secrets stored in the database
const key = crypto.createHash('sha256').update(config.appSecret).digest();
function encrypt(text) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([c.update(text, 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map((b) => b.toString('base64')).join('.');
}
function decrypt(blob) {
  const [iv, tag, enc] = blob.split('.').map((s) => Buffer.from(s, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', key, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
}

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { toC, toD, rid, sha256hex, HttpError, bad, parseMoney, encrypt, decrypt, wrap };
