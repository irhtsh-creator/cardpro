const { get, all, run, tx, settings, audit } = require('./db');
const providers = require('./providers');
const { creds } = require('./providers/credentials');
const { post } = require('./ledger');
const { emit } = require('./events');
const { toC, bad, HttpError } = require('./util');

// New USDT TRC-20 address whose deposits Capitalist converts to fiat on our account. Addresses are short-lived: never reuse old ones.
async function createDepositAddress(user) {
  if (!settings().feature_wallet) throw new HttpError(403, 'Wallet deposits are disabled');
  if (user.status !== 'active') throw new HttpError(403, 'Account suspended');
  const account = providers.isMock() ? 'U0000001' : creds('capitalist').account;
  if (!account) throw bad('Capitalist account is not configured. Admin: set the receiving account under API Credentials.');
  let r;
  try { r = await providers.capitalist.depositAddressAuto(account); }
  catch (e) { throw new HttpError(502, `Could not generate address: ${e.message}`); }
  if (!r?.address) throw new HttpError(502, 'Provider returned no address');
  const expires = new Date(Date.now() + 8 * 3600e3).toISOString();
  const d = run('INSERT INTO deposits(user_id,address,expires_at) VALUES(?,?,?)', user.id, r.address, expires);
  return get('SELECT * FROM deposits WHERE id=?', d.id);
}

let syncing = false;
// Match incoming converted transactions against issued addresses and credit the owner's wallet exactly once per provider transaction.
async function syncDeposits() {
  if (syncing) return 0;
  syncing = true;
  let credited = 0;
  try {
    if (!providers.isMock() && !creds('capitalist').key) return 0;
    const since = new Date(Date.now() - 3 * 86400e3).toISOString();
    const res = await providers.capitalist.transactions({ limit: 200, periodStart: since });
    const minC = Math.round(settings().wallet_min_deposit * 100);
    for (const t of res?.transactions || []) {
      if (t.docType !== 'IN' || t.state !== 'EXECUTED' || !t.dstAddress) continue;
      const key = String(t.documentId ?? t.txId);
      if (get('SELECT 1 x FROM deposits WHERE provider_tx=?', key)) continue;
      const dep = get('SELECT * FROM deposits WHERE address=? ORDER BY id LIMIT 1', t.dstAddress);
      if (!dep) continue;
      const amountC = toC(t.amount);
      tx(() => {
        const belowMin = amountC < minC;
        if (dep.provider_tx) {
          run('INSERT INTO deposits(user_id,address,status,amount_c,provider_tx,expires_at,credited_at) VALUES(?,?,?,?,?,?,datetime(\'now\'))', dep.user_id, dep.address, belowMin ? 'below_min' : 'credited', amountC, key, dep.expires_at);
        } else {
          run("UPDATE deposits SET status=?, amount_c=?, provider_tx=?, credited_at=datetime('now') WHERE id=?", belowMin ? 'below_min' : 'credited', amountC, key, dep.id);
        }
        if (!belowMin) { post(dep.user_id, 'deposit', amountC, { ref: key, note: 'USDT TRC-20 deposit (auto-converted)' }); credited++; }
        else audit(null, 'deposit_below_min', { user: dep.user_id, amount: amountC / 100, key });
      });
      emit(dep.user_id, 'deposit', { amount: amountC / 100 });
    }
  } finally { syncing = false; }
  return credited;
}

module.exports = { createDepositAddress, syncDeposits };
