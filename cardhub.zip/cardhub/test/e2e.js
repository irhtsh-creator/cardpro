// End-to-end test: boots the real server on a temp DB in simulator mode and exercises every feature.
const os = require('os');
const fs = require('fs');
const path = require('path');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'cardhub-'));
Object.assign(process.env, {
  DB_FILE: path.join(tmp, 't.db'), UPLOAD_DIR: path.join(tmp, 'up'), PROVIDER_MODE: 'mock', RATE_LIMIT: '1000',
  APP_SECRET: 'test-secret', WEBHOOK_SECRET: 'whsec', ADMIN_EMAIL: 'admin@t.io', ADMIN_PASSWORD: 'AdminPass123',
  CARDSPRO_API_KEY: '', CARDSPRO_API_SECRET: '',
});
const { start } = require('../src/server');
const { get, run, all } = require('../src/db');

let base; let pass = 0; let fail = 0;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function check(name, cond, extra = '') { if (cond) { pass++; console.log(`  ok   ${name}`); } else { fail++; console.log(`  FAIL ${name} ${extra}`); } }
const eq = (name, a, b) => check(name, JSON.stringify(a) === JSON.stringify(b), `(got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`);
async function until(fn, ms = 4000) { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await sleep(40); } return null; }

function client() {
  let cookie = '';
  const call = async (method, p, body, extra = {}) => {
    const res = await fetch(base + p, { method, headers: { 'content-type': 'application/json', ...(cookie ? { cookie } : {}), ...extra }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    const text = await res.text(); let json; try { json = JSON.parse(text); } catch { json = text; }
    return { status: res.status, body: json, headers: res.headers };
  };
  return { get: (p) => call('GET', p), post: (p, b = {}) => call('POST', p, b), put: (p, b) => call('PUT', p, b), patch: (p, b) => call('PATCH', p, b), del: (p) => call('DELETE', p), raw: call, cookie: () => cookie };
}
// 1x1 PNG
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const kycBody = (o = {}) => ({ fullName: 'Test User', dob: '1990-05-01', country: 'Germany', address: '1 Main St', docType: 'passport', docNumber: 'X123456', front: PNG, selfie: PNG, ...o });
const bal = async (c) => (await c.get('/api/auth/me')).body.user.balance;
const webhook = (type, body, secret = 'whsec') => fetch(`${base}/api/webhooks/cardspro/${secret}`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-cp-callback-type': type }, body: JSON.stringify(body) });

async function fund(c, amount) {
  const a = await c.post('/api/wallet/deposit-address'); if (a.status !== 201) throw new Error('addr ' + JSON.stringify(a.body));
  const r = await c.post('/api/wallet/simulate-deposit', { amount }); if (r.status !== 200) throw new Error('dep ' + JSON.stringify(r.body));
}

(async () => {
  const server = await start(0);
  base = `http://localhost:${server.address().port}`;
  const admin = client(); const alice = client(); const bob = client(); const mgr = client(); const eve = client();

  console.log('\n# auth');
  eq('public config 200', (await alice.get('/api/auth/public-config')).status, 200);
  eq('unauthenticated -> 401', (await alice.get('/api/cards')).status, 401);
  eq('bad email rejected', (await alice.post('/api/auth/signup', { email: 'nope', password: 'password123', name: 'A' })).status, 400);
  eq('short password rejected', (await alice.post('/api/auth/signup', { email: 'a@t.io', password: 'short', name: 'A' })).status, 400);
  eq('admin login', (await admin.post('/api/auth/login', { email: 'admin@t.io', password: 'AdminPass123' })).status, 200);
  eq('wrong password -> 401', (await client().post('/api/auth/login', { email: 'admin@t.io', password: 'bad' })).status, 401);
  const mk = await admin.post('/api/admin/users', { email: 'mgr@t.io', password: 'ManagerPass1', name: 'Mia Manager', role: 'manager' });
  eq('admin creates manager', mk.status, 201);
  const mgrId = mk.body.id;
  const sa = await alice.post('/api/auth/signup', { email: 'alice@t.io', password: 'password123', name: 'Alice' });
  eq('alice signup', sa.status, 201);
  eq('duplicate email rejected', (await client().post('/api/auth/signup', { email: 'alice@t.io', password: 'password123', name: 'A2' })).status, 400);
  const aliceCode = (await alice.get('/api/auth/me')).body.user.referralCode;
  eq('bad referral code rejected', (await client().post('/api/auth/signup', { email: 'x@t.io', password: 'password123', name: 'X', referralCode: 'NOPE' })).status, 400);
  const sb = await bob.post('/api/auth/signup', { email: 'bob@t.io', password: 'password123', name: 'Bob', referralCode: aliceCode });
  eq('bob signup with alice referral', sb.status, 201);
  const me = (await bob.get('/api/auth/me')).body;
  eq('bob auto-assigned to manager', me.user.managerId, mgrId);
  eq('bob sees manager contact', me.manager?.name, 'Mia Manager');
  eq('user cannot reach admin API', (await alice.get('/api/admin/users')).status, 403);
  eq('user cannot reach manager API', (await alice.get('/api/manager/users')).status, 403);
  eq('logout', (await eve.post('/api/auth/logout')).status, 200);
  eq('profile update', (await alice.patch('/api/auth/profile', { name: 'Alice A', telegram: '@alice' })).body.user.telegram, '@alice');

  console.log('\n# KYC');
  const prods = await alice.get('/api/cards/products');
  check('products listed', prods.body.products?.length >= 2);
  eq('issue blocked before KYC', (await alice.post('/api/cards/issue', { productCode: 'MOCK-VISA-ADS', amount: 20 })).status, 403);
  eq('kyc: missing field rejected', (await alice.post('/api/kyc', kycBody({ fullName: '' }))).status, 400);
  eq('kyc: underage rejected', (await alice.post('/api/kyc', kycBody({ dob: '2015-01-01' }))).status, 400);
  eq('kyc: non-image rejected', (await alice.post('/api/kyc', kycBody({ front: 'data:text/html;base64,PGI+' }))).status, 400);
  eq('kyc: fake png rejected', (await alice.post('/api/kyc', kycBody({ front: 'data:image/png;base64,AAAA' }))).status, 400);
  eq('kyc submitted', (await alice.post('/api/kyc', kycBody())).status, 201);
  eq('kyc status pending', (await alice.get('/api/kyc')).body.status, 'pending');
  eq('kyc double submit rejected', (await alice.post('/api/kyc', kycBody())).status, 400);
  const q = (await admin.get('/api/admin/kyc?status=pending')).body.items;
  eq('admin sees pending kyc', q.length, 1);
  eq('decline needs reason', (await admin.put(`/api/admin/kyc/${q[0].id}`, { status: 'declined' })).status, 400);
  eq('kyc declined', (await admin.put(`/api/admin/kyc/${q[0].id}`, { status: 'declined', reason: 'Photo is blurry' })).status, 200);
  eq('user sees decline reason', (await alice.get('/api/kyc')).body.kyc.reason, 'Photo is blurry');
  eq('kyc resubmit after decline', (await alice.post('/api/kyc', kycBody())).status, 201);
  const q2 = (await admin.get('/api/admin/kyc?status=pending')).body.items[0];
  eq('stranger cannot view kyc file', (await bob.get(`/api/kyc/${q2.id}/file/front`)).status, 403);
  eq('owner can view kyc file', (await alice.get(`/api/kyc/${q2.id}/file/front`)).status, 200);
  eq('kyc approved', (await admin.put(`/api/admin/kyc/${q2.id}`, { status: 'approved' })).status, 200);
  eq('alice kyc approved', (await alice.get('/api/auth/me')).body.user.kycStatus, 'approved');
  eq('bob kyc', (await bob.post('/api/kyc', kycBody({ fullName: 'Bob B' }))).status, 201);
  await admin.put(`/api/admin/kyc/${(await admin.get('/api/admin/kyc?status=pending')).body.items[0].id}`, { status: 'approved' });
  await mgr.post('/api/auth/login', { email: 'mgr@t.io', password: 'ManagerPass1' });
  const bobKyc = (await mgr.get(`/api/manager/users/${me.user.id}`)).body.kyc;
  eq('manager can see assigned user kyc file', (await mgr.get(`/api/kyc/${bobKyc.id}/file/selfie`)).status, 200);

  console.log('\n# wallet (USDT TRC-20 auto-conversion)');
  const addr = await bob.post('/api/wallet/deposit-address');
  eq('deposit address created', addr.status, 201);
  check('address looks valid', /^T[a-zA-Z0-9]{20,}/.test(addr.body.deposit.address));
  await bob.post('/api/wallet/simulate-deposit', { amount: 5 });
  eq('below-minimum deposit not credited', await bal(bob), 0);
  eq('deposit credited ($200)', (await bob.post('/api/wallet/simulate-deposit', { amount: 200 })).status, 200);
  eq('balance after deposit', await bal(bob), 200);
  await bob.post('/api/wallet/sync'); await bob.post('/api/wallet/sync');
  eq('sync is idempotent (no double credit)', await bal(bob), 200);
  await fund(alice, 100);
  eq('alice funded', await bal(alice), 100);

  console.log('\n# cards + fees');
  eq('below min deposit rejected', (await bob.post('/api/cards/issue', { productCode: 'MOCK-VISA-ADS', amount: 5 })).status, 400);
  eq('unknown product rejected', (await bob.post('/api/cards/issue', { productCode: 'NOPE', amount: 50 })).status, 400);
  eq('insufficient funds rejected', (await bob.post('/api/cards/issue', { productCode: 'MOCK-VISA-ADS', amount: 5000 })).status, 400);
  eq('balance untouched after rejections', await bal(bob), 200);
  const issued = await bob.post('/api/cards/issue', { productCode: 'MOCK-VISA-ADS', amount: 50, name: 'FB Ads #1' });
  eq('card issue accepted', issued.status, 201);
  const cardId = issued.body.card.id;
  eq('issue debits deposit + fee immediately ($50 + $2 + 2% = $53)', await bal(bob), 147);
  const live = await until(async () => { const c = (await bob.get(`/api/cards/${cardId}`)).body.card; return c.status === 'active' ? c : null; });
  check('card becomes active via callback', !!live);
  eq('card balance = deposit', live?.balance, 50);
  check('card has last4', /^\d{4}$/.test(live?.last4 || ''));
  eq('referrer got 10% of issue fee ($0.30)', Math.round((await bal(alice)) * 100) - 10000, 30);
  const rev = (await bob.post(`/api/cards/${cardId}/reveal`)).body;
  check('reveal returns PAN + CVV', /^\d{16}$/.test(rev.number) && /^\d{3}$/.test(rev.cvv));
  eq('other user cannot access card', (await alice.get(`/api/cards/${cardId}`)).status, 404);
  eq('other user cannot reveal card', (await alice.post(`/api/cards/${cardId}/reveal`)).status, 404);

  eq('top-up accepted', (await bob.post(`/api/cards/${cardId}/topup`, { amount: 20 })).status, 200);
  eq('top-up debits amount + 3% ($20.60)', Math.round((await bal(bob)) * 100), 14700 - 2060);
  await until(async () => (await bob.get(`/api/cards/${cardId}`)).body.card.balance === 70);
  eq('card balance after top-up', (await bob.get(`/api/cards/${cardId}`)).body.card.balance, 70);
  eq('top-up below provider minimum rejected', (await bob.post(`/api/cards/${cardId}/topup`, { amount: 1 })).status, 400);

  const spend = await bob.post(`/api/cards/${cardId}/simulate-spend`, { amount: 10, merchant: 'FACEBK ADS' });
  eq('spend simulated', spend.status, 200);
  await until(async () => (await bob.get(`/api/cards/${cardId}`)).body.card.balance === 60);
  eq('card balance after spend', (await bob.get(`/api/cards/${cardId}`)).body.card.balance, 60);
  const wBefore = Math.round((await bal(bob)) * 100);
  const ct = (await bob.get('/api/transactions/card')).body;
  eq('card transaction recorded', ct.rows[0].type, 'expense');
  eq('txn fee charged (0.5% of $10 = $0.05)', ct.rows[0].platform_fee, 0.05);
  await bob.post(`/api/cards/${cardId}/simulate-spend`, { amount: 3, decline: true });
  await until(async () => Math.round((await bal(bob)) * 100) === wBefore - 30);
  eq('decline fee charged ($0.30)', Math.round((await bal(bob)) * 100), wBefore - 30);
  eq('referrer paid on issue ($0.30) + top-up ($0.06) + decline ($0.03) fees', Math.round((await bal(alice)) * 100), 10000 + 30 + 6 + 3);

  // idempotent callback
  const dup = { san: live.id && (await bob.get(`/api/cards/${cardId}`)) && get('SELECT san FROM cards WHERE id=?', cardId).san, txId: 'DUPTX1', txType: 'expense', txAmount: 1, txCurrency: 'USD', billAmount: 1, billCurrency: 'USD', merchantName: 'DUP' };
  await webhook('CARD_TRANSACTION', dup); await webhook('CARD_TRANSACTION', dup);
  eq('duplicate callback stored once', get("SELECT COUNT(*) n FROM card_tx WHERE tx_id='DUPTX1'").n, 1);
  eq('webhook rejects wrong secret', (await webhook('CARD_TRANSACTION', dup, 'wrong')).status, 403);
  eq('webhook rejects missing type', (await fetch(`${base}/api/webhooks/cardspro/whsec`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' })).status, 400);

  eq('freeze', (await bob.post(`/api/cards/${cardId}/freeze`)).body.status, 'frozen');
  eq('cannot withdraw... frozen allows withdraw, top-up allowed', (await bob.post(`/api/cards/${cardId}/topup`, { amount: 10 })).status, 200);
  eq('unfreeze', (await bob.post(`/api/cards/${cardId}/unfreeze`)).body.status, 'active');
  await sleep(200);
  const w0 = Math.round((await bal(bob)) * 100);
  eq('withdraw too much rejected', (await bob.post(`/api/cards/${cardId}/withdraw`, { amount: 9999 })).status, 400);
  eq('withdraw accepted', (await bob.post(`/api/cards/${cardId}/withdraw`, { amount: 15 })).status, 200);
  await until(async () => Math.round((await bal(bob)) * 100) === w0 + 1500);
  eq('withdrawal credited to wallet', Math.round((await bal(bob)) * 100), w0 + 1500);
  await bob.post(`/api/cards/${cardId}/simulate-otp`);
  eq('otp code available', (await bob.get(`/api/cards/${cardId}/otp`)).body.length, 1);

  const w1 = Math.round((await bal(bob)) * 100);
  eq('block accepted', (await bob.post(`/api/cards/${cardId}/block`)).status, 200);
  await until(async () => (await bob.get(`/api/cards/${cardId}`)).body.card.status === 'blocked');
  eq('card blocked', (await bob.get(`/api/cards/${cardId}`)).body.card.status, 'blocked');
  eq('provider-reported released balance credited ($55)', Math.round((await bal(bob)) * 100), w1 + 5500);
  eq('top-up on blocked card rejected', (await bob.post(`/api/cards/${cardId}/topup`, { amount: 10 })).status, 400);

  console.log('\n# concurrency (no overspend)');
  await fund(bob, 120);
  const startBal = await bal(bob);
  const amt = Math.floor((startBal / 2.5 - 2) / 1.02); // fee = $2 + 2%  ->  exactly 2 cards affordable
  const results = await Promise.all(Array.from({ length: 6 }, () => bob.post('/api/cards/issue', { productCode: 'MOCK-VISA-ADS', amount: amt })));
  const okCount = results.filter((x) => x.status === 201).length;
  check('balance never negative under parallel issue', (await bal(bob)) >= 0, `balance ${await bal(bob)}`);
  eq('only the 2 affordable cards were issued', okCount, 2);

  console.log('\n# admin controls');
  const bobId = me.user.id;
  eq('settings reject unknown key', (await admin.put('/api/admin/settings', { hack: 1 })).status, 400);
  eq('settings reject negative', (await admin.put('/api/admin/settings', { issue_fee_flat: -1 })).status, 400);
  eq('settings reject pct > 100', (await admin.put('/api/admin/settings', { topup_fee_pct: 150 })).status, 400);
  await admin.put('/api/admin/settings', { issue_fee_flat: 5, issue_fee_pct: 0, card_min_deposit: 25 });
  const pf = (await bob.get('/api/cards/products')).body.products.find((p) => p.code === 'MOCK-VISA-ADS');
  eq('new issue fee visible to users', [pf.issueFeeFlat, pf.issueFeePct, pf.minDeposit], [5, 0, 25]);
  eq('global card min deposit enforced', (await bob.post('/api/cards/issue', { productCode: 'MOCK-VISA-ADS', amount: 15 })).status, 400);
  await admin.patch(`/api/admin/users/${bobId}`, { feeOverrides: { issue_fee_flat: 0, card_min_deposit: 10 } });
  const pf2 = (await bob.get('/api/cards/products')).body.products.find((p) => p.code === 'MOCK-VISA-ADS');
  eq('per-user override beats global', [pf2.issueFeeFlat, pf2.minDeposit], [0, 10]);
  await admin.put('/api/admin/products/MOCK-VISA-ADS', { label: 'Visa Ads', enabled: true, issueFeeFlat: 1, issueFeePct: 0, minDeposit: 40 });
  const pf3 = (await alice.get('/api/cards/products')).body.products.find((p) => p.code === 'MOCK-VISA-ADS');
  eq('per-product override beats global', [pf3.issueFeeFlat, pf3.minDeposit, pf3.label], [1, 40, 'Visa Ads']);
  await admin.put('/api/admin/products/MOCK-MC-META', { label: 'MC Meta', enabled: false });
  check('disabled product hidden from users', !(await alice.get('/api/cards/products')).body.products.some((p) => p.code === 'MOCK-MC-META'));
  await admin.put('/api/admin/products/MOCK-MC-META', { label: 'MC Meta', enabled: true });
  eq('adjust needs reason', (await admin.post(`/api/admin/users/${bobId}/adjust`, { amount: 5 })).status, 400);
  const b0 = await bal(bob);
  await admin.post(`/api/admin/users/${bobId}/adjust`, { amount: 12.5, note: 'goodwill' });
  eq('manual credit', Math.round(((await bal(bob)) - b0) * 100), 1250);
  await admin.post(`/api/admin/users/${bobId}/adjust`, { amount: -2.5, note: 'correction' });
  eq('manual debit', Math.round(((await bal(bob)) - b0) * 100), 1000);

  await admin.put('/api/admin/settings', { feature_cards: 0 });
  eq('feature switch blocks cards', (await alice.get('/api/cards')).status, 403);
  await admin.put('/api/admin/settings', { feature_cards: 1 });
  await admin.put('/api/admin/settings', { feature_wallet: 0 });
  eq('feature switch blocks wallet', (await alice.post('/api/wallet/deposit-address')).status, 403);
  await admin.put('/api/admin/settings', { feature_wallet: 1 });
  await admin.put('/api/admin/settings', { feature_referrals: 0 });
  eq('feature switch blocks referrals', (await alice.get('/api/referrals')).status, 403);
  await admin.put('/api/admin/settings', { feature_referrals: 1 });

  await admin.patch(`/api/admin/users/${bobId}`, { status: 'suspended' });
  eq('suspended user cannot issue', (await bob.post('/api/cards/issue', { productCode: 'MOCK-VISA-ADS', amount: 50 })).status, 403);
  await admin.patch(`/api/admin/users/${bobId}`, { status: 'active' });
  eq('cannot demote self', (await admin.patch(`/api/admin/users/${(await admin.get('/api/auth/me')).body.user.id}`, { role: 'user' })).status, 400);

  await admin.put('/api/admin/settings', { registration_open: 0 });
  eq('registration can be closed', (await client().post('/api/auth/signup', { email: 'late@t.io', password: 'password123', name: 'L' })).status, 403);
  await admin.put('/api/admin/settings', { registration_open: 1 });
  await admin.put('/api/admin/settings', { maintenance_mode: 1 });
  eq('maintenance blocks users', (await alice.get('/api/cards')).status, 503);
  eq('maintenance allows admin', (await admin.get('/api/admin/stats')).status, 200);
  await admin.put('/api/admin/settings', { maintenance_mode: 0 });

  // stuck operation resolved by admin
  const cardRow = get('SELECT * FROM cards WHERE user_id=? AND status=? LIMIT 1', bobId, 'active');
  const before = Math.round((await bal(bob)) * 100);
  const opId = run("INSERT INTO card_ops(user_id,card_id,type,request_id,amount_c,fee_c) VALUES(?,?,'TOPUP','stuck-req-0000001',1000,100)", bobId, cardRow.id).id;
  eq('stuck ops visible', (await admin.get('/api/admin/ops')).body.ops.some((o) => o.id === opId), true);
  eq('admin declines stuck op', (await admin.post(`/api/admin/ops/${opId}/resolve`, { status: 'DECLINED' })).status, 200);
  eq('stuck op refunds amount + fee', Math.round((await bal(bob)) * 100), before + 1100);
  eq('resolve twice rejected', (await admin.post(`/api/admin/ops/${opId}/resolve`, { status: 'DECLINED' })).status, 400);

  console.log('\n# credentials');
  const add = await admin.post('/api/admin/credentials', { provider: 'cardspro', label: 'prod', apiKey: 'KEY1234567890', apiSecret: 'SECRET-VALUE-XYZ' });
  eq('credentials saved', add.status, 201);
  const cl = JSON.stringify((await admin.get('/api/admin/credentials')).body);
  check('secret never returned', !cl.includes('SECRET-VALUE-XYZ'));
  check('key is masked', !cl.includes('KEY1234567890') && cl.includes('KEY1'));
  check('secret stored encrypted', !all('SELECT api_secret_enc FROM api_credentials')[0].api_secret_enc.includes('SECRET'));
  eq('http base url rejected', (await admin.post('/api/admin/credentials', { provider: 'cardspro', apiKey: 'a', apiSecret: 'b', baseUrl: 'http://evil' })).status, 400);
  eq('delete credentials', (await admin.del(`/api/admin/credentials/${add.body.id}`)).status, 200);
  eq('mode switch rejects junk', (await admin.put('/api/admin/settings', { provider_mode: 'nope' })).status, 400);

  console.log('\n# account manager');
  const aliceId = (await alice.get('/api/auth/me')).body.user.id;
  const mk2 = await admin.post('/api/admin/users', { email: 'mgr2@t.io', password: 'ManagerPass2', name: 'Max Manager', role: 'manager' });
  await admin.patch(`/api/admin/users/${aliceId}`, { managerId: mk2.body.id });
  eq('manager sees own users only', (await mgr.get('/api/manager/users')).body.users.map((u) => u.email), ['bob@t.io']);
  eq('manager blocked from unassigned user', (await mgr.get(`/api/manager/users/${aliceId}`)).status, 403);
  eq('manager overview', (await mgr.get('/api/manager/overview')).body.users, 1);
  eq('user sends message', (await bob.post('/api/support/messages', { body: 'Hi, can you raise my limit?' })).status, 201);
  eq('manager reads message', (await mgr.get(`/api/manager/users/${bobId}/messages`)).body.messages[0].body, 'Hi, can you raise my limit?');
  eq('manager replies', (await mgr.post(`/api/manager/users/${bobId}/messages`, { body: 'Sure!' })).status, 201);
  eq('user sees reply', (await bob.get('/api/support/messages')).body.messages.at(-1).from_staff, 1);
  eq('manager adds note', (await mgr.post(`/api/manager/users/${bobId}/notes`, { body: 'VIP' })).status, 201);
  eq('manager profile update', (await mgr.put('/api/manager/profile', { title: 'Senior AM', telegram: '@mia' })).status, 200);
  eq('user sees manager telegram', (await bob.get('/api/auth/me')).body.manager.telegram, '@mia');
  eq('manager cannot use admin API', (await mgr.get('/api/admin/users')).status, 403);
  await admin.patch(`/api/admin/users/${aliceId}`, { managerId: mgrId });
  eq('admin reassigns user to manager', (await mgr.get('/api/manager/users')).body.total, 2);

  console.log('\n# referrals');
  const ref = (await alice.get('/api/referrals')).body;
  eq('referral count', ref.count, 1);
  check('referral earnings tracked', ref.totalEarned >= 0.33, `earned ${ref.totalEarned}`);
  check('referred email masked', ref.referred[0].email.includes('***'));
  const ar = (await admin.get('/api/admin/referrals')).body;
  check('admin referral overview', ar.totals.n >= 2 && ar.top.length === 1);

  console.log('\n# reports + history');
  const sum = (await bob.get('/api/reports/summary')).body;
  check('summary has spend', sum.spend30 >= 10);
  eq('14-day series', sum.spendSeries.length, 14);
  const st = (await admin.get('/api/admin/stats')).body;
  check('admin stats: revenue > 0', st.revenueTotal > 0);
  check('admin stats: users counted', st.users >= 2);
  const wt = (await bob.get('/api/transactions/wallet?type=deposit')).body;
  check('wallet history filter', wt.rows.length === 2 && wt.rows.every((r) => r.type === 'deposit'));
  check('search filter', (await bob.get('/api/transactions/card?q=FACEBK')).body.total >= 1);
  check('pagination', (await bob.get('/api/transactions/wallet?limit=2&page=1')).body.rows.length === 2);
  const csv = await bob.get('/api/transactions/wallet/export.csv');
  check('csv export', typeof csv.body === 'string' && csv.body.startsWith('id,'));
  check('user history is isolated', (await alice.get('/api/transactions/wallet')).body.rows.every((r) => r.email === 'alice@t.io'));
  check('admin sees all history', new Set((await admin.get('/api/admin/transactions/wallet?limit=200')).body.rows.map((r) => r.email)).size >= 2);
  check('audit log written', (await admin.get('/api/admin/audit')).body.log.length > 5);

  console.log('\n# realtime (SSE)');
  const ctrl = new AbortController();
  const sse = await fetch(`${base}/api/stream`, { headers: { cookie: bob.cookie() }, signal: ctrl.signal });
  eq('sse connected', sse.status, 200);
  const reader = sse.body.getReader(); let buf = '';
  const pump = (async () => { try { for (;;) { const { value, done } = await reader.read(); if (done) break; buf += Buffer.from(value).toString(); } } catch { /* aborted */ } })();
  await sleep(150);
  await fund(bob, 11);
  const got = await until(() => buf.includes('event: ledger') && buf.includes('event: deposit'), 3000);
  check('live ledger/deposit events pushed', !!got);
  ctrl.abort(); await pump;

  console.log('\n# security');
  eq('form posts without JSON content-type rejected (CSRF)', (await fetch(`${base}/api/cards/1/block`, { method: 'POST', headers: { cookie: bob.cookie(), 'content-type': 'text/plain' }, body: 'x' })).status, 415);
  eq('invalid json -> 400', (await fetch(`${base}/api/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{bad' })).status, 400);
  check('security headers', (await fetch(`${base}/`)).headers.get('x-frame-options') === 'DENY');
  check('password hash never exposed', !JSON.stringify((await admin.get(`/api/admin/users/${bobId}`)).body).includes('$2'));
  eq('static index served', (await fetch(`${base}/`)).status, 200);
  eq('unknown api route 404', (await admin.get('/api/nope')).status, 404);

  console.log(`\n${pass} passed, ${fail} failed`);
  server.close(); fs.rmSync(tmp, { recursive: true, force: true });
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST CRASH', e); process.exit(2); });
